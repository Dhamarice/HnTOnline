<?php 
/*
* Database Constants 
*/
$DB_HOST = "localhost";
$DB_USERNAME = "hammeran_hntdbur";
$DB_PASSWORD = "password";
$DB_NAME = "hammeran_shpdb";
 
//Connecting to the database
$con = mysqli_connect ($DB_HOST, $DB_USERNAME, $DB_PASSWORD, $DB_NAME);
 
//checking the successful connection
if($con) {
 //getting the name from request 
 $user_login = (isset($_POST['username']) ? $_POST['username'] : '');
 $user_pass = (password_hash($_POST['password'], PASSWORD_BCRYPT));
 /* $user_nicename = (isset($_POST['user_nicename']) ? $_POST['user_nicename'] : '');   
   *$user_email = $_POST['user_email']; 
   *$user_url = $_POST['user_url'];
    *$user_registered = $_POST['user_registered']; 
	* $user_activation_key = (isset($_POST['user_activation_key']) ? $_POST['user_activation_key'] : '');
	  *$user_status = $_POST['user_status']; 
	  * $display_name = (isset($_POST['display_name']) ? $_POST['display_name'] : '');
 */
 //creating a statement to insert to database 
 
 $query = " SELECT * FROM wp_users WHERE user_pass = '".$user_pass."' AND user_login = '".$user_login."' "; 
 
 $result = mysqli_query ($con, $query);
 $response = array ();
 
 if (mysqli_num_rows($result) > 0 ) {
	 $status = 'OK';
 }
 else
 {
	 $status = 'FAILED';
 }
}
echo json_encode (array ("response"=> $status));

mysqli_close ($con);
?>
}

?>