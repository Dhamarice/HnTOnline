<?php

//load and connect to MySQL database stuff
require("config.inc.php");

include_once('class-phpass.php' );
if (! empty($_POST['voucherid']))
{

    //gets user's info based off of a username.
    $query = "SELECT * FROM `wp_walleto_coupons`  where cpn_code = :vid and cpn_avail>0 ";
    
    $query_params = array(
        ':vid' => $_POST['voucherid']
    );
    
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one to product JSON data:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!";
        die(json_encode($response));
        
    }
    
    //This will be the variable to determine whether or not the user's information is correct.
    //we initialize it as false.
    $validated_info = false;
    
    //fetching all the rows from the query
    $row = $stmt->fetch();
    if ($row) {
		
		if ($row["cpn_type"] == 'percentage'){
			
			$cpn_amt = $_POST['amt'] * ($row["cpn_discount"]/100);
			
		}
		
		else {
			
			$cpn_amt = $row["cpn_discount"];
		}
    
	$response["success"] = 1;
        $response["message"] = "Login successful!";
				   
   $response["posts"]   = array();
        $post             = array();
		$post["cpn_amt"] = $cpn_amt; 
        
        //update our repsonse JSON data
        array_push($response["posts"], $post);
        die(json_encode($response));
    } 
	else {
        $response["success"] = 0;
        $response["message"] = "Invalid Voucher!";
        die(json_encode($response));
    }
 }
 else {
        $response["success"] = 0;
        $response["message"] = "Invalid Credentials2!";
print_r($_POST);
        die(json_encode($response));
 }

?> 
