<?php
 
 require("config.inc.php");
require ("class-phpass.php");
 
 
 if (($_POST['userid'] != "unknownhapanazeronada") || ($_POST['password']!= "unknownhapanazeronada"))
 {
 
 $query = "UPDATE `wp_users` SET  `user_pass` = :pass WHERE id = :userid";
	$hasher = new PasswordHash(8, TRUE);
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':userid' => $_POST['userid'],
        ':pass' =>  $hasher->HashPassword( $_POST['password']),
		
		
    );
    
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        die("Failed to run query: " . $ex->getMessage());
        
        
           $response["success"] = 1;
    $response["message"] = "Internal error occured!";
    echo json_encode($response);
        
       
    }
    
   
    $response["success"] = 1;
    $response["message"] = "Password reset succesful!";
    echo json_encode($response);
    
    }
    
    else {
        
        $randomchars = substr(md5(microtime()),rand(0,26),5);
        
        
        
        
        $query = "UPDATE `wp_users` SET  `user_pass` = :pass WHERE user_login = :userid";
	$hasher = new PasswordHash(8, TRUE);
    
    $query_params = array(
        ':userid' => $_POST['useroremailfake'],
        ':pass' =>  $hasher->HashPassword( $randomchars),
		
		
    );
    
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
         $response["success"] = 0;
    $response["message"] = "Error occured on userame!".$ex;
    echo (json_encode($response));
       
    }
    
    
    
     // when post is not username
        
         $query = "UPDATE `wp_users` SET  `user_pass` = :pass WHERE user_email = :userid";
	$hasher = new PasswordHash(8, TRUE);
    
    $query_params = array(
        ':userid' => $_POST['useroremail'],
        ':pass' =>  $hasher->HashPassword( $randomchars),
		
		
    );
    
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
        
    }
    catch (PDOException $ex) {
           $response["success"] = 0;
    $response["message"] = "Error occured on email!".$ex;
    echo (json_encode($response));
        
       
    }
        
    
    
    
   
   
    
    
    
    
    
    //******************************************************
//
//	Fetching user ID by username
//
//******************************************************  
	
	
	
	
	$query  = " SELECT ID FROM `wp_users` where user_login=:uid";
    //now lets update what :user should be
    $query_params = array(
        ':uid' => $_POST['useroremailfake'],
    );
    


    //Now let's make run the query:
    try { 
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
		
		
		
    }
    catch (PDOException $ex) {
        
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!";
        echo(json_encode($response));
    }
    
    $row = $stmt->fetch();
    if ($row) {
        
                            $uid = $row['ID'];
						
	}
 else {
     
     
    //******************************************************
//
//	Fetching user ID by email
//
//******************************************************  
	
	
	
	
	$query  = " SELECT ID FROM `wp_users` where user_email=:uid";
    //now lets update what :user should be
    $query_params = array(
        ':uid' => $_POST['useroremail'],
    );
    


    //Now let's make run the query:
    try { 
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
		
		
		
    }
    catch (PDOException $ex) {
        
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!";
        echo(json_encode($response));
    }
    
    $row = $stmt->fetch();
    if ($row) {
        
                            $uid = $row['ID'];
						
	}
 else {
        

$response["success"] = 0;
        $response["message"] = "Email ".$_POST['useroremail']." not found! ";
		
       die(json_encode($response));
		
 }
		
 }
    
    
    
    
    
    
    
    
    
    
    
     //******************************************************
//
//	Fetching phone number
//
//******************************************************  
	
	
	
	
	$query  = " SELECT VALUE FROM `wp_cimy_uef_data` where USER_ID=:uid and FIELD_ID=4 LIMIT 1";
    //now lets update what :user should be
    $query_params = array(
        ':uid' => $uid
    );
    


    //Now let's make run the query:
    try { 
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
		
		
		
    }
    catch (PDOException $ex) {
        
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!";
        echo(json_encode($response));
    }
    
    $row = $stmt->fetch();
    if ($row) {
        
                            $telno = $row['VALUE'];
						


        $response["success"] = 2;
        $response["message"] = "Phone number fetched " .$telno;
        echo(json_encode($response));
	}
 else {
         $telno = "Error";

$response["success"] = 0;
        $response["message"] = "Phone number not fetched:".$row['VALUE'];
		
       die(json_encode($response));
		
 }
    
    
    
    
    
    
    
    //******************************************************
//
//	Sending sms
//
//******************************************************  



function send_sms($sender,$cell,$message)
{
	//$sender = 'HTAH';
	
    $user = 'calvinm';
    $pass = 'h4mm3r';
	//$message = "Dear Customer, Your password has been rest to ".$randomchars." Please use this to login and go to personal details to change the password";
	//$cell = isset($_POST['telno']);
    
    $url = "http://api.infobip.com/api/v3/sendsms/plain?user=".$user."&password=".$pass."&sender=" . $sender . "&SMSText=".urlencode($message)."&GSM=". $cell ."&type=longSMS"; 
    $answer = file_get_contents($url);
    return $answer; 
	 //var_dump(parse_url($url));


    
//$code = $_SESSION['startNum'];

    //$cell = $CellNo;
}

 

send_sms('HTAH', $telno, "Dear Customer, Your password has been rest to ".$randomchars." Please use this to login and go to personal details to change the password");

mail($_POST['useroremail'], 'HnTOnline Password Reset', 'Dear Customer,Your password has been reset to '.$randomchars.' Please use this to login and go to personal details to change the password');
        
        
        
       $response["success"] = 2;
    $response["message"] = "SMS sent!";
    echo json_encode($response);  
        
    }
    
    
   ?> 
	
	