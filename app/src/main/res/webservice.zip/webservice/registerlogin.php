<?php

/*
Our "config.inc.php" file connects to database every time we include or require
it within a php script.  Since we want this script to add a new user to our db,
we will be talking with our database, and therefore,
let's require the connection to happen:
*/
require("devconfig.inc.php");
require ("class-phpass.php");

$hasher = new PasswordHash(8, TRUE);
if (isset($_POST['pword']) && isset($_POST['uname'])) {
    //If the username or password is empty when the user submits
    //the form, the page will die.
    //Using die isn't a very good pra$ctice, you may want to look into
    //displaying an error message within the form instead.  
    //We could also do front-end form validation from within our Android App,
    //but it is good to have a have the back-end code do a double check.
 

 $query = " SELECT * FROM wp_users WHERE user_login = :user";
    //now lets update what :user should be
    $query_params = array(
	':user'  => $_POST['uname'],
		);
		
 try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
		
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        //$response["success"] = 0;
        //$response["message"] = "Database Error2. Please Try Again!";
        //die(json_encode($response));
    }
		$row = $stmt->fetch();


	
	$hasher = new PasswordHash(8, TRUE);

$password = $hasher->CheckPassword( $_POST['pword'], $row['user_pass']); 
if ($password == "true") {
	
	/*
	
						String post_id = jsonobject.optString("id");
                        String address = jsonobject.optString("add");
                        String uname = jsonobject.optString("uname");
                        String umail = jsonobject.optString("umail");
                        String balance = jsonobject.optString("balance");
	
	*/
	
		$response["id"] = $row['id'];
			$response["add"] = $row['add'];
				$response["uname"] = $row['uname'];
					$response["umail"] = $row['umail'];
						$response["balance"] = $row['balance'];
						
	
	$response["success"] = 1;
     $response["message"] = "Login sucessfull";
	die(json_encode($response));
   
}	
	
	else {
    $response["success"] = 0;
        $response["message"] = "Incorrect username or password, Please try again";
		die(json_encode($response));
}
    
    //If we have made it here without dying, then we are in the clear to 
    //create a new user.  Let's setup our new query to create a user.  
    //Again, to protect against sql injects, user tokens such as :user and :pass

	}
    

	
   else {
        
        
        // Create some data that will be the JSON response 
        $response["success"] = 0;
        $response["message"] = "Please Enter Both a Username and Password.";
        
        //die will kill the page and not execute any code below, it will also
        //display the parameter... in this case the JSON data our Android
        //app will parse
        die(json_encode($response));
    }
	
?>