<?php

require("config.inc.php");

 $tm 		= $_SERVER['REQUEST_TIME'] ;
 
 
if(isset($_POST['endUserId']) && isset($_POST['amt']) && isset($_POST['yes']) && isset($_POST['oid'])) 
{
try
{

global $wp_query, $wpdb;
//$bid_id = $wp_query->query_vars['bid_id'];
$amt =   intval(trim($_POST['amt']));
$endUserId = intval(trim($_POST['endUserId']));
$total = $amt;
$oid = $_POST['oid'];
	


	 //-------------------------------------------------

 #$ecocash_url = "https://payonline.econet.co.zw/ecocashGateway-preprod/payment/v1/transactions/amount";
 $ecocash_url = "https://payonline.econet.co.zw/ecocashGateway/payment/v1/transactions/amount";

$clientCorrelator = rand().time();
$amount = $total;
//$endUserId = $_GET['endUserId'];
$mcht_code = urlencode( '37252');
$mcht_pin = urlencode('5684');
$mcht_num = urlencode('771991902');

$myhsh =  time().rand(0,9999);
$notify_url = 'http://devshop.hammerandtongues.com/webservice?notify_paid_ecash=1&myhsh=' . $oid ;



$ecocash_values = array(
	
					"clientCorrelator" => "$clientCorrelator",
					"endUserId" => "+263$endUserId",
					"merchantCode" => "$mcht_code",
					"merchantPin" => "$mcht_pin",
					"merchantNumber" => "+263$mcht_num",
					"notifyUrl" => "$notify_url",
					"paymentAmount" => array(
									   		 "charginginformation" => array(
											 					   	  		"amount" => "$amount",
											 								"currency" => "USD",
											 								"description" => "HAMMER AND TONGUES MALL SITE ORDER"
											 								),
											 "chargeMetaData" => array(
									   	  						   		 "onBeHalfOf" => "H&T",
																		 "purchaseCategoryCode" => "HnT Mall",
																		 "channel" => "HTTP"
																		 
								   		   	  							 )
											),
				"referenceCode" => "REF - $clientCorrelator",
				"transactionOperationStatus" => "Charged",
				

);

// Takes the input fields and turn them into the appropriate format
// for an https post. E.g: "merchantCode=02273&merchantPin=1357"
$ecocash_string = json_encode($ecocash_values);

// The CURL library for php is used to establish a connection,
// submit the post, and record the response.
// Ensure that you have the curl library enabled in your php configuration
$request = curl_init($ecocash_url); // initiate curl object
	curl_setopt($request, CURLOPT_HEADER, 0); // set to 0 to eliminate header info from response
	curl_setopt($request, CURLOPT_RETURNTRANSFER, 1); // Returns response data instead of TRUE(1)
	curl_setopt($request, CURLOPT_HTTPAUTH, CURLAUTH_BASIC ) ; 
	curl_setopt($request, CURLOPT_USERPWD,"hammer:#t0ngu3$");
	curl_setopt($request, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
	curl_setopt($request, CURLOPT_ENCODING, "");	
	curl_setopt($request, CURLOPT_SSL_VERIFYHOST, 2); 
	curl_setopt($request, CURLOPT_RETURNTRANSFER, true); 
	curl_setopt($request, CURLOPT_POSTFIELDS, $ecocash_string); // use HTTP POST to send form data
	curl_setopt($request, CURLOPT_SSL_VERIFYPEER, FALSE); // uncomment this line if you get no gateway response.
	curl_setopt($request, CURLOPT_URL, $ecocash_url); 

	$json_raw = curl_exec($request); // execute curl post and store results in $json_raw
	
curl_close ($request); // close curl object

	


// This line takes the response and breaks it into an array using the specified delimiting character

$ecocash_response = json_decode($json_raw, TRUE);
/*print_r($ecocash_response); die;*/
if (preg_match("/SVC0007/i", json_encode($ecocash_response))) {
    //Invalid number
	
	$response["success"] = 0;
    $response["message"] = "Invalid number ".$endUserId;
    echo json_encode($response);
    
	} elseif (preg_match("/SVC0270/i", json_encode($ecocash_response))){
    //Valid number but failed. This might be because customer does not have enough funds 	
	$response["success"] = 0;
    $response["message"] = "Insufficient Funds";
    echo json_encode($response);
    
	} 
	 /*elseif($ecocash_response['transactionOperationStatus'] == "PENDING SUBSCRIBER VALIDATION") 
	*/ 
	 else{
	// Update Order Status Before Returning Success

$response["success"] = 1;
    $response["message"] = "Success, PENDING SUBSCRIBER VALIDATION";
    echo json_encode($response);
    
}
}
	catch (Exception $e) {
    echo 'Caught exception: ',  $e->getMessage(), "\n";
}
	

}
 
else
{
	//print_r($_POST);
	?>
	 <form action="ecash_api_old.php" method="post">
Mobile Number:+263:
			   <input type="number" class="do_input" size=10 name="endUserId" value="" required />
			   <input type="hidden" value="2.00" name="amt" />
			   <input type="hidden" value="19720" name="oid" />
			   <input type="hidden" value="Proceed Now" name="yes" />
			   <br/><br/>
               <input type="submit" name="yes"  />               
                
               </form>
	<?php 
}


?>
               