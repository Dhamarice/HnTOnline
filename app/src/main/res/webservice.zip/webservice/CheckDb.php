<?php


require("devconfig.inc.php");
require ("class-phpass.php");
//require_once('../../../wp-load.php');
$tm = $_SERVER['REQUEST_TIME'] ;
$uid = $_REQUEST['userid'];
 $ptype = $_REQUEST['ptype'];
	 $orderid = $_REQUEST['oid'];
	
		
	

	
	
	
	
	
	

//if posted data is not empty
//if (!empty($_POST)) {
    
    
    	function send_sms($sender,$cell,$message)
{
	//$sender = 'HTAH';
	
    $user = 'calvinm';
    $pass = 'h4mm3r';
	//$message = 'Dear Customer, You have placed an order of $".$_POST["totalprice"].", for invoice  #". $oid ." You will be notified when it is ready for delivery/pick up. Thank you HTSM';
	//$cell = isset($_POST['telno']);
    
    $url = "http://api.infobip.com/api/v3/sendsms/plain?user=".$user."&password=".$pass."&sender=" . $sender . "&SMSText=".urlencode($message)."&GSM=". $cell ."&type=longSMS"; 
    $answer = file_get_contents($url);
    return $answer; 
	 //var_dump(parse_url($url));


    
//$code = $_SESSION['startNum'];

    //$cell = $CellNo;
}
	
	
	
	
	
	//******************************************************
//
//	Creating HTO code
//
//******************************************************
$hasher = new PasswordHash(8, TRUE);

$gennum = mt_rand(1000, 9999);

$htocodeplain = 'HTO'.$gennum;

$htocode = $hasher->HashPassword($htocodeplain);


 
 $query = "INSERT INTO `wp_options`(`option_name`, `option_value`, `autoload`) 
	   VALUES (:NAME, :VALUE, :AUTOLOAD) ";
    //now lets update what :user should be
    $query_params = array(
        ':NAME' => "ODR_".$orderid,
        ':VALUE' => $htocode,
        ':AUTOLOAD' => "yes"
    );
    


    //Now let's make run the query:
    try { 
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
		
		
		 ///$response["success"] = 1;
        //$response["message"] = "HTO code created!";
        //echo(json_encode($response));
		
    }
    catch (PDOException $ex) {
        
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again! HTO" .$ex;
        echo(json_encode($response));
    }
    
	
    	 //******************************************************
//
//	Fetching phone number
//
//******************************************************  
	
	
	
	
	$query  = " SELECT VALUE FROM `wp_cimy_uef_data` where USER_ID=:uid and FIELD_ID=4 LIMIT 1";
    //now lets update what :user should be
    $query_params = array(
        ':uid' => $uid
    );
    


    //Now let's make run the query:
    try { 
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
		
		
		 //$response["success"] = 1;
        //$response["message"] = "Phone number fetched" .$result;
        //echo(json_encode($response));
		
    }
    catch (PDOException $ex) {
        
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!";
        echo(json_encode($response));
    }
    
    $row = $stmt->fetch();
    if ($row) {
        
                                 $telnumber = $row['VALUE'];
						
						if (strpos( $telnumber, "+263") !== false){
						    
						    $telno =  $telnumber;
						}
						
						else {
						    
						    $telno = "+263".$telnumber;
						
}

        //$response["success"] = 1;
        //response["message"] = "Phone number fetched" .$telno;
        //echo(json_encode($response));
	}
 else {
         $telno = "Error";

$response["success"] = 0;
        $response["message"] = "Phone number not fetched:".$row['VALUE'];
		
        echo(json_encode($response));
		
 }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
      	 //******************************************************
//
//	Checking for Paid order
//
//******************************************************  
    

    
    $query = "SELECT paid FROM wp_walleto_order_contents
WHERE orderid=:ORDERID ;";
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':ORDERID' => $_REQUEST['oid'],
    );            
          
    
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        die("Failed to run query: " . $ex->getMessage());
        

    }
  
    $row = $stmt->fetch();
    if ($row) {
        
                            $paid = $row['paid'];
						
if ($paid==1){

        $response["success"] = 1;
        $response["message"] = "Payment successful" .$telno;
        echo(json_encode($response));
        
        
        //Walleto_send_email_when_item_is_paid_buyer($order_id, $uid);
        
          //******************************************************
//
//	update walleto orders
//
//******************************************************
    
    
    
      $query = "UPDATE wp_walleto_orders
SET paid=1, paid_on=:TM
WHERE id=:ORDERID ;";
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
	':TM' => $tm ,
    ':ORDERID' => $_REQUEST['oid'],
    );            
          
    
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        die("Failed to run query: " . $ex->getMessage());
        

    }
    
   
    $response["success"] = 1;
    $response["message"] = "Account successfully updated!";
    echo json_encode($response);
    
    
    
    //******************************************************
//
//	Subtraction of stock
//
//******************************************************

//initial query

if (isset($orderid))
	{
		 $cart = json_decode(stripslashes($_REQUEST['cartitems']));
		foreach($cart as $item)
		{	
	
$query = "UPDATE wp_postmeta SET  meta_value = meta_value - :quant WHERE post_id = :pid and meta_key = 'quant'";
    
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
		':pid' => $item->productid,
		':quant' => $item->qnty,
     
    );
    
    //time to run our query.
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
		
		$prdcid = $db->lastInsertId();
		
				  echo json_encode($response);
	$response["success"] = 1;
    $response["message"] = "Quantity subtracted!";

    }
    catch (PDOException $ex) {
       
        $response["success"] = 0;
        $response["message"] = "Database Error2. Please Try Again!: ".$ex->getMessage();
        die(json_encode($response));
    }




   //******************************************************
//
//	Calling functions to send emails
//
//******************************************************     
     
 	$Seller = $item->seller;
 	
Walleto_send_email_when_item_is_purchased_for_seller($orderid, $Seller,$uid);     
     
Walleto_send_email_when_item_is_paid_seller($orderid, $Seller,  $uid);
		}
		
	}
	
	else {
	    
	    echo("Haina kusetwa oder");
	}
	
		Walleto_send_email_when_item_is_purchased_for_buyer($orderid, $uid);  
		
		Walleto_send_email_when_item_is_paid_buyer($orderid, $uid);
	
		
	
               
    //******************************************************
//
//	Getting invoice number
//
//******************************************************   


$query = "SELECT ometa_value
FROM wp_walleto_ordermeta
WHERE order_id = :pid";
    
    $query_params = array(
        ':pid' => $orderid
    );
    
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!" . $ex->getMessage();
        echo(json_encode($response));
        
    }
      
    //fetching all the rows from the query
 $rows = $stmt->fetchAll();
                           
    if ($rows) {
      foreach ($rows as $row)
                            {
                            //$CellNo = $row['VALUE'];
							$Invnum=$row['ometa_value'];
							
							   $response["success"] = 1;
        $response["message"] = "Fetched number" .$row['ometa_value'] ;
        echo(json_encode($response));
							
							}
					
 }
 else {
         return "Error";
 }




 //******************************************************
//
//	Update payment transaction as user
//
//******************************************************  


                
        $query = "INSERT INTO `wp_walleto_payment_transactions`(`uid`, `reason`, `datemade`, `amount`, `tp`, `uid2`) 
	   VALUES (:uid, :reason, :dt, :amt,  :tp, 0) ";
	   
	   if ($uid != '87') {
	   		$reason = "Paid through ". $ptype . " against invoice ".$Invnum;
			$tp = 1;
	   }
	   else {
		   	   $reason = "USER PAID against invoice ".$Invnum. " via ". $ptype;
			$tp = 0;
	   }
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':uid' => $uid,
		':reason' => $reason, 
		':dt' => $tm,
		':amt' => $_POST['amt'],
		':tp' => $tp,		
    );
   
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
		$invid = $db->lastInsertId();
		
		//$stmt   = $db->prepare($query);
        //$result = $stmt->execute($query_params);
		
		 $response["success"] = 1;
        $response["message"] = "Payment transaction added!";
        echo(json_encode($response));
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!" . $ex->getMessage();
        die(json_encode($response));
    }
	
	
	
	 //******************************************************
//
//	Update payment transaction as bank
//
//******************************************************  
	
	
	
	    
    	   $query = "INSERT INTO `wp_walleto_payment_transactions`(`uid`, `reason`, `datemade`, `amount`, `tp`, `uid2`) 
	   VALUES (:uid, :reason, :dt, :amt,  :tp, 0) ";

		   	   $reason = "USER PAID against invoice ".$Invnum. " via ". $ptype;
			$tp = 0;
	   
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':uid' => 87,
		':reason' => $reason, 
		':dt' => $tm,
		':amt' => $_POST['amt'],
		':tp' => $tp,		
    );
   
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
		$invid = $db->lastInsertId();
		
		//$stmt   = $db->prepare($query);
        //$result = $stmt->execute($query_params);
		
		 $response["success"] = 1;
        $response["message"] = "Payment transaction added!";
        echo(json_encode($response));
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!" . $ex->getMessage();
        die(json_encode($response));
    }
	
	

 


 //******************************************************
//
//	Sending sms
//
//******************************************************  





  send_sms('HTAH', $telno, "Dear Customer, YOU have just placed an order with the order number ".$_POST["oid"].", your HTO code is ". $htocodeplain .".  You will be notified when it is ready for delivery/pick up. Thank you HTSM");

send_sms('HTAH', $telno, "Dear Customer, You have payed an amount of $".$_POST["amt"].", for invoice  # ". $Invnum ." via" .$ptype. "  You will be notified when it is ready for delivery/pick up. Thank you HTSM");
        
        
        
}
else{
	 	if ($ptype == 'COD'){
	    
	     send_sms('HTAH', $telno, "Dear Customer, YOU have just placed an order with the order number".$_POST["oid"].", your HTO code is ". $htocodeplain .".  You will be notified when it is ready for delivery/pick up. Thank you HTSM");
	     	  $responsee["success"] = 1;
    $responsee["message"] = "Order placed successfully!";
    echo json_encode($responsee);
	    
	}
    
    else{
	  $response["success"] = 0;
    $response["message"] = "Payment no validated";
    echo json_encode($response);
    }
}
	
    
    
} else {
	
	  $response["success"] = 0;
    $response["message"] = "Check failed!";
    echo json_encode($response);
	}

	
//}
	?>
	
	
	
	