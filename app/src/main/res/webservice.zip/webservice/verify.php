<?php

 require("devconfig.inc.php");
 $query        = " SELECT * FROM wp_users WHERE mobile_number = :mobile ORDER BY ID DESC LIMIT 1";
    //now lets update what :user should be
    $query_params = array(
        ':mobile' =>$_POST['telno']
    );
    
    //Now let's make run the query:
    try { 
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!";
        die(json_encode($response));
    }
    
    $row = $stmt->fetch();
        
        //You could comment out the above die and use this one:
		
if	($row){
		$code  = $row["verify_code"];
		$user_id  = $row["ID"];
        $response["success"] = 1;
		     $response["user_id"] = $user_id;
			 $response["code"] = $code;
        $response["message"] = "Verification successfull";
        die(json_encode($response));
	
}

else{
	$response["success"] = 0;
        $response["message"] = "Incorrect code!";
        die(json_encode($response));
	
}

?>

<html>    
    <head>    
        <title>Verification Form</title>    
    </head>    
    <body>    
        <link href = "registration.css" type = "text/css" rel = "stylesheet" />    
        <h2>Sign in</h2>    
        <form name = "form1" action="" method = "post" enctype = "multipart/form-data" >    
            <div class = "container">    
                <div class = "form_group">    
                    <label>First Name:</label>    
                    <input type = "text" name = "telno" value = "" required/>    
                </div>    
                <div class = "form_group">    
                    <label>Password:</label>    
                    <input type = "password" name = "code" value = "" />    
                </div>    				
            </div> 
<button type="submit">Submit</button>			
        </form>    
    </body>    
</html> 