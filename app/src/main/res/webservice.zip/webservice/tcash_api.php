<?php

require("config.inc.php");

if(isset($_POST['endUserId']) && isset($_POST['amt']) && isset($_POST['endUserotp']) && isset($_POST['yes'])) :

$amount = floatval(trim($_POST['amt']));
$endUserId = intval(trim($_POST['endUserId']));
$endUserotp = intval(trim($_POST['endUserotp']));

	$mcht_username = "230090";
	$mcht_pid = "HummerTongues";
	$mcht_pass =  "test1234";
	$mcht_enckey = "haskingvista127$";

$reqID =  'hsh'.time().rand(0,9999);


$uid = $_POST['userid'];;
 

/* Creating Request For TeleCash  */
$url = "http://testonlinepay.telecel.co.zw/ObopayExternalWS/ObopayExternalWebServiceV1?WSDL";
//$url = "http://liveonlinepay.telecel.co.zw/ObopayExternalWS/ObopayExternalWebServiceV1?WSDL";
$client = new SoapClient($url);
$header_part = '

<obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="UserName">'.$mcht_username.'</obons:header> 
  <obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="Password">'.$mcht_pid.'</obons:header> 
  <obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="PartnerId">'.$mcht_pass.'</obons:header> 
  <obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="iv">'.$mcht_enckey.'</obons:header>

';
$soap_var_header = new SoapVar( $header_part, XSD_ANYXML, null, null, null );
$soap_header = new SoapHeader( 'http://www.obopay.com/xml/ns/tpu/v1', 'obons', $soap_var_header );
$client->__setSoapHeaders($soap_header);
//$client->__setLocation('http://liveonlinepay.telecel.co.zw/ObopayExternalWS/ObopayExternalWebServiceV1');
$client->__setLocation('http://testonlinepay.telecel.co.zw/ObopayExternalWS/ObopayExternalWebServiceV1?WSDL');

$result = $client->process(array('request'=>array('encoding'=>'UTF-8',
    'ApiIdType' => 'REQ',
                'Tier3AgentId' => $mcht_username,  
                'CustomerPhoneNumber' => '263'.$endUserId,  
                'TransactionType' => '500',  
                'InstrumentType' => '1', 
                'ProcessorCode' => '0026', 
                'PaymentDetails1' => $endUserotp,
                'TxnAmount' => $amount,  
                'CurrencyType' => 'USD', 
                'FeeAmount' => 20, 
                'TaxAmount' => 10,
                'RequestId' => $reqID,  
                'TerminalID' => '123', 
                'Reference1' => 'ONUS',
                'Reference2' => 'CARDLESS'
    )));
    
    
    
    if($result) {
		
		
    $telresult = $result->return->Remark;
    

if ($telresult == "Success") {
	$hash = $result->return->RequestId;	
	$hsh_ = get_option($hash);
	delete_option($hash);
	$exp = explode('|', $hsh_);	
	$uid = $exp[0];
	$datemade = $exp[1];
	$amount = $exp[2];
	$settle_amt = (float)str_replace(",", "", $amount);
	/*********
	SETTLEMENT OF TRANACTION STARTS
	*********/
	$mcht_username = "230090";
	$mcht_pid = "OBOPAY";
	$mcht_pass =  "test1234";
	$mcht_enckey = "haskingvista127$";
	$ops_trnx_id = $result->return->OpsTransactionId;
	$pay_details_1 = date("dmY", $datemade)."MC".$mcht_username."_".rand(1,9999);	
	
	$url = "http://testonlinepay.telecel.co.zw/ObopayExternalWS/ObopayExternalWebServiceV1?WSDL";
	//$url = "http://liveonlinepay.telecel.co.zw/ObopayExternalWS/ObopayExternalWebServiceV1?WSDL";
	$client = new SoapClient($url);

	$header_part = '

<obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="UserName">'.$mcht_username.'</obons:header> 
  <obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="Password">'.$mcht_pid.'</obons:header> 
  <obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="PartnerId">'.$mcht_pass.'</obons:header> 
  <obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="iv">'.$mcht_enckey.'</obons:header>

	';
	$soap_var_header = new SoapVar( $header_part, XSD_ANYXML, null, null, null );
	$soap_header = new SoapHeader( 'http://www.obopay.com/xml/ns/tpu/v1', 'obons', $soap_var_header );
	$client->__setSoapHeaders($soap_header);
	//$client->__setLocation('http://liveonlinepay.telecel.co.zw/ObopayExternalWS/ObopayExternalWebServiceV1');
	$client->__setLocation('http://testonlinepay.telecel.co.zw/ObopayExternalWS/ObopayExternalWebServiceV1?WSDL');
	$reqID =  'hsh'.time().rand(0,9999);
	$results = $client->process(array('request'=>array('encoding'=>'UTF-8',
		'ApiIdType' => 'REQ',  
					'Tier3AgentId' => $mcht_username, 
					'TransactionType' => '503',  
					'InstrumentType' => '1', 
					'ProcessorCode' => '0029', 
					'PaymentDetails1' => $pay_details_1,
					'PaymentDetails2' => $ops_trnx_id."|".$settle_amt,
					'RequestId' => $reqID,  
					'TerminalID' => '123', 
					'Reference1' => 'ONUS',
					'Reference2' => 'CARDLESS'
		)));		
		
	/*********
	SETTLEMENT OF TRANACTION ENDS
	*********/
	
	
	mail('ruvimbom@hammerandtongues.com', 'Telecash Response', 'Result success!'.$telresult);
			
					$response["success"] = 1;
        $response["message"] = "Result success!".$telresult ;
        echo (json_encode($response));
    
	

	}
 else {
		mail('ruvimbom@hammerandtongues.com', 'Telecash Response', 'Result not success! '.$telresult."Request ID ".$result->return->RequestId);
			
			$response["success"] = 0;
           $response["message"] = "Result not success! ".$telresult."Request ID ".$result->return->RequestId;
        echo (json_encode($response));
}
}


else{
    
    mail('ruvimbom@hammerandtongues.com', 'Telecash Response', 'No response found!');
			
			$response["success"] = 1;
        $response["message"] = "No response found" ;
        echo (json_encode($response));
}

die();
endif;

?>
