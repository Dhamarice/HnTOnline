<?php
 
/*
* Database Constants 
*/
define('DB_HOST','196.44.176.187');
define('DB_USERNAME','root');
define('DB_PASSWORD','Hsat@563');
define('DB_NAME', 'hammeran_shpdb');
 
//Connecting to the database
$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
//checking the successful connection
if($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
 
//making an array to store the response
$response = array(); 
 
//if there is a post request move ahead 
if($_SERVER['REQUEST_METHOD']=='POST'){
 
 //getting the name from request 
 $user_login = $_POST['user_login']; 
 $user_pass = $_POST['user_pass']; 
  $user_nicename = $_POST['user_nicename']; 
   $user_email = $_POST['user_email']; 
   $user_url = $_POST['user_url'];
    $user_registered = $_POST['user_registered']; 
	 $user_activation_key = $_POST['user_activation_key']; 
	  $user_status = $_POST['user_status']; 
	   $display_name = $_POST['display_name']; 
 
 //creating a statement to insert to database 
 $stmt = $conn->prepare("INSERT INTO wp_users`( `user_login`, `user_pass`, `user_nicename`, `user_email`,  `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES ( ?, ?, ?, ?, ?, NOW(),?, ?, ?)");
 
 //binding the parameter to statement 
 $stmt->bind_param("s", $user_login, $user_pass, $user_nicename, $user_email, $user_url, $user_registered, $user_activation_key, $user_status, $display_name );
 
 //if data inserts successfully
 if($stmt->execute()){
 //making success response 
 $response['error'] = false; 
 $response['message'] = 'Details saved successfully'; 
 }else{
 //if not making failure response 
 $response['error'] = true; 
 $response['message'] = 'Please try later';
 }
 
}else{
 $response['error'] = true; 
 $response['message'] = "Invalid request"; 
}
 
//displaying the data in json format 
echo json_encode($response);

?>