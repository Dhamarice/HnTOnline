<?php

/*
Our "config.inc.php" file connects to database every time we include or require
it within a php script.  Since we want this script to add a new user to our db,
we will be talking with our database, and therefore,
let's require the connection to happen:
*/
require("devconfig.inc.php");


//if posted data is not empty
if (!empty($_POST)) {

    
    $query = " INSERT INTO wp_cimy_uef_data (USER_ID, FIELD_ID, VALUE)
VALUES(:USER_ID, 3, :NATIONAL_ID_NUMBER),
(:USER_ID, 4, :TELEPHONE),
(:USER_ID, 5, :ADDRESS_LINE_1),
(:USER_ID, 6, :ADDRESS_LINE_2),
(:USER_ID, 7, :CITY),
(:USER_ID, 8, :TERMS_OF_USE),
(:USER_ID, 9, :COUNTRY),
(:USER_ID, 10, :AGREE),
(:USER_ID, 11, :REGION),
(:USER_ID, 12, :SUBURB),
(:USER_ID, 13, 00);";
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
	':USER_ID' => $_POST['userid'],
        ':NATIONAL_ID_NUMBER' => $_POST['Idno'],
        ':TELEPHONE' => $_POST['telno'],
		':ADDRESS_LINE_1' => $_POST['address1'],
		':ADDRESS_LINE_2' => $_POST['address2'],
		':CITY' => $_POST['city'],
		':TERMS_OF_USE' => $_POST['telno'],
		':COUNTRY' => $_POST['country'],
		':AGREE' => $_POST['telno'],
		':REGION' => $_POST['regionstate'],
		':SUBURB' => $_POST['surbub'],
		
    );            
          
    
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        //$response["success"] = 0;
        //$response["message"] = "Database Error2. Please Try Again!";
        //die(json_encode($response));
    }
    
    //If we have made it this far without dying, we have successfully added
    //a new user to our database.  We could do a few things here, such as 
    //redirect to the login page.  Instead we are going to echo out some
    //json data that will be read by the Android application, which will login
    //the user (or redirect to a different activity, I'm not sure yet..)
    $response["success"] = 1;
    $response["message"] = "Account successfully updated!";
    echo json_encode($response);
    
    //for a php webservice you could do a simple redirect and die.
    //header("Location: login.php"); 
    //die("Redirecting to login.php");
    
    
} else {
	
	  $response["success"] = 0;
    $response["message"] = "Update failed!";
    echo json_encode($response);
	}
?>



