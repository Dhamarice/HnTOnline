<?php 



/************************************
	*
	*	INCLUDES HERE - ;)
	*
	*************************************/
	include 'classes/php_cookie.php';
	
	include 'lib/admin_menu.php';
	include 'lib/first_run.php';
	include 'lib/first_run_emails.php';
	include 'lib/post_new.php';
	include 'lib/advanced_search.php';
	
	include 'lib/widgets/browse-by-category.php';
	include 'lib/widgets/latest-posted-products.php';
	include 'lib/widgets/most-visited-products.php';
	include 'lib/widgets/featured-products.php';
	include 'lib/widgets/search-widget.php';
	include 'lib/widgets/browse_shops.php';
	
	//----- my account includes ---------
	
	include 'lib/my_account/my_account.php';
	include 'lib/my_account/private_messages.php';
	include 'lib/my_account/reviews.php';
	include 'lib/my_account/personal_info.php';
	include 'lib/my_account/shop_loyalty_points.php';
	include 'lib/my_account/buyer_common_basket.php';
	include 'lib/my_account/finances.php';
	
	include 'lib/my_account/outstanding_payments.php';
	include 'lib/my_account/all_orders.php';
	include 'lib/my_account/not_shipped.php';
	include 'lib/my_account/shipped_items.php';
	
	include 'lib/my_account/shipped_orders.php';
	include 'lib/my_account/awaiting_shipping.php';
	include 'lib/my_account/awaiting_payments.php';
	include 'lib/my_account/active_products.php';
	include 'lib/my_account/out_of_stock.php';
	include 'lib/my_account/order_content.php';
	include 'lib/my_account/order_content2.php';
	include 'lib/my_account/pay_4_item.php';
	include 'lib/my_account/pay_4_item_virtual.php';
	include 'lib/my_account/pay_for_item_cod.php';
	include 'lib/my_account/my_shop_setup.php';
	include 'lib/my_account/purchase_membership.php';
	include 'lib/my_account/purchase_membership_credits.php';
	include 'lib/my_account/cancel_order.php';
	
	include 'lib/login_register/custom2.php';
	
	include 'lib/my_cart.php';
	include 'lib/checkout.php';	
	include 'lib/set_delivery.php';
	include 'lib/set_pickup.php';
	include 'lib/shops.php';
	include 'lib/watchlist.php';
	include 'lib/all_categories.php';
	include 'lib/blog.php';
	include 'lib/my_account/seller_dashboard.php';
	include 'lib/wl_manage_locations.php';
	include 'lib/wl_manage_packages.php';
	include 'lib/wl_manage_rewards.php';
	include 'lib/wl_dashboard_stats.php';
	include 'lib/wl_manage_draws.php';
	include 'lib/wl_odr_cln_verification.php';
	include 'lib/wl_odr_dlv_invoice.php';
	include 'lib/wl_pro_csv_import.php';
	include 'lib/wl_odr_cmb_invoices.php';
	
	
	add_shortcode('walleto_my_account_home', 							'Walleto_my_account_display_home_page');
	add_action('widgets_init',	 										'Walleto_framework_init_widgets' );
	add_action('init', 													'walleto_create_post_type' );
	add_action('admin_menu', 											'Walleto_admin_main_menu_scr');
	add_action('admin_head', 											'walleto_admin_main_head_scr');
	add_action("template_redirect", 									'walleto_template_redirect');
	add_action('query_vars', 											'walleto_add_query_vars'); 
	add_action('wp_enqueue_scripts', 									'walleto_add_theme_styles');
	add_filter('wp_head',												'walleto_add_max_nr_of_images');
	
	add_image_size( 'main-image-post', 170, 135, false );
	add_image_size( 'main-image-post2', 205, 155, true );  
	add_image_size( 'small-image-post', 65, 65, false );
	add_image_size( 'image-single-product-page', 350, 200, true );
	add_image_size( 'slider-image', 150, 110, false );
	
	
	
	
	add_action("manage_posts_custom_column", 					"walleto_my_custom_columns");
	add_filter("manage_edit-product_columns",					"walleto_my_products_columns");
	add_filter("manage_edit-shop_columns",						"walleto_my_shops_columns");
	add_action('save_post',										'walleto_save_custom_fields');
	add_action( 'init', 										'walleto_register_my_menus' );
	add_action('generate_rewrite_rules', 						'walleto_rewrite_rules' );
	
	add_shortcode( 'walleto_my_account' , 									'Walleto_my_account_display_home_page' );
	add_shortcode( 'walleto_my_account_priv_mess' , 						'Walleto_my_account_display_priv_mess_page' );
	add_shortcode( 'walleto_my_account_reviews' , 							'Walleto_my_account_display_reviews_page' );
	add_shortcode( 'walleto_my_account_pers_info' , 						'Walleto_my_account_display_persinfo_page' );
	add_shortcode( 'walleto_my_account_shp_lty_pnts' , 						'Walleto_my_account_display_shp_lty_pnts' );
	add_shortcode( 'walleto_my_account_byr_cmn_bskt' , 						'Walleto_my_account_display_byr_cmn_bskt' );		
	add_shortcode( 'walleto_my_account_finances' , 							'Walleto_my_account_display_finances_page' );	
	
	add_shortcode( 'walleto_my_account_all_orders' , 						'Walleto_my_account_display_all_orders_page' );
	add_shortcode( 'walleto_my_account_outstand_pay' , 						'Walleto_my_account_display_outstanding_pay_page' );
	add_shortcode( 'walleto_my_account_not_shipped' , 						'Walleto_my_account_display_not_shipped_page' );
	add_shortcode( 'walleto_my_account_shipped_cust' , 						'Walleto_my_account_display_shipped_cust_page' );
	
	add_shortcode( 'walleto_my_account_active_items' , 						'Walleto_my_account_display_active_items_page' );
	add_shortcode( 'walleto_my_account_out_of_stock' , 						'Walleto_my_account_display_out_of_stock_page' );	
	add_shortcode( 'walleto_my_account_aw_pay' , 							'Walleto_my_account_display_awa_pay_page' );
	add_shortcode( 'walleto_my_account_aw_shp' , 							'Walleto_my_account_display_awa_shp_page' );	
	add_shortcode( 'walleto_my_account_shipped_orders' ,					'Walleto_my_account_display_shipped_orders_page' );
	add_shortcode( 'walleto_theme_shopping_cart' ,							'walleto_cart_area_function' );
	add_shortcode( 'walleto_theme_checkout_page' ,							'walleto_checkout_area_function' );
	add_shortcode( 'walleto_theme_set_delivery_page' ,						'walleto_delivery_area_function' );	
	add_shortcode( 'walleto_theme_set_pickup_page' ,						'walleto_pickup_area_function' );	
	add_shortcode( 'walleto_my_account_order_cnt_pg' ,						'walleto_get_my_order_content_area_function' );
	add_shortcode( 'walleto_theme_post_new' ,								'walleto_post_new_product_content_area_function' );
	add_shortcode( 'walleto_theme_adv_search' ,								'walleto_advanced_search_content_area_function' );
	add_shortcode( 'walleto_my_account_pay_4_item' ,						'walleto_pay_4_item_content_area_function' );
	add_shortcode( 'walleto_my_account_pay_4_item_virt' ,					'walleto_pay_4_item_virt_content_area_function' );
	add_shortcode( 'walleto_my_account_cash_on_delivery' ,					'walleto_pay_4_item_cod_content_area_function' );
	add_shortcode( 'walleto_theme_shops_page' ,								'walleto_shops_show_area_function' );
	add_shortcode( 'walleto_watch_list' ,									'walleto_watchlist_area_function' );
	add_shortcode( 'walleto_show_all_categories' ,							'walleto_all_cats_area_function' );
	add_shortcode( 'walleto_blog_posts' ,									'walleto_blog_posts_area_function' );
	add_shortcode( 'walleto_my_account_purchase_mem' ,						'walleto_purchase_membership_area_function' );
	add_shortcode( 'walleto_my_account_my_shop_setup' ,						'walleto_my_shop_setup_area_function' );
	add_shortcode( 'walleto_my_account_purchase_mem_crds' ,					'walleto_purchase_membership_area_function_crds' );
	add_shortcode( 'walleto_my_account_order_cnt_pg2' ,						'walleto_get_my_order_content_area_function2' );
	add_shortcode( 'walleto_my_account_cancel_order' ,						'Walleto_my_account_display_cancel_order_page' );





/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function Walleto_send_email_when_item_is_paid_seller($oid, $the_seller_id,  $the_buyer_id) //received by seller
{
	$enable 	= get_option('Walleto_paid_order_seller_email_enable');
	$subject 	= get_option('Walleto_paid_order_seller_email_subject');
	$message 	= get_option('Walleto_paid_order_seller_email_message');	
	
	
	
	if($enable != "no"):
		
 
		$post_au 			= get_post($pid);
		$user 				= get_userdata($the_seller_id);
		$buyer 				= get_userdata($the_buyer_id);
		$site_login_url 	= Walleto_login_url();
		$site_name 			= get_bloginfo('name');
		$account_url 		= get_permalink(get_option('Walleto_my_account_page_id'));
		
		$post 		= get_post($pid);
		$item_name 	= $post_au->post_title;
		$item_link 	= get_permalink(get_option('Walleto_my_account_aw_pay_page_id'));

		$find 		= array('##order_id##', '##seller_user##', '##buyer_user##', '##site_login_url##', '##your_site_name##', '##your_site_url##' , '##my_account_url##', '##order_link##');
   		$replace 	= array($oid, $user->user_login, $buyer->user_login, $site_login_url, $site_name, get_bloginfo('siteurl'), $account_url, $item_link);
		
		$tag		= 'Walleto_send_email_when_item_is_purchased_for_buyer';
		$find 		= apply_filters( $tag . '_find', 	$find );
		$replace 	= apply_filters( $tag . '_replace', $replace );
		
		$message 	= Walleto_replace_stuff_for_me($find, $replace, $message);
		$subject 	= Walleto_replace_stuff_for_me($find, $replace, $subject);
		
		//---------------------------------------------
		
		$email = $user->user_email;
		Walleto_send_email($user->user_email, $subject, $message);
		
		/* Buyer Shop Based Loyalty Points Calculation */
		$lty_pnts_allowed = get_field('is_lty_pnts_allowed', $shp_id);
		$loyaltyPriceOption  =  intval(get_field('shp_lty_amt', $shp_id));
		$loyaltyPointsOption =  intval(get_field('shp_lty_pnts', $shp_id));
		if($lty_pnts_allowed == "yes" && !empty($loyaltyPriceOption) && !empty($loyaltyPointsOption)) {
			$perdollarloyalty = $pnts = 0;			
			$usr_shp_lty_key = "shp_".$shp_id."_loyalty_points";
			$perdollarloyalty = $loyaltyPointsOption/$loyaltyPriceOption;
			$userLoyaltyPoints = get_user_meta($the_buyer_id, $usr_shp_lty_key, true);
			$userLoyaltyPoints = ($userLoyaltyPoints) ? $userLoyaltyPoints : 0;
			$userLoyaltyPoints = $userLoyaltyPoints + ($perdollarloyalty*$orderSellerTotal);
			$pnts = round( $userLoyaltyPoints, 0, PHP_ROUND_HALF_DOWN );
			update_user_meta($the_buyer_id, $usr_shp_lty_key, $pnts);
		}			
		/* Buyer Shop Based Loyalty Points Calculation */			
		
	endif;
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function Walleto_send_email_when_item_is_paid_buyer($oid, $the_buyer_id) //received by buyer
{
	$enable 	   = get_option('Walleto_paid_order_buyer_email_enable');
	$subject 	   = get_option('Walleto_paid_order_buyer_email_subject');
	$message 	   = get_option('Walleto_paid_order_buyer_email_message');	

	if($enable != "no"):			
		$buyer 		    = get_userdata($the_buyer_id);	
		$site_login_url = Walleto_login_url();
		$site_name 		= get_bloginfo('name');
		$account_url 	= get_permalink(get_option('Walleto_my_account_page_id'));
		$tot_head		="";
		
		$lnk 		= walleto_get_order_content_link($oid);
		$find 		= array('##buyer_user##', '##site_login_url##', '##your_site_name##', '##your_site_url##' , '##my_account_url##', '##order_id##', '##order_link##');
   		$replace 	= array($buyer->user_login, $site_login_url, $site_name, get_bloginfo('siteurl'), $account_url, $oid, $lnk);
		
		$tag		= 'Walleto_send_email_when_item_is_paid_buyer';
		$find 		= apply_filters( $tag . '_find', 	$find );
		$replace 	= apply_filters( $tag . '_replace', $replace );
		
		$message 	= Walleto_replace_stuff_for_me($find, $replace, $message);
		$subject 	= Walleto_replace_stuff_for_me($find, $replace, $subject);
		
		//---------------------------------------------
			/*Spidanet: update buyer's loyalty points starts*/

		$loyaltyPriceOption  =  get_option('Walleto_loyalty_price');
		$loyaltyPointsOption =  get_option('Walleto_loyalty_points');
		if(!empty($loyaltyPriceOption) && !empty($loyaltyPointsOption)) {
			$perdollarloyalty = $pnts = 0;
			$orderDetails = walleto_get_order_obj($oid);
			$orderTotal = $orderDetails->totalprice;
			$perdollarloyalty = $loyaltyPointsOption/$loyaltyPriceOption;
			$userLoyaltyPoints = get_user_meta($the_buyer_id, 'loyalty_points',true);
			$userLoyaltyPoints = ($userLoyaltyPoints) ? $userLoyaltyPoints : 0;
			$userLoyaltyPoints = $userLoyaltyPoints + ($perdollarloyalty*$orderTotal);
			$pnts = round( $userLoyaltyPoints, 0, PHP_ROUND_HALF_DOWN );
			update_user_meta($the_buyer_id, 'loyalty_points',$pnts);
		}
		/*Spidanet: update buyer's loyalty points ends*/



		if($message!=''){
			Walleto_send_email($buyer->user_email, $subject, $message);
		}
	 
	
	endif;
	// Sending receipt of shipping in a separate email
	wl_send_dlvry_receipt($oid, $the_buyer_id);
	
	// Check if any draw is enabled and this user transaction is eligible for any enabled draw.
	Walleto_add_draw_entries($oid, $the_buyer_id); 
}

function Walleto_send_email_when_item_is_purchased_for_buyer($order_id, $buyer_id)
{
	

	$the_buyer_id = $buyer_id;
	$oid          = $order_id;
	$enable 	= get_option('Walleto_buy_now_order_buyer_email_enable');
	$subject 	= get_option('Walleto_buy_now_order_buyer_email_subject');
	$message 	= get_option('Walleto_buy_now_order_buyer_email_message');
	$odr_vat 	= (get_option('Walleto_purchase_vat')) ? get_option('Walleto_purchase_vat') : 15;
	$odr_vat_perc = $odr_vat / 100;

	$orderDetails  	= walleto_get_order_obj($oid);
	$orderTotal   	= $orderDetails->totalprice;
	$orderDis      	= $orderDetails->discount;
	$orderShp		= $orderDetails->shipping;
	$orig_orderShp	= $orderShp / (1+$odr_vat_perc); // Original delivery amount(without VAT)
	$orig_orderShp 	= Walleto_formats($orig_orderShp, 2);
	$orderShpTax 	= $orderShp - $orig_orderShp;
	$orderPkup		= 0;
	$orderPkupTax 	= 0;
	$orderPkup_ttl	= 0;
	$Pkupinf		= $orderDetails->pickup;
	if(!empty($Pkupinf)) {
		$infarr = "";
		$infarr = explode('|', $orderDetails->pickup);
		$orderPkup_ttl = $infarr[1]; // Total pick up amount including VAT
		$orderPkup = $orderPkup_ttl / (1+$odr_vat_perc); // Original pick up amount(without VAT)
		$orderPkup = Walleto_formats($orderPkup, 2);
		$orderPkupTax = $orderPkup_ttl - $orderPkup;
	}
	
	if($orderDis>0)
		$orderOldTotal = $orderTotal+$orderDis;
	else {
		$orderOldTotal = $orderTotal;
		$orderDis = 0;
	}	
	$cust_details  ='';
	$invoice_head  = '';

	
	if($enable != "no"):
	
		/*Spidanet: Sending proforma invoice starts */

		global $wpdb;
		
		$buyer 		    = get_userdata($the_buyer_id);

		$orderConentSql ="SELECT pid,sid,stitle,price,quant,discount FROM ".$wpdb->prefix."walleto_order_contents WHERE orderid='$oid'";
		$orderRs = $wpdb->get_results($orderConentSql);
		$userAdd 			= ""; 
		$regAdd 			= ""; 
		$inv_no 			= "";
		$add1 				= get_cimyFieldValue($the_buyer_id, "ADDRESS_LINE_1");
		$add2 				= get_cimyFieldValue($the_buyer_id, "ADDRESS_LINE_2");
		//$userAdd			= $add1.$add2;
		$userAdd = $add1;
		if(!empty($add2)) {
			$userAdd .= "\n".$add2;
		}
		$userTel 			= get_cimyFieldValue($the_buyer_id, "TELEPHONE");
		
		$userCity 			= get_cimyFieldValue($the_buyer_id, "CITY");
		$usercty 			= Walleto_get_city($userCity);
		
		$userCountry 		= get_cimyFieldValue($the_buyer_id, "COUNTRY");
		
		$userRgn 			= get_cimyFieldValue($the_buyer_id, "REGION");
		$userrgn 			= Walleto_get_region($userRgn);
		
		$userSbrb 			= get_cimyFieldValue($the_buyer_id, "SUBURB");
		$usersbrb 			= Walleto_get_suburb($userSbrb);
		
		$userZip 			= get_cimyFieldValue($the_buyer_id, "ZIP");		
		$item_details		='';
		$logo_details		='<table><tbody>';
		
		foreach ($orderRs as $logoKey => $logoValue) {			
		    $postLogo=get_field('shop_logo',$logoValue->sid);
			$logoImg = $postLogo["url"];

			if($logoImg!=""){
				$logo_details  .= '<tr><td><img src="'.$logoImg.'" width="150px" /><td></tr>';
			}
		}
		/* Generate proforma invoice number and store it for further use */
		$inv_no = wl_generate_odr_proinvnum();
		if(empty($inv_no)) {
			$inv_no = rand( 100000 , 99999999 );
		}
		
		wl_update_order_meta($oid, "proformainv_num", $inv_no);

		/* Store buyer city for further use */
		wl_update_order_meta($oid, "buyer_city", $usercty->cty_name);
		
		/* Store buyer registered address for further use in logistics panel*/
		$regAdd = $userAdd . "|" . $usersbrb->sbrb_name . "|" . $usercty->cty_name . "|" . $userrgn . "|" . $userCountry;
		if(!empty($userZip)) {
			$regAdd .= "|" . $userZip;
		}
		update_user_meta($the_buyer_id, 'reg_add', $regAdd);
		$logo_details .="</table>";
		$invoice_head = '<table  style="border-collapse:collapse;width:90%"><tr><td style="border:1px solid #000000; text-align:center;" colspan="5">HAMMER AND TONGUES AFRICA HOLDINGS</td></tr><tr><td style="border:1px solid #000000; text-align:center;" colspan="1"><img alt="Hammer and Tongues Africa Holdings" src="http://shopping.hammerandtongues.com/wp-content/themes/Walleto/images/online_logo.png?chk=1" /></td><td style="border-top: 1px solid #000000; border-left: 1px solid #000000; border-bottom: 1px solid #000000;" colspan="3">'.__("All prices are inclusive of VAT.", "Walleto").'<br/><strong>'.__("BUYER PROFORMA INVOICE", "Walleto").'</strong><table  style="border-collapse: collapse;margin-bottom:5px;"><tbody><tr><td style="border:1px solid #000000;">'.__("INVOICE DATE: ", "Walleto").'</td><td style="border:1px solid #000000;">'.date( 'Y-m-d', current_time( 'timestamp', 0 ) ).'</td></tr><tr><td style="border:1px solid #000000;">'.__("INVOICE NO: ", "Walleto").'</td><td style="border:1px solid #000000;">'.intval($inv_no).'</td></tr><tr><td style="border:1px solid #000000;">'.__("ORDER NO. ", "Walleto").'</td><td style="border:1px solid #000000;">'.$oid.'</td></tr></tbody></table></td><td style= "border-top: 1px solid #000000;border-bottom: 1px solid #000000; border-right: 1px solid #000000;" >&nbsp;</td></tr></tbody>';
		$cust_details = '<tbody><tr><td style="border:1px solid #000000;" colspan="2"><u>'.__("CUSTOMER", "Walleto").'</u><br />'.$buyer->first_name.' '.$buyer->last_name.'<br />'.cimy_uef_sanitize_content($userAdd).'<br />'.$usersbrb->sbrb_name.'<br />'.$usercty->cty_name.'<br />'.$userrgn.'<br />'.cimy_uef_sanitize_content($userCountry).'<br />'.cimy_uef_sanitize_content($userZip).'</td><td style="border-top: 1px solid rgb(0, 0, 0); border-bottom: 1px solid rgb(0, 0, 0); border-left: 1px solid rgb(0, 0, 0);" colspan="2">TEL: '.cimy_uef_sanitize_content($userTel).'<br />CUST NO.: '.$buyer->ID.'</td><td style= "border-top: 1px solid #000000; border-bottom: 1px solid #000000;border-right: 1px solid #000000;">&nbsp;</td></tr></tbody>';
		$item_details  = '<tbody><tr><th style="border:1px solid #000000;">STOCK NR</th><th style="border:1px solid #000000;">DESCRIPTION</th><th style="border:1px solid #000000;">SHOP</th><th style="border:1px solid #000000;">QUANTITY</th><th style="border:1px solid #000000;">AMOUNT</th></tr>';
		$rowTotal=0;
		$shopAddressArr=array();
		foreach ($orderRs as $key => $value) {
			$abt_off = "";
			$shopspost=array($value->sid, $value->stitle);
			if($value->discount) {
				$abt_off = '<p style="font-size: 11px;margin: 0;">'.Walleto_get_show_price($value->discount).__(" discount applied", "Walleto").'</p>';
			}			
			array_push($shopAddressArr,$shopspost);
			$item_details  .= '<tr><td style="border:1px solid #000000;text-align:center;">'.$value->pid.'</td><td style="border:1px solid #000000;text-align:center;" ><strong>'.get_the_title($value->pid).$abt_off.'</strong></td><td style="border:1px solid #000000;text-align:center;" >'.$shopspost[1].'</td><td style="border:1px solid #000000;text-align:center;">'.$value->quant.'</td><td style="border:1px solid #000000;text-align:center;" >'.Walleto_formats(($value->price*$value->quant), 2).'</td></tr>';
			$rowTotal +=$value->price*$value->quant;
				
		}		
		$item_details .= '</tbody></table>';
	
		$grand_tot = '<table  style="border-collapse: collapse;width:90%">';	
		$grand_tot .= '<tbody><tr><th></th><th></th><th>VAT</th><th></th></tr><tr><td style="border:1px solid #000000;" ><strong>'.__("SALES", "Walleto").'</strong></td><td style="border:1px solid #000000;">'.$orderOldTotal.'</td><td style="border:1px solid #000000;">0</td><td style="border:1px solid #000000;" >'.$orderOldTotal.'</td></tr>';
		
		// If discount available
		if($orderDis > 0){
			$grand_tot .= '<tr><td style="border:1px solid #000000;"><strong>'.__("DISCOUNT", "Walleto").'</strong></td><td style="border:1px solid #000000;">'.$orderDis.'</td><td style="border:1px solid #000000;">0</td><td style="border:1px solid #000000;">'.$orderDis.'</td></tr>';
		}
		// If shipping available
		if($orderShp > 0){
			$grand_tot .= '<tr><td style="border:1px solid #000000;"><strong>'.__("SHIPPING", "Walleto").'</strong></td><td style="border:1px solid #000000;">'.$orig_orderShp.'</td><td style="border:1px solid #000000;">'.$orderShpTax.'</td><td style="border:1px solid #000000;">'.$orderShp.'</td></tr>';
		} else {
			$orderShp = 0;
		}		
		// If pick up available
		if($orderPkup > 0){
			$grand_tot .= '<tr><td style="border:1px solid #000000;"><strong>'.__("PICKUP", "Walleto").'</strong></td><td style="border:1px solid #000000;">'.$orderPkup.'</td><td style="border:1px solid #000000;">'.$orderPkupTax.'</td><td style="border:1px solid #000000;">'.$orderPkup_ttl.'</td></tr>';
		}
		
		$grand_tot .= '<tr><td style="border:1px solid #000000;"><strong>'.__("TOTAL DUE", "Walleto").'</strong></td><td style="border:1px solid #000000;"><strong>'.($orig_orderShp + $orderTotal + $orderPkup).'</strong></td><td style="border:1px solid #000000;"><strong>'.($orderShpTax + $orderPkupTax).'</strong></td><td style="border:1px solid #000000;"><strong>'.($orderTotal + $orderShp + $orderPkup_ttl).'</strong></td></tr></tbody>';
		$grand_tot .= '</table>';

		/*Spidanet: Colletion points starts*/
		$collectionPoints = '';	
		$collectionPoints .= '<br/><br/><div><b>'.__("COLLECTION POINTS FOR PRODUCTS", "Walleto").'</b><br/><br/><table cellpadding="1" cellspacing="6">';

		$shopAddressArr = array_unique($shopAddressArr, SORT_REGULAR);
		$shpType = "";
		foreach ($shopAddressArr as $shp) {
			$shpAdd= get_post_meta($shp[0], 'address', true);
			$shpAdd2= get_post_meta($shp[0], 'address2', true);
			$shpCity= get_post_meta($shp[0], 'city', true);
			$shpCountry= get_post_meta($shp[0], 'country/region', true);
			$postLogo = get_field('shop_logo',$shp[0]);
			$shpType = get_field('shop_hnt_type',$shp[0]);
			$shpImg = $postLogo["url"];
			$shpFullAdd= $shpAdd.",&nbsp;".$shpAdd2.'<br/>'.$shpCity.",&nbsp;".$shpCountry;
			$collectionPoints .= '<tr><td>&nbsp;</td><td ><b>'.$shp[1].'</b></td></tr>';
			$collectionPoints .= '<tr><td><img src="'.$shpImg.'"  /></td>';
			$collectionPoints .= '<td >'.$shpFullAdd.'</td></tr>';

		}
		$collectionPoints .= '</table>';
		// To disable collection points in proforma in case of service
		if($shpType != "service") {
			$grand_tot .= $collectionPoints;
		}
		/*Spidanet: Colletion points ends*/


		$user 			= get_userdata($post->post_author);
		$site_login_url = Walleto_login_url();
		$site_name 		= get_bloginfo('name');
		$account_url 	= get_permalink(get_option('Walleto_my_account_page_id'));
		$tot_head		="";
		
		$lnk 		= walleto_get_order_content_link($oid);
		$find 		= array( '##invoicehead##', '##customerdetails##', '##totalhead##', '##itemdetails##','##grandtotal##', '##buyer_user##', '##site_login_url##', '##your_site_name##', '##your_site_url##' , '##my_account_url##', '##order_id##', '##order_link##');
   		$replace 	= array( $invoice_head, $cust_details, $tot_head, $item_details, $grand_tot , $buyer->user_login, $site_login_url, $site_name, get_bloginfo('siteurl'), $account_url, $oid, $lnk);
		

		$tag		= 'Walleto_send_email_when_item_is_purchased_for_buyer';
		$find 		= apply_filters( $tag . '_find', 	$find );
		$replace 	= apply_filters( $tag . '_replace', $replace );
		
		$message 	= Walleto_replace_stuff_for_me($find, $replace, $message);
		$subject 	= Walleto_replace_stuff_for_me($find, $replace, $subject);
		
		//---------------------------------------------
		
		if($message!=''){
			#Walleto_send_email($buyer->user_email, $subject, $message);
		}
		
		$inv_content = $message;
		if($message!='') {		
			require_once( get_template_directory().'/pdf/mpdf.php');
			$filename = "(BUYER)_PROFORMA_INVOICE_".date( 'Y-m-d H:i:s', current_time( 'timestamp', 0 ) ).".pdf";
			$filetitle = "(BUYER)_PROFORMA_INVOICE";
			$mpdf=new mPDF('','A4',11,'sans-serif');
			$mpdf->SetTitle($filetitle);
			//$mpdf->WriteHTML($inv_content);
			$mpdf->WriteHTML(utf8_encode($inv_content));
			$content = $mpdf->Output('', 'S');
			$content = chunk_split(base64_encode($content));
			$mailto = $buyer->user_email;
			$from_name = "admin";
			$from_mail = "online@hammerandtongues.com";
			$replyto = $from_mail;
			$uid = md5(uniqid(time()));		
			$txt_message = 'Hello '.$buyer->user_login.',<br /><br /><p>You have just placed an order with the order ID: <b>'.$oid.'</b> ( '.$lnk.' ).</p><p>You need to login into your account area, under outstanding payments and pay the item price.</p><p>Login here: '.$account_url.'</p><br /><br /><br /><p>Thank you,</p><p>'.$site_name.' Team</p>';

			//Headers of PDF and e-mail
			$header = "--$uid\r\n";
			$header .= "Content-Transfer-Encoding: 8bits\r\n";
			$header .= "Content-Type: text/html; charset=ISO-8859-1\r\n\r\n"; // or utf-8
			$header .= "$txt_message\r\n";
			$header .= "--$uid\r\n";
			$header .= "Content-Type: application/pdf; name=\"".$filename."\"\r\n";
			$header .= "Content-Disposition: attachment; filename=\"".$filename."\"\r\n";
			$header .= "Content-Transfer-Encoding: base64\r\n\r\n";
			$header .= "$content\r\n";
			$header .= "--$uid--\r\n";
			$header2 = "MIME-Version: 1.0\r\n";
			$header2 .= "From: ".$from_mail." \r\n";
			$header2 .= "Return-Path: $from_mail\r\n";
			$header2 .= "Content-type: multipart/mixed; boundary=\"$uid\"\r\n";
			$header2 .= "$uid\r\n";
			mail($mailto,$subject,$header,$header2, "-r".$from_mail);
		}	

		/*Send a copy to admin starts */

		$admin_email = get_option( 'admin_email' );
		$admiSubject = "PRO FORMA INVOICE SENT TO ".$buyer->user_login;
		
		if($message!=''){
			Walleto_send_email($admin_email, $admiSubject, $message);
	 	}

		
	endif;		
	
}

function Walleto_send_email_when_item_is_purchased_for_seller($order_id, $seller_id,$buyer_id)
{
	$enable 	= get_option('Walleto_buy_now_order_seller_email_enable');
	$subject 	= get_option('Walleto_buy_now_order_seller_email_subject');
	$message 	= get_option('Walleto_buy_now_order_seller_email_message');	
	
	if($enable != "no"):
	
		$seller 		= get_userdata($seller_id);
		$buyer 		    = get_userdata($buyer_id);
		
		$site_login_url = Walleto_login_url();
		$site_name 		= get_bloginfo('name');
		$account_url 	= get_permalink(get_option('Walleto_my_account_page_id'));

		$add1 				= get_cimyFieldValue($buyer_id, "ADDRESS_LINE_1");
		$add2 				= get_cimyFieldValue($buyer_id, "ADDRESS_LINE_2");
		//$userAdd			= $add1.$add2;
		$userAdd = $add1;
		if(!empty($add2)) {
			$userAdd .= "\n".$add2;
		}		
		$userTel 			= get_cimyFieldValue($buyer_id, "TELEPHONE");
		$userCity 			= get_cimyFieldValue($buyer_id, "CITY");
		$usercty 			= Walleto_get_city($userCity);
		
		$userRgn 			= get_cimyFieldValue($buyer_id, "REGION");
		$userrgn 			= Walleto_get_region($userRgn);		
		
		$userSbrb 			= get_cimyFieldValue($buyer_id, "SUBURB");
		$usersbrb 			= Walleto_get_suburb($userSbrb);
		
		$userZip 			= get_cimyFieldValue($buyer_id, "ZIP");		
		$userCountry 		= get_cimyFieldValue($buyer_id, "COUNTRY");		
		
		$lnk = walleto_get_order_content_link2($order_id,$seller_id);
		
		global $wpdb;
		$shp_id = 0;
		$orderSql ="SELECT pid,price,quant FROM ".$wpdb->prefix."walleto_order_contents WHERE orderid='$order_id'";
		$orderSellerRs = $wpdb->get_results($orderSql);
		
		$logoQuery = new WP_Query(array("author" => $seller_id,"post_type" =>"shop"));
		
		while ( $logoQuery->have_posts() ) {
			$logoQuery->the_post();
			$postLogo=get_field('shop_logo',get_the_ID());
			$postseller = get_field('seller',get_the_ID());						
			$shp_id = get_the_ID();
			$logoImg = $postLogo["url"];			
			if($logoImg !=""){
				$logoDetails  ='<table><tbody><tr>';
				
				$logoDetails .= '<td><img src="'.$logoImg.'" width="100px" /><td>';
				$logoDetails .="</tr></table>";				
			}
		}		
		 
	    $invoice_head = '<table  style="border-collapse:collapse;width:90%"><tr><td style="border: 1px solid #000000; text-align: center;"  colspan="1"><img alt="Hammer and Tongues Africa Holdings" src="http://shopping.hammerandtongues.com/wp-content/themes/Walleto/images/online_logo.png?chk=1" /><br/>'.$logoDetails.'</td><td style="border:1px solid #000000;" colspan="3"><table  style="border-collapse: collapse;margin-bottom:5px;"><tbody><tr><td style="border:1px solid #000000;">'.__("INVOICE DATE: ", "Walleto").'</td><td style="border:1px solid #000000;">'.date( 'Y-m-d', current_time( 'timestamp', 0 ) ).'</td></tr><tr><td style="border:1px solid #000000;">'.__("BUYER INVOICE NO: ", "Walleto").'</td><td style="border:1px solid #000000;">'.wl_get_order_proinvnum($order_id, $buyer_id).'</td></tr><tr><td style="border:1px solid #000000;">'.__("ORDER NO. ", "Walleto").'</td><td style="border:1px solid #000000;">'.$order_id.'</td></tr></tbody></table></td></tr></tbody>';
		$cust_details = '<tbody><tr><td style="border:1px solid #000000;" colspan="2"><u>'.__("CUSTOMER", "Walleto").'</u><br />'.$buyer->first_name.' '.$buyer->last_name.'<br />'.cimy_uef_sanitize_content($userAdd).'<br />'.$usersbrb->sbrb_name.'<br />'.$usercty->cty_name.'<br />'.$userrgn.'<br />'.cimy_uef_sanitize_content($userCountry).'<br />'.cimy_uef_sanitize_content($userZip).'</td><td style="border:1px solid #000000;" colspan="2">TEL: '.cimy_uef_sanitize_content($userTel).'<br />CUST NO.: '.$buyer->ID.'</td></tr></tbody>';
		$item_details  = '<tbody><tr><th style="border:1px solid #000000;">STOCK NR</th><th style="border:1px solid #000000;">DESCRIPTION</th><th style="border:1px solid #000000;">QUANTITY</th><th style="border:1px solid #000000;">AMOUNT</th></tr>';
		$rowTotal = 0;
		$orderSellerTotal = 0;
		
		foreach ($orderSellerRs as $itemkey => $itemvalue) {
			$prd = get_post($itemvalue->pid);
			if($seller_id == $prd->post_author){						
				$item_details  .= '<tr><td style="border:1px solid #000000;text-align:center">'.$itemvalue->pid.'</td><td style="border:1px solid #000000;text-align:center;" ><strong>'.get_the_title($itemvalue->pid).'</strong></td><td style="border:1px solid #000000;text-align:center;">'.$itemvalue->quant.'</td><td style="border:1px solid #000000;text-align:center;" >'.Walleto_formats(($itemvalue->price*$itemvalue->quant), 2).'</td></tr>';
				$rowTotal += $itemvalue->price*$itemvalue->quant;
				//$orderSellerTotal +=$rowTotal;				
			}				
		}		
		$orderSellerTotal = $rowTotal;
		$item_details  .= '<tr><td colspan="3" style="border:1px solid #000000;text-align:left;">'.__("TOTAL", "Walleto").'</td><td colspan="1" style="border:1px solid #000000;text-align:center;" >'.$rowTotal.'</td></tr>';
		$item_details .= '</tbody></table>';
		
		//echo $item_details;
		$grand_tot = '<table  style="border-collapse: collapse;width:90%">';	
		$grand_tot .= '<tbody><tr><th></th><th></th><th>VAT</th><th></th></tr><tr><td style="border:1px solid #000000;"><strong>'.__("SALES", "Walleto").'</strong></td><td style="border:1px solid #000000;">'.$orderSellerTotal.'</td><td style="border:1px solid #000000;">Inclusive</td><td style="border:1px solid #000000;">'.$orderSellerTotal.'</td></tr>';
		
		$grand_tot .= '<tbody><tr><td style="border:1px solid #000000;"><strong>'.__("TOTAL DUE", "Walleto").'</strong></td><td style="border:1px solid #000000;"><strong></strong></td><td style="border:1px solid #000000;"><strong>Inclusive</strong></td><td style="border:1px solid #000000;"><strong>'.$orderSellerTotal.'</strong></td></tr></tbody>';
		$grand_tot .= '</table>';
		
		$site_login_url = Walleto_login_url();
		$site_name 		= get_bloginfo('name');
		$account_url 	= get_permalink(get_option('Walleto_my_account_page_id'));
		$tot_head		="";
		
		$find 		= array('##invoicehead##', '##customerdetails##', '##totalhead##', '##itemdetails##','##grandtotal##', '##seller_user##', '##buyer_user##', '##site_login_url##', '##your_site_name##', '##your_site_url##' , '##my_account_url##', '##order_id##','##order_link##');
   		$replace 	= array($invoice_head, $cust_details, $tot_head, $item_details, $grand_tot, $seller->user_login, $buyer->user_login, $site_login_url, $site_name, get_bloginfo('siteurl'), $account_url, $order_id, $lnk);
		
		$tag		= 'Walleto_send_email_when_item_is_purchased_for_seller';
		$find 		= apply_filters( $tag . '_find', 	$find );
		$replace 	= apply_filters( $tag . '_replace', $replace );
		
		$message 	= Walleto_replace_stuff_for_me($find, $replace, $message);
		$subject 	= Walleto_replace_stuff_for_me($find, $replace, $subject);
		
		//---------------------------------------------

		Walleto_send_email($seller->user_email, $subject, $message);
		
	endif;
}
			
			?> 