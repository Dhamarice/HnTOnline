<?php

/*
Our "config.inc.php" file connects to database every time we include or require
it within a php script.  Since we want this script to add a new user to our db,
we will be talking with our database, and therefore,
let's require the connection to happen:
*/
require("devconfig.inc.php");
require ("class-phpass.php");


//if posted data is not empty
if (empty($_POST['update'])) {
    //If the username or password is empty when the user submits
    //the form, the page will die.
    //Using die isn't a very good practice, you may want to look into
    //displaying an error message within the form instead.  
    //We could also do front-end form validation from within our Android App,
    //but it is good to have a have the back-end code do a double check.
    if (empty($_POST['username']) || empty($_POST['password'])) {
        
        
        // Create some data that will be the JSON response 
        $response["success"] = 0;
        $response["message"] = "Please Enter Both a Username and Password.";
        
        //die will kill the page and not execute any code below, it will also
        //display the parameter... in this case the JSON data our Android
        //app will parse
        die(json_encode($response));
    }
    
    //if the page hasn't died, we will check with our database to see if there is
    //already a user with the username specificed in the form.  ":user" is just
    //a blank variable that we will change before we execute the query.  We
    //do it this way to increase security, and defend against sql injections
    $query        = " SELECT 1 FROM wp_users WHERE user_login = :user";
    //now lets update what :user should be
    $query_params = array(
        ':user' => $_POST['username']
    );
    
    //Now let's make run the query:
    try {
        // These two statements run the query against your database table. 
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one to product JSON data:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!";
        die(json_encode($response));
    }
    
    //fetch is an array of returned data.  If any data is returned,
    //we know that the username is already in use, so we murder our
    //page
    $row = $stmt->fetch();
    if ($row) {
        // For testing, you could use a die and message. 
        //die("This username is already in use");
        
        //You could comment out the above die and use this one:
        $response["success"] = 0;
        $response["message"] = "Sorry, this username is already in use";
        die(json_encode($response));
    }

  
  	//******************************************************
//
//	INSERT INTO WP_USERMETA
//
//******************************************************
	
	
	    $query = "INSERT INTO `wp_usermeta` (user_id, meta_key, meta_value) VALUES (:user_id, 'nickname', :user), 
		(:user_id, 'first_name', :firstname),
		(:user_id, 'last_name', :lastname),
		(:user_id, 'description', ''),
		(:user_id, 'rich_editing', 'true'),
		(:user_id, 'comment_shortcuts', 'false'),
		(:user_id, 'admin_color', 'fresh'),
		(:user_id, 'use_ssl', '0'),
		(:user_id, 'show_admin_bar_front', 'true'),
		(:user_id, 'wp_capabilities', 'a:1:{s:10:subscriber;b:1;}'),
		(:user_id, 'wp_user_level', '0'),
		(:user_id, 'aim', ''),
		(:user_id, 'yim', ''),
		(:user_id, 'jabber', ''),
		(:user_id, 'pw_user_status', 'approved'),
		(:user_id, 'default_password_nag', '1'),
		(:user_id, 'default_password_nag', 'pw_user_approve_password_reset'),
		(:user_id, 'credits', '0')
		";
   // $hasher->CheckPassword( $_POST['password']
	$hasher = new PasswordHash(8, TRUE);
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':user' => $_POST['username'],
        ':lastname' =>  $_POST['surname'],
		':firstname' => $_POST['firstname'],
		':user_id' => $_POST['user_id'],
		
    );
    
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        //$response["success"] = 0;
        //$response["message"] = "Database Error2. Please Try Again!";
        //die(json_encode($response));
    }
    
   
    $response["success"] = 1;
    $response["message"] = "Account successfully created!";
    echo json_encode($response);
  
  
    	//******************************************************
//
//	INSERT INTO WP_USERS
//
//******************************************************

    $query = "UPDATE `wp_users` SET  `user_login` = :user, `user_pass` = :pass, `user_nicename` = :nicename, `user_email` = :email,  `user_registered` = NOW(), `user_activation_key` = 0, `user_status` = 0, `display_name` = :display  WHERE mobile_number = :number1";
   // $hasher->CheckPassword( $_POST['password']
	$hasher = new PasswordHash(8, TRUE);
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':user' => $_POST['username'],
        ':pass' =>  $hasher->HashPassword( $_POST['password']),
		':nicename' => $_POST['username'],
		':email' => $_POST['email'],
		':display' => $_POST['firstname'] . ' '.$_POST['surname'],
		':number1' => $_POST['telno'],
		
    );
    
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        //$response["success"] = 0;
        //$response["message"] = "Database Error2. Please Try Again!";
        //die(json_encode($response));
    }
    
    //If we have made it this far without dying, we have successfully added
    //a new user to our database.  We could do a few things here, such as 
    //redirect to the login page.  Instead we are going to echo out some
    //json data that will be read by the Android application, which will login
    //the user (or redirect to a different activity, I'm not sure yet..)
    $response["success"] = 1;
    $response["message"] = "Account successfully created!";
    echo json_encode($response);
    
    //for a php webservice you could do a simple redirect and die.
    //header("Location: login.php"); 
    //die("Redirecting to login.php");
   	
	
	
	
	
	
	

    
  
	
	
	
	
	
	
	
	
} else {

  $query = "UPDATE `wp_users` SET  `user_login` = :user, `user_nicename` = :nicename, `user_email` = :email,  `display_name` = :display  WHERE mobile_number = :number1";
   // $hasher->CheckPassword( $_POST['password']
	$hasher = new PasswordHash(8, TRUE);
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':user' => $_POST['username'],
		':nicename' => $_POST['username'],
		':email' => $_POST['email'],
		':display' => $_POST['firstname'] . ' '.$_POST['surname'],
		':number1' => $_POST['telno'],
		
    );
    
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error2. Please Try Again!".$ex;
        die(json_encode($response));
    }
    
    //If we have made it this far without dying, we have successfully added
    //a new user to our database.  We could do a few things here, such as 
    //redirect to the login page.  Instead we are going to echo out some
    //json data that will be read by the Android application, which will login
    //the user (or redirect to a different activity, I'm not sure yet..)
    $response["success"] = 1;
    $response["message"] = "Update successful!";
    echo json_encode($response);
    
    //for a php webservice you could do a simple redirect and die.
    //header("Location: login.php"); 
    //die("Redirecting to login.php");
   	
	
	
}

?>
