<?php

/*
Our "config.inc.php" file connects to database every time we include or require
it within a php script.  Since we want this script to add a new user to our db,
we will be talking with our database, and therefore,
let's require the connection to happen:
*/
require("config.inc.php");

if (!isset($_POST['storeid']))
{
//initial query
$query = "SELECT p.ID, p.post_title, p.post_date , (SELECT guid FROM wp_posts WHERE id = m.meta_value ) AS `imgurl` 
,(SELECT guid FROM wp_posts WHERE id = m2.meta_value ) AS `banner`, pm.meta_value AS seller, pm1.meta_value AS shop_day, pm2.meta_value AS shop_open, pm3.meta_value AS shop_close
FROM wp_posts p left join wp_postmeta m on p.id = m.post_id AND m.meta_key = 'shop_logo' 
 left join wp_postmeta m2 on p.id = m2.post_id AND m2.meta_key = 'shop_slider_image' 
left join wp_postmeta pm on p.ID = pm.post_id and pm.meta_key = 'seller' 
left join wp_postmeta pm1 on p.ID = pm1.post_id and pm1.meta_key = 'shop_open_day'
left join wp_postmeta pm2 on p.ID = pm2.post_id and pm2.meta_key = 'shop_open_hrs'
left join wp_postmeta pm3 on p.ID = pm3.post_id and pm3.meta_key = 'shop_close_hrs'
left join wp_users u on u.id= pm.meta_value 
left join wp_postmeta m1 on p.id = m1.post_id AND m1.meta_key = 'featured' 
where p.post_type='shop' and post_status='publish'
HAVING imgurl is not null Order By p.post_date desc";
}
else
{
	$query = "SELECT ID, p.post_title, p.post_content , (SELECT guid FROM wp_posts WHERE id = m.meta_value ) AS `imgurl` 
FROM wp_posts p left outer join wp_postmeta m on p.id = m.post_id AND m.meta_key = 'shop_slider_image' 
inner join wp_postmeta m1 on p.id = m1.post_id AND m1.meta_key = 'featured' 
where p.post_type='shop'  and post_status='publish' and m1.meta_value = 1  and ID=".$_POST['storeid']."  LIMIT 1";
}
//execute query
try {
    $stmt   = $db->prepare($query);
    $result = $stmt->execute();
}
catch (PDOException $ex) {
    $response["success"] = 0;
    $response["message"] = "Database Error!";
    die(json_encode($response));
}

// Finally, we can retrieve all of the found rows into an array using fetchAll 
$rows = $stmt->fetchAll();


if ($rows) {
    $response["success"] = 1;
    $response["message"] = "Post Available!";
    $response["posts"]   = array();
    
    foreach ($rows as $row) {
        $post             = array();
		$post["post_id"]  = $row["ID"];
        $post["name"] = $row["post_title"];
		$post["imgurl"] = $row["imgurl"]; 
        $post["seller"] = $row["seller"]; 
         $post["banner"] = $row["banner"]; 
		 $post["shop_day"] = $row["shop_day"];
		 $post["shop_open"] = $row["shop_open"];
		 $post["shop_close"] = $row["shop_close"];
       
        //update our repsonse JSON data
        array_push($response["posts"], $post);
    }
    
    // echoing JSON response
    echo json_encode($response);
    
    
} else {
    $response["success"] = 0;
    $response["message"] = "No Post Available!";
    die(json_encode($response));
}

?>
