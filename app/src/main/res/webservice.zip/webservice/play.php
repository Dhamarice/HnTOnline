<?php
//include 'ecash_api.php';
//if(isset($_GET['notify_paid_ecash']))
//{

	//write a file to show that paynow silently visisted us sometime
	file_put_contents('deposit_ecash_visit.txt', date('d m y h:i:s') . ' Ecocash visited us ' . PHP_EOL , FILE_APPEND | LOCK_EX);
		$get_post = file_get_contents('php://input');
	$ecocash_array = json_decode($get_post, TRUE);
	$ecocash_str = json_encode($ecocash_array);
	
	mail('ruvimbom@hammerandtongues.com', 'ECOCASH RESPONSE', $ecocash_str);

	

	//$ecocash_array = json_decode($get_post, TRUE);
	//$referenceCode = $ecocash_array['referenceCode'];
	$amount = $ecocash_array['paymentAmount']['charginginformation']['amount'];
	$transactionOperationStatus = $ecocash_array['transactionOperationStatus'];
	$version = $ecocash_array['version'];
//$response = array();
//$ecocash_response = json_decode($json_raw, TRUE);

//if (preg_match("/SVC0007/i", json_encode($ecocash_response)))
//json_encode($ecocash_array)

echo $get_post;

	if($transactionOperationStatus == "COMPLETED" AND $version == 1 ) {
		
		global $wpdb;
		//$status = $_POST['status'];
		//$amount = $referenceCode;
		$hash = $_GET['myhsh']; 
		
		$hsh_ = get_option('hsh_' . $hash);
		$exp = explode('|', $hsh_);
		
		$uid = $exp[0];
		$datemade = $exp[1];
		
		$op = get_option('Walleto_deposit_'.$uid.$datemade.$exp[2]);
		
		$response["success"] = 1;
    $response["message"] = "Transaction Successful ".$endUserId;
    echo(json_encode($response));
	
	die();
		
		
		//----------------------------------------------------------
	}
//}

	?>