    $query = "select U.display_name,U.user_nicename,U.user_email,Nid.VALUE,Uc.VALUE,Uad.VALUE,Ultn.VALUE,Ucntry.VALUE from wp_users U left join wp_cimy_uef_data Nid on Nid.USER_ID = U.ID 
left join wp_cimy_uef_data Uc on Uc.USER_ID = U.ID 
left join wp_cimy_uef_data Uad on Uad.USER_ID =  U.ID
left join wp_cimy_uef_data Ultn on Ultn.USER_ID = U.ID 
left join wp_cimy_uef_data Ucntry on Ucntry.USER_ID = U.ID
where Nid.FIELD_ID=3 and Uc.FIELD_ID=4 and Uad.FIELD_ID=5 and Ultn.FIELD_ID=6 and Ucntry.FIELD_ID=9 where user_login  = :user ";

//Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':user' => $_POST['username'],
        ':pass' => password_hash($_POST['password'], PASSWORD_BCRYPT),
		':nicename' => $_POST['firstname'] . '_'.$_POST['surname'],
		':email' => $_POST['email'],
		':display' => $_POST['firstname'] . ' '.$_POST['surname'],
		
		 $response["success"] = 1;
    $response["message"] = "details captured";
    echo json_encode($response);