<?php
 
/*
* Database Constants 
*/
$DB_HOST = "196.44.176.187";
$DB_USERNAME = "root";
$DB_PASSWORD = "Hsat@563";
$DB_NAME = "hammeran_shpdb";
 
//Connecting to the database
$con = mysqli_connect ($DB_HOST, $DB_USERNAME, $DB_PASSWORD, $DB_NAME);
 
//checking the successful connection
if($con) {
 //getting the name from request 
 $user_login = $_POST['user_login']; 
 $user_pass = $_POST['user_pass']; 
  $user_nicename = (isset($_POST['user_nicename']) ? $_POST['user_nicename'] : '');   
   $user_email = $_POST['user_email']; 
   $user_url = $_POST['user_url'];
    $user_registered = $_POST['user_registered']; 
	 $user_activation_key = (isset($_POST['user_activation_key']) ? $_POST['user_activation_key'] : '');
	  $user_status = $_POST['user_status']; 
	   $display_name = (isset($_POST['display_name']) ? $_POST['display_name'] : '');
 
 //creating a statement to insert to database 
 $query = "INSERT INTO wp_users( `user_login`, `user_pass`, `user_nicename`, `user_email`,  `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES ( '".$user_login."', '".$user_pass."', '".$user_nicename."', '".$user_email."', '". $user_url."','".$user_registered."', '".$user_activation_key."', '".$user_status."', '". $display_name."')";
 
 $result = mysqli_query ($con, $query);
 $response = array ();
 
 if ($result) {
	 $status = 'OK';
 }
 else
 {
	 $status = 'FAILED';
 }
}
echo json_encode (array ("response"=> $status));

mysqli_close ($con);
?>