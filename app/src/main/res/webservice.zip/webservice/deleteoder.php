<?php
	
require("config.inc.php");
require ("class-phpass.php");
 
 $oderid  = $_POST['oid'];
 $userid =$_POST['userid'];
 
 //******************************************************
//
//	DELETE order
//
//******************************************************
			
   
    $query = "DELETE FROM  `wp_walleto_orders` WHERE uid = :uid  AND paid = 0";
    
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        //':oid' => $oderid,  
        ':uid' => $userid
    );
   
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);

        
        
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!" . $ex;
        die(json_encode($response));
    }
   
	
	//******************************************************
//
//	DELETE order contents
//
//*******************************************************
	
		$query = "DELETE FROM `wp_walleto_order_contents` WHERE uid = :uid   AND paid = 0";
    
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        //':oid' => $oderid,
           ':uid' => $userid
    );
    
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);

    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error2. Please Try Again!: ".$ex;
        die(json_encode($response));
    }

		

//******************************************************
//
//	DELETE Invoice Number
//
//******************************************************

	   $query = "DELETE FROM `wp_walleto_ordermeta` WHERE order_id = :oid ";
    
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':oid' => $oderid, 
    );
   
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
		$invid = $db->lastInsertId();
		
		$response["success"] = 1;
        $response["message"] = "Error occured while processing payment!";
        echo(json_encode($response));
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!" . $ex->getMessage();
        echo(json_encode($response));
    }

?>

