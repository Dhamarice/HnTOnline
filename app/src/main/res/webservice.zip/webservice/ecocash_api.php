<?php
include 'config.inc.php';
if(isset($_REQUEST['endUserId']) && isset($_REQUEST['oid']) && isset($_REQUEST['yes']))
{
    
    
    /** check for error in connection and report error if any */
   

    $order_id = intval(trim($_REQUEST['oid']));
    $cell = '263' . trim($_REQUEST['endUserId']);
    $amt = floatval(trim($_REQUEST['amt']));
    $clientCorrelator = rand().time();
    $myhsh =  intval(trim($_POST['oid']));

    $hash = time() . rand(0, 99);

    $ecocash_url = "https://payonline.econet.co.zw/ecocashGateway-preprod/payment/v1/transactions/amount";
    #$ecocash_url = "https://payonline.econet.co.zw/ecocashGateway/payment/v1/transactions/amount";

    $fields = array(
        'clientCorrelator'             =>  $hash,
        'notifyUrl'                    =>  'https://devshop.hammerandtongues.com/webservice/newEcoResp.php?notify_paid_ecash=1&myhsh=' . $order_id,
        'referenceCode'                =>  $order_id,
        'endUserId'                    =>  $cell,
        'transactionOperationStatus'   =>  'CHARGED',
        'paymentAmount'                 =>  array(
            'charginginformation'           =>  array(
                'amount'                        => $amt,
                'currency'                      => 'USD',
                'description'                   => 'Eletronic Transfer'
            ),
            'chargeMetaData'                => array(
                'channel'                       => 'WEB',
                'purchaseCategoryCode'          => 'Online Voucher Sell',
                'onBeHalfOf'                    => 'HNT Shopping Mall'
            )
        ),
        'merchantCode'                  => '37252',
        'merchantPin'                   => '5684',
        'merchantNumber'                => '771991902',
        	"referenceCode" => "REF - $clientCorrelator",
			
    );

 
    $execute = curl_init();
    $params = json_encode($fields);
    curl_setopt($execute, CURLOPT_URL, $ecocash_url);
    curl_setopt($execute, CURLOPT_POST, TRUE);
    curl_setopt($execute, CURLOPT_POSTFIELDS, $params);
    curl_setopt($execute, CURLOPT_HEADER, FALSE);
    curl_setopt($execute, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($execute, CURLOPT_HTTPAUTH, CURLAUTH_BASIC ) ; 
    curl_setopt($execute, CURLOPT_USERPWD,"hammer:#t0ngu3$");
    curl_setopt($execute, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($execute, CURLOPT_ENCODING, "");	
    //curl_setopt($execute, CURLOPT_SSL_VERIFYHOST, 2); 
    curl_setopt($execute, CURLOPT_SSL_VERIFYPEER, FALSE); // uncomment this line if you get no gateway response.
    
   	$json_raw = curl_exec($execute); // execute curl post and store results in $json_raw
   	//$info = curl_get_info($execute);
   	
   	//mail('ruvimbom@hammerandtongues.com', 'RESPONSE MOBILE APP', implode('|||', $info));
	
curl_close ($execute); // close curl object

	


// This line takes the response and breaks it into an array using the specified delimiting character

$ecocash_response = json_decode($json_raw, TRUE);
/*print_r($ecocash_response); die;*/
if (preg_match("/SVC0007/i", json_encode($ecocash_response))) {
    //Invalid number
	
	$response["success"] = 0;
    $response["message"] = "Invalid number ".$endUserId;
    echo json_encode($response);
    
	} elseif (preg_match("/SVC0270/i", json_encode($ecocash_response))){
    //Valid number but failed. This might be because customer does not have enough funds 	
	$response["success"] = 0;
    $response["message"] = "Insufficient Funds";
    echo json_encode($response);
    
	} 

	 else{
	
	
	sleep(10);
	
	
	    $tm = $_SERVER['REQUEST_TIME'] ;
		$query = "Update `wp_walleto_order_contents` set paid = 1, paid_on = :dt where orderid = :oid  ";
    
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':oid' => $order_id, 
		':dt' => $tm,
    );
   
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
        
        	mail('ruvimbom@hammerandtongues.com', 'ECOCASH RESPONSE', 'Order status updated!'.$Oid);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        echo "Failed To Update Order Status";
    }
	
	
	
	
	
$response["success"] = 1;
    $response["message"] = "Success, PENDING SUBSCRIBER VALIDATION".implode('|||', $ecocash_response);
    echo json_encode($response);
    
    
}
}

	
?>