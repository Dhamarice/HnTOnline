<?php

//load and connect to MySQL database stuff
require("devconfig.inc.php");
require ("class-phpass.php");

//include_once($_SERVER['DOCUMENT_ROOT'].'/wp-includes/class-phpass.php' );
if (! empty($_POST['username']))
{

    //gets user's info based off of a username.
    $query = "SELECT u.id, u.user_email, u.user_nicename, ifnull(uefd1.value,'') as cellno, CONCAT(uefd2.value , ', ',uefd3.value) as add1, uefd4.value as country, uefd5.value as province, u.user_pass, um.meta_value as 'balance', um1.meta_value as level, um2.meta_value as loyalty_points
FROM wp_users u 
left join `wp_cimy_uef_data` uefd1 on uefd1.user_id = u.ID  and uefd1.FIELD_ID=4
left join `wp_cimy_uef_data` uefd2 on uefd2.user_id = u.ID and uefd2.FIELD_ID=5
left join `wp_cimy_uef_data` uefd3 on uefd3.user_id = u.ID and uefd3.FIELD_ID=6
left join `wp_cimy_uef_data` uefd4 on uefd4.user_id = u.ID and uefd4.FIELD_ID=9
left join `wp_cimy_uef_data` uefd5 on uefd5.user_id = u.ID and uefd5.FIELD_ID=11
left JOIN wp_usermeta um on u.ID=um.user_id and um.meta_key='credits'
left Join wp_usermeta um1 on  u.ID=um1.user_id and um1.meta_key='byr_rwd_lvl'
left Join wp_usermeta um2 on  u.ID=um2.user_id and um2.meta_key='loyalty_points'
where user_login  = :username ";
    
    $query_params = array(
        ':username' => $_POST['username']
    );
    
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one to product JSON data:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again! ".$ex;
       die (json_encode($response));
        
    }
    
    //This will be the variable to determine whether or not the user's information is correct.
    //we initialize it as false.
    $validated_info = false;
    
    //fetching all the rows from the query
    $row = $stmt->fetch();
    if ($row) {
        //if we encrypted the password, we would unencrypt it here, but in our case we just
        //compare the two passwords
		
$hasher = new PasswordHash(8, TRUE);

	
if (! empty($_POST['password']))
{
// compare plain password with hashed password
if ($hasher->CheckPassword( $_POST['password'], $row['user_pass'] )){        
         $response["success"] = 1;
        $response["message"] = "Login successful!";
		
		//echo json_encode($response);
				   
   $response["posts"]   = array();
    
    
        $post             = array();
		$post["id"]  = $row["id"];
        $post["uname"] = $row["user_nicename"]; 
        $post["umail"] = $row["user_email"]; 
		$post["add"] = $row["add1"]; 
		$post["province"] = $row["province"];
		$post["country"] = $row["country"];
		$post["balance"] = $row["balance"]; 
		$post["level"] = $row["level"];
		$post["loyalty_points"] = $row["loyalty_points"];
        
        //update our repsonse JSON data
        array_push($response["posts"], $post);
	
        echo json_encode($response);
    } else {
        $response["success"] = 0;
        $response["message"] = "Incorrect Password!";
        die (json_encode($response));
    }
 }
	}
	
	else {
        $response["success"] = 0;
        $response["message"] = "Incorrect username!";

        die (json_encode($response));
 }
}
 else {
        $response["success"] = 0;
        $response["message"] = "empty Credentials!";

        die (json_encode($response));
 }

?> 
