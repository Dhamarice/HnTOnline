<?php

require("config.inc.php");

//initial query
$query = "UPDATE TABLE wp_walleto_variations_content SET  quant = quant - :PQUANT WHERE pid = :PID";
  //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':PQUANT' => $_REQUEST['qnty'],
		':PID' => $_REQUEST['productid'],
    );            
          
    
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
		
		
    
    // echoing JSON response
    echo json_encode($response);
	$response["success"] = 1;
    $response["message"] = "Quantity subtracted!";
    }
catch (PDOException $ex) {
    $response["success"] = 0;
    $response["message"] = "Subtract stock Database Error!".$stmt;
    die(json_encode($response));
}


?>
