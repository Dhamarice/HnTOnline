<?php

/*
Our "config.inc.php" file connects to database every time we include or require
it within a php script.  Since we want this script to add a new user to our db,
we will be talking with our database, and therefore,
let's require the connection to happen:
*/
require("config.inc.php");

if ( $_POST['storeid'])
{
//initial query
$query = "Select distinct pr.ID, pr.post_title, pr.post_content, pr_p.meta_value as price, (SELECT guid FROM wp_posts pimg WHERE pimg.id = m.meta_value ) AS `imgurl` from wp_posts pr inner join wp_postmeta pr_m on pr.ID=pr_m.post_id inner join wp_postmeta pr_p on pr.ID=pr_p.post_id inner join wp_postmeta m on pr.ID=m.post_id AND m.meta_key = '_thumbnail_id' where pr_m.meta_key='seller' and pr_p.meta_key='price' and pr.post_status='publish' And pr_m.meta_value=(SELECT sr_m.meta_value FROM `wp_posts` sr inner join wp_postmeta sr_m on sr.id=sr_m.post_id where id = ".$_POST['storeid']." and sr_m.meta_key='seller' limit 1) LIMIT 100  ";
}
else if ( $_POST['cartprdcts'])
{
	$query = "Select distinct pr.ID, pr.post_title, pr.post_content, pr_p.meta_value as price, (SELECT guid FROM wp_posts pimg WHERE pimg.id = m.meta_value ) AS `imgurl` from wp_posts pr inner join wp_postmeta pr_m on pr.ID=pr_m.post_id inner join wp_postmeta pr_p on pr.ID=pr_p.post_id inner join wp_postmeta m on pr.ID=m.post_id AND m.meta_key = '_thumbnail_id' where pr_m.meta_key='seller' and pr_p.meta_key='price' and pr.post_status='publish' And pr_m.meta_value=(SELECT sr_m.meta_value FROM `wp_posts` sr inner join wp_postmeta sr_m on sr.id=sr_m.post_id where id in ( ".$_POST['cartprdcts'].") and sr_m.meta_key='seller' limit 1) LIMIT 100  ";
}
//execute query
try {
    $stmt   = $db->prepare($query);
    $result = $stmt->execute();
}
catch (PDOException $ex) {
    $response["success"] = 0;
    $response["message"] = "Database Error!";
    die(json_encode($response));
}

// Finally, we can retrieve all of the found rows into an array using fetchAll 
$rows = $stmt->fetchAll();


if ($rows) {
    $response["success"] = 1;
    $response["message"] = "Post Available!";
    $response["posts"]   = array();
    
    foreach ($rows as $row) {
        $post             = array();
		$post["post_id"]  = $row["ID"];
        $post["name"] = $row["post_title"]; 
        $post["imgurl"] = $row["imgurl"]; 
		$post["price"] = $row["price"]; 
        
        //update our repsonse JSON data
        array_push($response["posts"], $post);
    }
    
    // echoing JSON response
    echo json_encode($response);
    
    
} else {
    $response["success"] = 0;
    $response["message"] = "No Post Available!";
    die(json_encode($response));
}

?>
