<?php

/**
 * Send an sms
 * @param string $cell cell number
 * @param string $message message body
 * @return boolean return true if successful
 */
   //session_start();
 require("devconfig.inc.php");

  
  function send_sms($sender,$cell,$message)
{
	//$sender = 'HTAH';
	
    $user = 'calvinm';
    $pass = 'h4mm3r';
	//$message = 'Your verification code is' + $code;
	//$cell = isset($_POST['telno']);
    
    $url = "http://api.infobip.com/api/v3/sendsms/plain?user=".$user."&password=".$pass."&sender=" . $sender . "&SMSText=".urlencode($message)."&GSM=". $cell ."&type=longSMS"; 
    $answer = file_get_contents($url);
    return $answer; 
	 //var_dump(parse_url($url));
}

    $code = mt_rand(1000, 9999); // if not set define a new number between 1 and 100
//$code = $_SESSION['startNum'];

if (isset($_REQUEST['telno'])) {
    $telno = $_REQUEST['telno'];
}

 
  
   $query        = " SELECT 1 FROM wp_users WHERE mobile_number = :mobile";
    //now lets update what :user should be
    $query_params = array(
        ':mobile' => $telno
    );
    
    //Now let's make run the query:
    try { 
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!";
        die(json_encode($response));
    }
    
    $row = $stmt->fetch();
    if ($row) {
        
        //You could comment out the above die and use this one:
        $response["success"] = 0;
        $response["message"] = "Sorry, this mobile number is already in use";
        die(json_encode($response));
	}
	
  
  
   else {   $query = "INSERT INTO `wp_users`( `mobile_number`, `verify_code`) VALUES ( :mobile, :code) ";
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':mobile' => $telno,
        ':code' => $code
		
		
		
    );
    
	 send_sms('HTAH', $telno, "Your verification code is $code");
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        //$response["success"] = 0;
        //$response["message"] = "Database Error2. Please Try Again!";
        //die(json_encode($response));
    }
 
 $response["success"] = 1;
        $response["message"] = "code sent";
		echo(json_encode($response));
   }

?>

