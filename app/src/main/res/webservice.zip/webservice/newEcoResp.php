<?php
include 'config.inc.php';
//ini_set("allow_url_fopen", 1);
/** check for error in connection and report error if any */


if(isset($_GET['notify_paid_ecash']))
{
    $post = file_get_contents('php://input');
    $response = json_decode($post, TRUE);
    file_put_contents('deposit_ecash_visit.txt', date('d m y h:i:s') . ' Ecocash visited us ' . implode('|||', $response) . PHP_EOL , FILE_APPEND | LOCK_EX);
    $amount = $response['paymentAmount']['charginginformation']['amount'];
    $status = $response['transactionOperationStatus'];
    $Oid = $_GET['myhsh'];
    $version = $response['version'];
    //mail('ekamundaranga@hammerandtongues.com', 'RESPONSE MOBILE APP', implode('|||', $response));
    mail('ruvimbom@hammerandtongues.com', 'RESPONSE MOBILE APP', implode('|||', $response));
    
    $tm = $_SERVER['REQUEST_TIME'] ;
		$query = "Update `wp_walleto_order_contents` set paid = 1, paid_on = :dt where orderid = :oid  ";
    
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':oid' => $Oid, 
		':dt' => $tm,
    );
   
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
        
        	mail('ruvimbom@hammerandtongues.com', 'ECOCASH RESPONSE', 'Order status updated!'.$Oid);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        echo "Failed To Update Order Status";
    }
	
	
	}
?>