<?php

/*
Our "config.inc.php" file connects to database every time we include or require
it within a php script.  Since we want this script to add a new user to our db,
we will be talking with our database, and therefore,
let's require the connection to happen:
*/
require("config.inc.php");
if (isset( $_POST['type']))
{
	 
if ($_POST['type'] =="Province")
//initial query
$query = "SELECT id, rgn_name as name from  `wp_walleto_regions`  ";

if ($_POST['type'] =="City")
//initial query
$query = "SELECT id, cty_name as name from  `wp_walleto_cities` where rgn_id=(select id from`wp_walleto_regions` where rgn_name= :val ) ";


if ($_POST['type'] =="Surburb")
//initial query
$query = "SELECT id, sbrb_name as name from  `wp_walleto_suburb` where cty_id=(select id from`wp_walleto_cities` where cty_name= :val ) ";

if ($_POST['type'] =="DlvryChrg")
//initial query
$query = "SELECT wz . * FROM `wp_walleto_zones` wz
INNER JOIN `wp_walleto_zones_sbrbs` wzs ON wz.id = wzs.zne_id
INNER JOIN `wp_walleto_suburb` ws ON wzs.sbrb_id = ws.id
WHERE sbrb_name = :val
LIMIT 1";

//query parameters
 $query_params = array(
        ':val' =>  $_POST['value'],
    );
    
	
//execute query
try {
    $stmt   = $db->prepare($query);
    $result = $stmt->execute($query_params);
}
catch (PDOException $ex) {
    $response["success"] = 0;
    $response["message"] = "Database Error!".$ex;
    die(json_encode($response));
}

// Finally, we can retrieve all of the found rows into an array using fetchAll 
$rows = $stmt->fetchAll();


if ($rows) {
    $response["success"] = 1;
    $response["message"] = "Post Available!";
    $response["posts"]   = array();
    
    foreach ($rows as $row) {
 
if ($_POST['type'] !="DlvryChrg")
{
       $post             = array();
		$post["id"]  = $row["id"];
        $post["name"] = $row["name"];      
        //update our repsonse JSON data
        array_push($response["posts"], $post);
}
else
{
	
	$points = json_decode( $row["zne_charge"], true);
	
		 
        $post             = array();
		$post["dlvrychrges"] = $points;
		
        //update our repsonse JSON data
        array_push($response["posts"], $post);}
        
    
    }
    
    // echoing JSON response
    echo json_encode($response);
    
    
} else {
    $response["success"] = 0;
    $response["message"] = "No Post Available! 113010";
    die(json_encode($response));
}
}
?>
