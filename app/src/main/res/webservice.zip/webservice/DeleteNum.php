<?php
require("devconfig.inc.php");
 $query = "DELETE FROM `wp_users` WHERE mobile_number = :userid";
   // $hasher->CheckPassword( $_POST['password']
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':userid' => $_POST['telno'],
		
		
    );
    
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        die("Failed to run query: " . $ex->getMessage());
        
       
    }
    
   
    $response["success"] = 1;
    $response["message"] = "Number deleted!";
    echo json_encode($response);
   ?> 