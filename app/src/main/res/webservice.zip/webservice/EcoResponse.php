<?php
require("config.inc.php");

$tm 		= $_SERVER['REQUEST_TIME'] ;

if(isset($_GET['notify_paid_ecash']))
	{
		GetResponse($db, $tm, $_POST['oid']);
	}
//if(isset($_POST['endUserId']) && isset($_POST['oid']) && isset($_POST['yes'])  && isset($_POST['amt'])) :
 
 
$orderId =   intval(trim($_POST['oid']));
$endUserId = intval(trim($_POST['endUserId']));
$total = $_POST['amt'];


	//write a file to show that paynow silently visisted us sometime
	file_put_contents('deposit_ecash_visit.txt', date('d m y h:i:s') . ' Ecocash visited us ' . PHP_EOL , FILE_APPEND | LOCK_EX);
	$get_post = file_get_contents('php://input');

	 //$url = "http://api.infobip.com/api/v3/sendsms/plain?user=".$user."&password=".$pass."&sender=" . $sender . "&SMSText=".urlencode($message)."&GSM=". $cell ."&type=longSMS"; 
	
	$ecocash_status = "https://payonline.econet.co.zw/ecocashGateway-preprod/payment/v1/{".$endUserId."}/transactions/amount{".$clientCorrelator."}";
	$ecocash_array = json_decode($get_post, TRUE);
	//$referenceCode = $ecocash_array['referenceCode'];
	$amount = $ecocash_array['paymentAmount']['charginginformation']['amount'];
	$transactionOperationStatus = $ecocash_array['transactionOperationStatus'];
	$version = $ecocash_array['version'];
	
	
	
	
	
	
	$clientCorrelator = rand().time();
$amount = $total;
//$endUserId = $_GET['endUserId'];
//$mcht_code = get_option('Walleto_ecash_mcode', $db);
//$mcht_pin = get_option('Walleto_ecash_mpin', $db);
//$mcht_num = get_option('Walleto_ecash_mnum', $db);

$myhsh =  intval(trim($_POST['oid']));
$notify_url = 'https://dev.hammerandtongues.com/shop/webservice/EcoResponse/?notify_paid_ecash=1&myhsh=' . $myhsh;

 
$ecocash_values = array(
	
					"clientCorrelator" => "$clientCorrelator",
					"endUserId" => "+263$endUserId",
						"merchantCode" => "37252",
					"merchantPin" => "5684",
					"merchantNumber" => "+263771991902",
					"notifyUrl" => "$notify_url",
					"paymentAmount" => array(
									   		 "charginginformation" => array(
											 					   	  		"amount" => "$amount",
											 								"currency" => "USD",
											 								"description" => "HAMMER AND TONGUES MALL SITE ORDER"
											 								),
											 "chargeMetaData" => array(
									   	  						   		 "onBeHalfOf" => "H&T",
																		 "purchaseCategoryCode" => "HnT Mall",
																		 "channel" => "HTTP"
																		 
								   		   	  							 )
											),
				"referenceCode" => "REF - $clientCorrelator",
				"transactionOperationStatus" => "Charged",
				

);

// Takes the input fields and turn them into the appropriate format
// for an https post. E.g: "merchantCode=02273&merchantPin=1357"
$ecocash_string = json_encode($ecocash_values);

// The CURL library for php is used to establish a connection,
// submit the post, and record the response.
// Ensure that you have the curl library enabled in your php configuration
$request = curl_init($ecocash_status); // initiate curl object
	curl_setopt($request, CURLOPT_HEADER, 0); // set to 0 to eliminate header info from response
	curl_setopt($request, CURLOPT_RETURNTRANSFER, 1); // Returns response data instead of TRUE(1)
	curl_setopt($request, CURLOPT_HTTPAUTH, CURLAUTH_BASIC ) ; 
	curl_setopt($request, CURLOPT_USERPWD,"hammer:#t0ngu3$");
	curl_setopt($request, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
	curl_setopt($request, CURLOPT_ENCODING, "");	
	curl_setopt($request, CURLOPT_SSL_VERIFYHOST, 2); 
	curl_setopt($request, CURLOPT_RETURNTRANSFER, true); 
	curl_setopt($request, CURLOPT_POSTFIELDS, $ecocash_string); // use HTTP POST to send form data
	curl_setopt($request, CURLOPT_SSL_VERIFYPEER, FALSE); // uncomment this line if you get no gateway response.
	curl_setopt($request, CURLOPT_URL, $ecocash_status); 

	$json_raw = curl_exec($request); // execute curl post and store results in $json_raw
	
curl_close ($request); // close curl object



$request = curl_init($notify_url); // initiate curl object
	curl_setopt($request, CURLOPT_HEADER, 0);
	curl_setopt($request, CURLOPT_RETURNTRANSFER, 1); // Returns response data instead of TRUE(1)
		$json_raw = curl_exec($request); // execute curl post and store results in $json_raw
	
curl_close ($request); // close curl object

echo $json_raw;


// This line takes the response and breaks it into an array using the specified delimiting character

$ecocash_response = json_decode($json_raw, TRUE);
	
	
	
	
	
	
	
	

	if($transactionOperationStatus == "COMPLETED" AND $version == 1) {
		
		global $wpdb;
		//$status = $_POST['status'];
		//$amount = $referenceCode;
		$hash = $_GET['myhsh']; 
		
		$hsh_ = get_option('hsh_' . $hash);
		$exp = explode('|', $hsh_);
		
		$uid = $exp[0];
		$datemade = $exp[1];
		
		$op = get_option('Walleto_deposit_'.$uid.$datemade.$exp[2]);
		
		$response["success"] = 1;
    $response["message"] = "Transaction Successful ".$endUserId;
    echo(json_encode($response));
		
		
		//----------------------------------------------------------

		
}

else {
			$response["success"] = 0;
    $response["message"] = "Transaction not completed ".$endUserId;
    echo(json_encode($response));
	
}
die();

//else:
//$response["success"] = 0;
//    	$response["message"] = "Insufficient Posts".$endUserId;
//        die( json_encode($response)); 

//endif;

	?>