<?php
if(isset($_POST['endUserId']) && isset($_POST['am']) && isset($_POST['endUserotp']) && isset($_POST['yes'])) :

$amount = floatval(trim($_POST['am']));
$endUserId = intval(trim($_POST['endUserId']));
$endUserotp = intval(trim($_POST['endUserotp']));

$mcht_username = get_option('Walleto_tcash_musername');
$mcht_pid = get_option('Walleto_tcash_pid');
$mcht_pass = get_option('Walleto_tcash_pass');
$mcht_enckey = get_option('Walleto_tcash_enckey');

$reqID =  'hsh'.time().rand(0,9999);


global $current_user;
get_currentuserinfo();
$uid = $current_user->ID;
 
update_option($reqID, $uid.'|'.time().'|'.$amount);

/* Creating Request For TeleCash  */
//$url = "http://testonlinepay.telecel.co.zw/ObopayExternalWS/ObopayExternalWebServiceV1?WSDL";
$url = "http://liveonlinepay.telecel.co.zw/ObopayExternalWS/ObopayExternalWebServiceV1?WSDL";
$client = new SoapClient($url);
$header_part = '
    <obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="UserName">'.$mcht_username.'</obons:header> 
  <obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="Password">'.$mcht_pass.'</obons:header> 
  <obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="PartnerId">'.$mcht_pid.'</obons:header> 
  <obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="iv">'.$mcht_enckey.'</obons:header>
';
$soap_var_header = new SoapVar( $header_part, XSD_ANYXML, null, null, null );
$soap_header = new SoapHeader( 'http://www.obopay.com/xml/ns/tpu/v1', 'obons', $soap_var_header );
$client->__setSoapHeaders($soap_header);
$client->__setLocation('http://liveonlinepay.telecel.co.zw/ObopayExternalWS/ObopayExternalWebServiceV1');

$result = $client->process(array('request'=>array('encoding'=>'UTF-8',
    'ApiIdType' => 'REQ',
                'Tier3AgentId' => $mcht_username,  
                'CustomerPhoneNumber' => '263'.$endUserId,  
                'TransactionType' => '500',  
                'InstrumentType' => '1', 
                'ProcessorCode' => '0026', 
                'PaymentDetails1' => $endUserotp,
                'TxnAmount' => $amount,  
                'CurrencyType' => 'USD', 
                'FeeAmount' => 20, 
                'TaxAmount' => 10,
                'RequestId' => $reqID,  
                'TerminalID' => '123', 
                'Reference1' => 'ONUS',
                'Reference2' => 'CARDLESS'
    )));

if ($result->return->Remark == "Success") {
	$hash = $result->return->RequestId;	
	$hsh_ = get_option($hash);
	delete_option($hash);
	$exp = explode('|', $hsh_);	
	$uid = $exp[0];
	$datemade = $exp[1];
	$amount = $exp[2];
	$settle_amt = (float)str_replace(",", "", $amount);
	/*********
	SETTLEMENT OF TRANACTION STARTS
	*********/
	$mcht_username = get_option('Walleto_tcash_musername');
	$mcht_pid = get_option('Walleto_tcash_pid');
	$mcht_pass = get_option('Walleto_tcash_pass');
	$mcht_enckey = get_option('Walleto_tcash_enckey');
	$ops_trnx_id = $result->return->OpsTransactionId;
	$pay_details_1 = date("dmY", $datemade)."MC".$mcht_username."_".rand(1,9999);	
	
	//$url = "http://testonlinepay.telecel.co.zw/ObopayExternalWS/ObopayExternalWebServiceV1?WSDL";
	$url = "http://liveonlinepay.telecel.co.zw/ObopayExternalWS/ObopayExternalWebServiceV1?WSDL";
	$client = new SoapClient($url);

	$header_part = '
		<obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="UserName">'.$mcht_username.'</obons:header> 
	  <obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="Password">'.$mcht_pass.'</obons:header> 
	  <obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="PartnerId">'.$mcht_pid.'</obons:header> 
	  <obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="iv">'.$mcht_enckey.'</obons:header>
	';
	$soap_var_header = new SoapVar( $header_part, XSD_ANYXML, null, null, null );
	$soap_header = new SoapHeader( 'http://www.obopay.com/xml/ns/tpu/v1', 'obons', $soap_var_header );
	$client->__setSoapHeaders($soap_header);
	$client->__setLocation('http://liveonlinepay.telecel.co.zw/ObopayExternalWS/ObopayExternalWebServiceV1');
	$reqID =  'hsh'.time().rand(0,9999);
	$results = $client->process(array('request'=>array('encoding'=>'UTF-8',
		'ApiIdType' => 'REQ',  
					'Tier3AgentId' => $mcht_username, 
					'TransactionType' => '503',  
					'InstrumentType' => '1', 
					'ProcessorCode' => '0029', 
					'PaymentDetails1' => $pay_details_1,
					'PaymentDetails2' => $ops_trnx_id."|".$settle_amt,
					'RequestId' => $reqID,  
					'TerminalID' => '123', 
					'Reference1' => 'ONUS',
					'Reference2' => 'CARDLESS'
		)));		
		
	/*********
	SETTLEMENT OF TRANACTION ENDS
	*********/
	
	$op = get_option('Walleto_deposit_'.$uid.$datemade);
	//----------------------------------------------------------
	
	if($op != "1")
	{
		$mc_gross = (float)str_replace(",", "", $amount);
		$amt_show = Walleto_get_show_price($mc_gross);
		
		$cr = Walleto_get_credits($uid);
		Walleto_update_credits($uid, $mc_gross + $cr);

		// H&T BANK UPDATE
		$bk_cr = Walleto_get_credits(87);
		Walleto_update_credits(87, $bk_cr + $mc_gross);			

		$usrobj = get_user_by('id', $uid);
		$admin_email = get_option( 'admin_email' );								
		
		$reason = __("Deposit through TeleCash.","Walleto"); 			
		$message = __('Hi '.$usrobj->user_login.PHP_EOL.PHP_EOL.'Your account has been credited with '.$mc_gross.PHP_EOL.'You can log on to our website for further process.','Walleto');
		$adm_message = __('Hi Administrator'.PHP_EOL.PHP_EOL.$usrobj->user_login.' has deposited '.$amt_show.' amount via TeleCash payment method'.PHP_EOL,'Walleto');
		Walleto_send_email($usrobj->user_email, $reason, $message);
		Walleto_send_email($admin_email, "USER DEPOSIT", $adm_message);

		// H&T BANK UPDATE
		$bk_reason = __("USER DEPOSIT via TeleCash.","Walleto"); 			
		Walleto_add_history_log('1', $bk_reason, $mc_gross, 87);
		
		update_option('Walleto_deposit_'.$uid.$datemade, "1");
		$reason = __("Deposit through TeleCash.","Walleto"); 
		Walleto_add_history_log('1', $reason, $mc_gross, $uid);
		
		/*SMS*/
		$tel = $userTel = 0;
		$userTel = get_cimyFieldValue($uid, "TELEPHONE");
		$userTel = cimy_uef_sanitize_content($userTel);
		$userTel = intval($userTel);
		// COUNTRY TELEPHONE CODE
		$userCountry = get_cimyFieldValue($uid, "COUNTRY");
		$userCountry = cimy_uef_sanitize_content($userCountry);
		$tel = wl_get_ctry_dcode($userCountry);
		$tel .= $userTel;
		$msg = __("your payment of ".$mc_gross." through TeleCash has been deposited to your ewallet. Thanks HT team", "Walleto");
		Walleto_send_sms($tel, $msg);				
		/*SMS*/
		
		$re_url = add_query_arg('st','1', get_permalink(get_option('Walleto_my_account_my_finances_page_id')));
		wp_redirect($re_url);
		exit;
	}
} else {
	$re_url = add_query_arg('fst','1', get_permalink(get_option('Walleto_my_account_my_finances_page_id')));
	wp_redirect($re_url);
	exit;
}
die();
endif;

//==========================

get_header();
$amount = (float)$_GET['am'];
?>
<div id="content">
<div class="clear10"></div>

	
			<div class="my_box3">
            
            	<div class="box_title"><?php echo __("Mobile Verification",'Walleto'); ?></div>
                <div class="box_content">   
               <?php
			   
	 
			   echo sprintf(__("You are about to pay. Please fill your mobile number associated with your account.",'Walleto'));
			   echo "<p><small>".sprintf(__("Please do not mention +263 while entering mobile number below.",'Walleto'))."</small><br />";
			   echo "<small>".sprintf(__("You would be required to generate OTP via your registered mobile number with TeleCash. Please mention OTP below.",'Walleto'))."</small>";
			   echo "</p>";
			   ?>
               <div class="clear10"></div>
               
               <form method="post" enctype="application/x-www-form-urlencoded"> 
			   <?php _e("Mobile Number","Walleto"); ?>:+263:
			   <input type="number" class="do_input" size=10 name="endUserId" value="" required />
			   <br/><br/>
			   <?php _e("OTP","Walleto"); ?>:
			   <input type="password" class="do_input" size=6 name="endUserotp" value="" required />
			   <input type="hidden" value="<?php echo $amount; ?>" name="am" />
			   <br/><br/>
               <input type="submit" name="yes" value="<?php _e("Proceed Now",'Walleto'); ?>" />               
                
               </form>
    </div>
			</div>
			
        
        
        <div class="clear100"></div>
            
</div>
<?php
echo Walleto_get_users_links();
get_footer();

?>