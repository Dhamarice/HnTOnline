<?php

//load and connect to MySQL database stuff
require("devconfig.inc.php");

//include_once($_SERVER['DOCUMENT_ROOT'].'/wp-includes/class-phpass.php' );


    //gets user's info based off of a username.
    $query = "SELECT meta_value as 'user_level' FROM wp_usermeta where user_id  = :USER_ID and meta_key='byr_rwd_lvl'";
    
    $query_params = array(
        ':USER_ID' => $_POST['userid']
    );
    
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one to product JSON data:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!";
       die (json_encode($response));
        
    }
    
    
    //fetching all the rows from the query
    $row = $stmt->fetch();
    if ($row) {
        //if we encrypted the password, we would unencrypt it here, but in our case we just
        //compare the two passwords

	

// compare plain password with hashed password
if ($row['user_level'] == "Gold" || $row ['user_level'] == "Silver" ||$row ['user_level'] == "Platinum" ){        
         $response["success"] = 1;
        $response["levelmessage"] = "COD approved!";
		echo json_encode($response);
				   
    } else {
        $response["success"] = 0;
        $response["levelmessage"] = "Invalid user level!";
        die (json_encode($response));
    }
	}
	
	else {
        $response["success"] = 0;
        $response["levelmessage"] = "Invalid user level!";

        die (json_encode($response));
 }
 
?> 
