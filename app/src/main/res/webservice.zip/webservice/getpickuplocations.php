<?php
 
require("config.inc.php");
if (isset( $_POST['city']))
{
//initial query
$query = "SELECT cltn_pnts from  `wp_walleto_cities` where cty_name= :cty";

//query parameters
 $query_params = array(
        ':cty' =>  $_POST['city'],
    );
    
//execute query
try {
    $stmt   = $db->prepare($query);
    $result = $stmt->execute($query_params);
}
catch (PDOException $ex) {
    $response["success"] = 0;
    $response["message"] = "Database Error!";
    die(json_encode($response));
}

// Finally, we can retrieve all of the found rows into an array using fetchAll 
$rows = $stmt->fetchAll();


if ($rows) {
    $response["success"] = 1;
    $response["message"] = "Post Available!";
    $response["posts"]   = array();
    
    foreach ($rows as $row) {
	$points = unserialize( $row["cltn_pnts"]);
	/*		print_r($points);
		die;
		*/
		if ($points)
		foreach ($points as $pnt)
		{
        $post             = array();
		$post["shop"]  = $pnt[0];
        $post["chrge"] = $pnt[1];
		
        //update our repsonse JSON data
        array_push($response["posts"], $post);}
        
    }
    
    // echoing JSON response
    echo json_encode($response);
    
    
} else {
    $response["success"] = 0;
    $response["message"] = "No Post Available! 113010";
    die(json_encode($response));
}
}