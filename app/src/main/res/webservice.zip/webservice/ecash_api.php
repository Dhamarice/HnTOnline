<?php

require("config.inc.php");

$tm 		= $_SERVER['REQUEST_TIME'] ;

if(isset($_GET['notify_paid_ecash']))
	{
		GetResponse($db, $tm, $_POST['oid']);
	}
if(isset($_POST['endUserId']) && isset($_POST['oid']) && isset($_POST['yes'])  && isset($_POST['amt'])) :
 
 
$orderId =   intval(trim($_POST['oid']));
$endUserId = intval(trim($_POST['endUserId']));
$total = $_POST['amt'];
	


	 //-------------------------------------------------
	 
	 // Test url is “https://payonline.econet.co.zw/ecocashGateway-preprod/payment/v1/transactions/amount 

 $ecocash_url = "https://payonline.econet.co.zw/ecocashGateway-preprod/payment/v1/transactions/amount";
 #$ecocash_url = "https://payonline.econet.co.zw/ecocashGateway/payment/v1/transactions/amount";
 
 //0776214825

$clientCorrelator = rand().time();
$amount = $total;
//$endUserId = $_GET['endUserId'];
$mcht_code = get_option('Walleto_ecash_mcode', $db);
$mcht_pin = get_option('Walleto_ecash_mpin', $db);
$mcht_num = get_option('Walleto_ecash_mnum', $db);

$myhsh =  intval(trim($_POST['oid']));
$notify_url = 'https://dev.hammerandtongues.com/shop/webservice/?notify_paid_ecash=1&myhsh=' . $myhsh;

 
$ecocash_values = array(
	
					"clientCorrelator" => "$clientCorrelator",
					"endUserId" => "+263$endUserId",
					"merchantCode" => "$mcht_code",
					"merchantPin" => "$mcht_pin",
					"merchantNumber" => "+263$mcht_num",
					"notifyUrl" => "$notify_url",
					"paymentAmount" => array(
									   		 "charginginformation" => array(
											 					   	  		"amount" => "$amount",
											 								"currency" => "USD",
											 								"description" => "HAMMER AND TONGUES MALL SITE ORDER"
											 								),
											 "chargeMetaData" => array(
									   	  						   		 "onBeHalfOf" => "H&T",
																		 "purchaseCategoryCode" => "HnT Mall",
																		 "channel" => "HTTP"
																		 
								   		   	  							 )
											),
				"referenceCode" => "REF - $clientCorrelator",
				"transactionOperationStatus" => "Charged",
				

);

// Takes the input fields and turn them into the appropriate format
// for an https post. E.g: "merchantCode=02273&merchantPin=1357"
$ecocash_string = json_encode($ecocash_values);

// The CURL library for php is used to establish a connection,
// submit the post, and record the response.
// Ensure that you have the curl library enabled in your php configuration
$request = curl_init($ecocash_url); // initiate curl object
	curl_setopt($request, CURLOPT_HEADER, 0); // set to 0 to eliminate header info from response
	curl_setopt($request, CURLOPT_RETURNTRANSFER, 1); // Returns response data instead of TRUE(1)
	curl_setopt($request, CURLOPT_HTTPAUTH, CURLAUTH_BASIC ) ; 
	curl_setopt($request, CURLOPT_USERPWD,"hammer:#t0ngu3$");
	curl_setopt($request, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
	curl_setopt($request, CURLOPT_ENCODING, "");	
	curl_setopt($request, CURLOPT_SSL_VERIFYHOST, 2); 
	curl_setopt($request, CURLOPT_RETURNTRANSFER, true); 
	curl_setopt($request, CURLOPT_POSTFIELDS, $ecocash_string); // use HTTP POST to send form data
	curl_setopt($request, CURLOPT_SSL_VERIFYPEER, FALSE); // uncomment this line if you get no gateway response.
	curl_setopt($request, CURLOPT_URL, $ecocash_url); 

	$json_raw = curl_exec($request); // execute curl post and store results in $json_raw
	
curl_close ($request); // close curl object




// This line takes the response and breaks it into an array using the specified delimiting character

$ecocash_response = json_decode($json_raw, TRUE);
/*print_r($ecocash_response); die;*/
//print_r($ecocash_response);
if (preg_match("/SVC0007/i", json_encode($ecocash_response))) {
    //Invalid number
	$response["success"] = 0;
    $response["message"] = "Invalid number ".$endUserId;
    die(json_encode($response));
   
	
	} elseif (preg_match("/SVC0270/i", json_encode($ecocash_response))){
    //Valid number but failed. This might be because customer does not have enough funds 	
	$response["success"] = 0;
    $response["message"] = "Transaction Failed ".$endUserId;
    die( json_encode($response));
   
	}
	elseif (preg_match("/60019/i", json_encode($ecocash_response)))	{
		$response["success"] = 0;
    	$response["message"] = "Insufficient Funds in Wallet".$endUserId;
        die( json_encode($response));
	}
	elseif (preg_match("/00409/i", json_encode($ecocash_response)))	{
		$response["success"] = 0;
    	$response["message"] = "Transaction Below Merchant Minimum".$endUserId;
        die( json_encode($response)); 
	}
	 elseif($ecocash_response['transactionOperationStatus'] == "PENDING SUBSCRIBER VALIDATION") { 
 //****UpdatePaymentStatus($_POST['oid'], $db, $tm);
 $response["success"] = 1;
    	$response["message"] = "Success, PENDING SUBSCRIBER VALIDATION".$endUserId;
        die( json_encode($response)); 
}	
else {$response["success"] = 0;
    	$response["message"] = "Unkown Error, Please Try again later".$endUserId;
        die( json_encode($response)); 
	}
 

die();

else:
$response["success"] = 0;
    	$response["message"] = "Insufficient Posts".$endUserId;
        die( json_encode($response)); 

endif;



function get_option($optionname,$dbo){
	$query = "SELECT * FROM `wp_options` where option_name = :oname";
    
    $query_params = array(
        ':oname' => $optionname
    );
    
    try {
        $stmt   = $dbo->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!OPTION1" . $ex->getMessage();
        echo(json_encode($response));
        
    }
    $StoreID="";
	$StoreName ="";
      
    //fetching all the rows from the query
 $rows = $stmt->fetchAll();
                           
    if ($rows) {
      foreach ($rows as $row)
                            {
                            //$CellNo = $row['VALUE'];
							$CategID=$row['option_id'];
							$CategName =$row['option_value'];
							}
							return $CategID . '|'.$CategName;
					
 }
 else {
         return "Error";
 }
	
}

function UpdatePaymentStatus($oid, $dbo, $tm){
	
	// Update Order Status Before Returning Success
	$query = "Update `wp_walleto_orders` set paid = 1, paid_on = :dt where id = :oid  ";
    
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':oid' => $oid, 
		':dt' => $tm,
    );
   
    //time to run our query, and create the user
    try {
        $stmt   = $dbo->prepare($query);
        $result = $stmt->execute($query_params);
		$id = $dbo->lastInsertId();
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Failed To Update Order Status To Paid";
        die(json_encode($response));
    }

	
	
	/*CREATE PAYMENT TRANSACTION RECORDS*/
	setOrderMeta(  $db, $id );	
		
	/*CREATE PAYMENT TRANSACTION RECORDS*/
	setPaymentTransactions(  $db, $id, 'Ewallet / Discount Voucher', $userid, $tm, $_POST['totalprice'] );

	/*SMS*/
	sendSMS(  $db, $order);
			
			
$response["success"] = 1;
    $response["message"] = "Success, PENDING SUBSCRIBER VALIDATION";
    echo json_encode($response);
    
}


function GetResponse($db, $dtm, $order) {
		$hash = $_GET['myhsh']; 
		UpdatePaymentStatus($hash, $db, $dtm); 
 
		die;
	}	


function sendSMS( $dbo, $oid){
//SEND EMAIL TO USER
	//Walleto_send_email_when_item_is_paid_buyer($id, $_POST['uid']);
    //gets user's info based off of a username.
	
    $query = "SELECT VALUE, wo.ID, wo.totalprice FROM `wp_cimy_uef_data` cimy
inner join wp_walleto_orders wo on wo.uid = cimy.USER_ID 
where wo.id=:oid and FIELD_ID=4 LIMIT 1";
    
    $query_params = array(
        ':oid' => $oid
    );
    
    try {
        $stmt   = $dbo->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one to product JSON data:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!dataselect";
        echo(json_encode($response));
        
    }
    $CellNo="";
	$ttl_amt ="";
	$inv_num ="";
    //This will be the variable to determine whether or not the user's information is correct.
    //we initialize it as false.
    $validated_info = false;
    
    //fetching all the rows from the query
 $rows = $stmt->fetchAll();
                           
    if ($rows) {
      foreach ($rows as $row)
                            {
                            $CellNo = $row['VALUE'];
							$inv_num = $row['id'];
							$ttl_amt = $row['totalprice'];
							$CellNo = 	"263" . substr($CellNo, 1);
							}
					
 }
 else {
         $CellNo = "Error";
 }
	//SEND SMS TO USER
	//$usercell = get_user_cellno($_POST['userid']);
	$msg = "Dear Customer, You have made a payment of ".$ttl_amt." through EcoCash for invoice ".$inv_num.". You will be notified when it is ready for delivery/pick up. Thank you HTSM";
	
	$url ="http://api.infobip.com/api/v3/sendsms/plain?user=HandT&password=n4Kzkp90&sender=HnTOnline&SMSText=" . urlencode($msg) ."&GSM=" . $CellNo;	
		 
		
//Set stream options
$opts = array(
  'http' => array('ignore_errors' => true)
);

//Create the stream context
$context = stream_context_create($opts);

//Open the file using the defined context
$file = file_get_contents($url, true, $context);		
		
}



//******************************************************
//
//	Create Invoice Number
//
//******************************************************

function setOrderMeta(  $dbo, $oid ){
	   $query = "INSERT INTO `wp_walleto_ordermeta`(  `order_id`, `ometa_key`, `ometa_value`) VALUES (:oid,'proformainv_num',(select max(ometa_value)+1 from `wp_walleto_ordermeta` where ometa_key = 'proformainv_num') ";
    
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':oid' => $oid, 
    );
   
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
		$invid = $db->lastInsertId();
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!ordermeta" . $ex;
        die(json_encode($response));
    }
}




//******************************************************
//
//	Create Payment Transactions
//
//******************************************************


function setPaymentTransactions(  $dbo, $invid, $ptype, $tm, $amt ){
	   $query = "INSERT INTO `wp_walleto_payment_transactions`(`uid`, `reason`, `datemade`, `amount`, `tp`, `uid2`) 
	   VALUES (:uid, :reason, :dt, :amt,  :tp, 0) ";
	   
	   if ($uid != '87') {
	   		$reason = "Paid through ". $ptype . " against invoice ".$invid;
			$tp = 1;
	   }
	   else {
		   	   $reason = "USER PAID against invoice ".$invid. " via ". $ptype;
			$tp = 0;
	   }
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':uid' => $uid, 
        ':invid' => $invid, 
		':reason' => $reason, 
		':dt' => $tm,
		':amt' => $amt,
		':tp' => $tp,		
    );
   
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
		//$id = $db->lastInsertId();
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!" . $ex;
        die(json_encode($response));
    }
}


