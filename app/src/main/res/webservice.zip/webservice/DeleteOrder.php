<?php
try
{
	
require("config.inc.php");
require ("class-phpass.php");
 
 $tm 		= $_SERVER['REQUEST_TIME'] ;
 $uid       = $_POST['userid'];
 $ptype     = $_POST['ptype'];
 $amt       = $_POST['amt'];
	
    if (!isset($_POST['userid']) || !isset($_POST['totalprice']) || !isset($_POST['discount']) || !isset($_POST['ptype'])   || !isset($_POST['Coupon']) )  {
        

        // Create some data that will be the JSON response 
        $response["success"] = 0;
        $response["message"] = "Please supply UserID,  Total Amount  Discount and Payment Types";
        
        //die will kill the page and not execute any code below, it will also
        //display the parameter... in this case the JSON data our Android
        //app will parse
		print_r($_POST);
        die(json_encode($response));
    }
    
	        
			if ($_POST['dlvrytype']=="PickUp")
			{
			$pickup = $_POST['dlvryadd'];
			$dlvryadd="";
			}
			else {
				$pickup ="";
				$dlvryadd=$_POST['dlvryadd'];
			}
			$dlvrymeth = $_POST['dlvrytype'];
			
   
    $query = "INSERT INTO `wp_walleto_orders`( `uid`,  datemade, `totalprice`,   `discount`, delivery_method, delivery_alt_add, pickup ) VALUES (:uid, :dt, :totalprice, :discount, :dlvrymeth, :dlvryadd, :pickup) ";
    
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':uid' => $_POST['userid'],
        ':totalprice' => $_POST['totalprice'],
		':discount' => $_POST['discount'],
		':dt' => $tm,
		':dlvrymeth' => $dlvrymeth,
		':dlvryadd' => $dlvryadd,
		':pickup' => $pickup,
    );
   
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
		$id = $db->lastInsertId();
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!" . $ex;
        die(json_encode($response));
    }
  
  //$id=16330;  
	if (isset($id))
	{
try
{
		 $cart = json_decode($_POST['cartitems']);
}
catch (exception $ex)
{
	echo die("Error Decoding".$ex);
}
/*
print_r($cart);
die;
*/
if(is_array($cart) and count($cart) > 0)
	{
	/*	 $response["success"] = 0;
        $response["message"] = "Bho Zvokuti Tsano!!!";
		print_r($cart);
        die(json_encode($response));
		
	*/	
		foreach($cart as $item)
		{	
		$Seller = getProductSellerName($item->seller, $db);
		 
		
		$Categ = getProductCategory($item->productid,$db);
		if ($Categ !== 'Error')
		{
		list($cid,$ctitle)= explode('|',$Categ);	
		}
		else
		{
			$cid=0;
			$ctitle="No Category";
		}
		$query = "INSERT INTO `wp_walleto_order_contents`( `uid`,  `orderid`, `pid`, `ptitle`, `price`, `discount`, `quant`, seller, slrtitle, sid, stitle, cid, ctitle, datemade) VALUES (:uid, :orderid, :pid, :ptitle, :price, :discount, :quant, :storeid,  :storetitle,:sellerid,  :sellertitle,:cid,  :ctitle, :odate) ";
    
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':uid' => $_POST['userid'],
        ':orderid' => $id,
		':pid' => $item->productid,
		':ptitle' => $item->ptitle,
        ':price' => $item->price,
		':discount' => $item->discount,
		':quant' => $item->qnty,
        ':storeid' =>  $item->storeid,
		':storetitle' => $item->storename,
        ':sellerid' =>  $item->seller,
		':sellertitle' => $Seller,
        ':cid' =>  $cid,
		':ctitle' => $ctitle,
		':odate' => $tm,
    );
    
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
		$prdcid = $db->lastInsertId();
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error2. Please Try Again!: ".$ex;
        die(json_encode($response));
    }

		}
			
	}
	setOrderMeta(  $db, $id );
	$userid = $_POST['userid'];
	sendSMS($userid, $db, $id, 'order');
	
	
	if ( $_POST['discount'] >0)
	{
		if ($_POST['discount']>= $_POST['totalprice'])
		{
				$query = "Update `wp_walleto_orders` set paid = 1, paid_on = :dt where id = :oid  ";
    
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':oid' => $id, 
		':dt' => $tm,
    );
   
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Failed To Update Order Status To Paid";
        die(json_encode($response));
    }
	
	if ($_POST['discount'] >= $_POST['totalprice'])
	{
	$Change =($_POST['discount'] -$_POST['totalprice']);
	}
	else
	{
		$Change = 0.0;
	}
	$query = "Update `wp_usermeta` set meta_value = round(meta_value + :amt,2) where user_id = :uid  and meta_key = 'credits' ";
    
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':uid' => $_POST['userid'],
		':amt' => $Change, 

    );
   
    //time to run our query,
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
       
	    $response["success"] = 0;
        $response["message"] = "Database Error1. Failed To Update Order Status To Paid". $ex;
        die(json_encode($response));
    }

	
	$query = "Update `wp_walleto_coupons` set cpn_avail = cpn_avail-1 where cpn_code = :uid";
    
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':uid' => $_POST['Coupon'], 

    );
   
    //time to run our query,
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
      
	    $response["success"] = 0;
        $response["message"] = "Database Error1. Failed To Update Order Status To Paid". $ex;
        die(json_encode($response));
    }
	setPaymentTransactions(  $db, $id, 'Ewallet / Discount Voucher', $userid, $tm, $_POST['totalprice'] );
	setPaymentTransactions(  $db, $id, 'Ewallet / Discount Voucher', '87', $tm, $_POST['totalprice'] );
	sendSMS($userid, $db, $id, 'pay');
	
 	$response["posts"] = "success";	
    $response["success"] = 1;
    $response["message"] = "Order Successfully Added!".$_POST['ptype'];
	$response["id"] = $id;
    die( json_encode($response));

		}
	}
	
	
	//If Payment is Via Ewallet mark as paid 
if ($_POST['ptype'] =='ewallet')
{
	$query = "Update `wp_walleto_orders` set paid = 1, paid_on = :dt where id = :oid  ";
    
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':oid' => $id, 
		':dt' => $tm,
    );
   
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Failed To Update Order Status To Paid";
        die(json_encode($response));
    }
	
	if ($_POST['discount'] >0)
	{
	if ($_POST['discount'] <= $_POST['totalprice'])
	{
	$amt = $_POST['totalprice'] - $_POST['discount'];
	}
	
	}
	if ($_POST['discount'] == 0)
	{
	$amt = $_POST['totalprice'];
	}
	$query = "Update `wp_usermeta` set meta_value = round(meta_value - :amt,2) where user_id = :uid  and meta_key = 'credits' ";
    
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':uid' => $_POST['userid'],
		':amt' => $amt, 

    );
   
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Failed To Update Order Status To Paid". $ex;
        die(json_encode($response));
    }
	$userid = $_POST['userid'];
	//setPaymentTransactions(  $db, $id, 'Ewallet', $userid, $tm, $_POST['totalprice'] );
	//setPaymentTransactions(  $db, $id, 'Ewallet', '87', $tm, $_POST['totalprice'] );
	sendSMS($userid, $db, $id, 'pay');
	
	
 	$response["posts"] = "success";	
    $response["success"] = 1;
    $response["message"] = "Order Successfully Added! ".$_POST['ptype'];
	$response["id"] = $id;
	//$response["celly"] = $CellNo;
    die( json_encode($response));
}

	}
	
						
    $response["posts"] = "success";
	$response["success"] = 1;
    $response["message"] = "Order Successfully Added!";
	$response["id"] = $id;
    echo( json_encode($response));
    
    //for a php webservice you could do a simple redirect and die.
    //header("Location: login.php"); 
    //die("Redirecting to login.php");
    
}
catch(Exception $ex)
{
	$response["success"] = 0;
        $response["message"] = $e->getMessage();
        
	  die( 'Caught exception: '.  json_encode($response) );

    $response["posts"] = "Failed";	
    $response["success"] = 0;
    $response["message"] = "Failed to Create Order Successfully Added!".$_POST['ptype'];
	$response["id"] = $id;
    echo( json_encode($response));

	
}





//******************************************************
//
//	Creating HTO codes
//
//******************************************************
$hasher = new PasswordHash(8, TRUE);

$hto = mt_rand(1000, 9999);
$htocode = 'HTO'.$hto;
$store = $hasher->HashPassword( $htocode);
$ordname = 'ODR_'.$oid;

$query = "INSERT INTO `wp_options`(`option_name`, `option_value`, `autoload`) 
	   VALUES (:NAME, :VALUE, :AUTO) ";
	   
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':NAME' => $ordname ,
		':VALUE' => $store, 
		':AUTO)' => 'yes',		
    );
   
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
		$invid = $db->lastInsertId();
		
		//$stmt   = $db->prepare($query);
        //$result = $stmt->execute($query_params);
		
		 $response["success"] = 1;
        $response["message"] = "HTO code added!";
        echo(json_encode($response));
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!" . $ex->getMessage();
        die(json_encode($response));
    }
	
	
	
	$query        = " SELECT option_value FROM wp_options WHERE option_name = :NAME";
    //now lets update what :user should be
    $query_params = array(
        ':NAME' => $ordname,
    );
    
    //Now let's make run the query:
    try { 
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!";
        die(json_encode($response));
    }
    
    $row = $stmt->fetch();
    if ($row) {
     $HTOC =  $hasher->CheckPassword ($row['option_value'], $store);
        //You could comment out the above die and use this one:
        $response["success"] = 1;
        $response["message"] = "HTO code fetched";
        echo(json_encode($response));
	}
	



//******************************************************
//
//	Send SMS Confirmation
//
//******************************************************



$query  = " SELECT VALUE FROM `wp_cimy_uef_data` where USER_ID=:uid and FIELD_ID=4 LIMIT 1";
    //now lets update what :user should be
    $query_params = array(
        ':uid' => $userid
    );
    


    //Now let's make run the query:
    try { 
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
		
		
		 //$response["success"] = 1;
        //$response["message"] = "Phone number fetched" .$result;
        //echo(json_encode($response));
		
    }
    catch (PDOException $ex) {
        
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!";
        echo(json_encode($response));
    }
    
    $row = $stmt->fetch();
    if ($row) {
        
                            $telno = $row['VALUE'];
						


        $response["success"] = 1;
        $response["message"] = "Phone number fetched" .$telno;
        echo(json_encode($response));
	}
 else {
         $telno = "Error";

$response["success"] = 0;
        $response["message"] = "Phone number not fetched:".$row['VALUE'];
		
        echo(json_encode($response));
		
 }






function send_sms($sender,$cell,$message)
{
	//$sender = 'HTAH';
	
    $user = 'calvinm';
    $pass = 'h4mm3r';
	//$message = 'Dear Customer, You have placed an order of $".$_POST["totalprice"].", for invoice  #". $oid ." You will be notified when it is ready for delivery/pick up. Thank you HTSM';
	//$cell = isset($_POST['telno']);
    
    $url = "http://api.infobip.com/api/v3/sendsms/plain?user=".$user."&password=".$pass."&sender=" . $sender . "&SMSText=".urlencode($message)."&GSM=". $cell ."&type=longSMS"; 
    $answer = file_get_contents($url);
    return $answer; 
	 //var_dump(parse_url($url));


    $oid = $id;
//$code = $_SESSION['startNum'];

    //$cell = $CellNo;
}

 


send_sms('HTAH', $telno, "Dear Customer, Your order number is ". $oid . " verification code is " .$HTOC. " You will be notified when it is ready for delivery/pick up. Thank you HTSM team");








//******************************************************
//
//	Get Product STORE / SELLER
//
//******************************************************

function getProductStore($pdctid, $db){
	$query = "SELECT u.id, u.display_name
FROM wp_postmeta pm
INNER JOIN wp_users u ON pm.meta_value = u.id
AND pm.meta_key = 'seller'
INNER JOIN wp_walleto_order_contents wom ON wom.pid = pm.post_id
WHERE post_id = :pid";
    
    $query_params = array(
        ':pid' => $pdctid
    );
    
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!" . $ex->getMessage();
        echo(json_encode($response));
        
    }
    $StoreID="";
	$StoreName ="";
      
    //fetching all the rows from the query
 $rows = $stmt->fetchAll();
                           
    if ($rows) {
      foreach ($rows as $row)
                            {
                            //$CellNo = $row['VALUE'];
							$StoreID=$row['id'];
							$StoreName =$row['display_name'];
							}
							return $StoreID . '|'.$StoreName;
					
 }
 else {
         return "Error";
 }
}


//******************************************************
//
//	Get Product STORE / SELLER
//
//******************************************************

function getProductSellerName($sellerid, $db){
	$query = "SELECT * FROM `wp_users` where id = :id";
    
    $query_params = array(
        ':id' => $sellerid
    );
    
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!" . $ex->getMessage();
        echo(json_encode($response));
        
    }
    $StoreID="";
	$StoreName ="";
      
    //fetching all the rows from the query
 $rows = $stmt->fetchAll();
                           
    if ($rows) {
      foreach ($rows as $row)
                            { 
							$SellerName =$row['user_login'];
							}
							return $SellerName;
					
 }
 else {
         return "Error";
 }
}



//******************************************************
//
//	Shipping Product CATEGORY
//
//******************************************************

function getProductCategory($pdctid,$dbo){
	$query = "SELECT wt.term_id, wt.name FROM `wp_terms` wt inner join wp_term_relationships wtr on wt.term_id = wtr.term_taxonomy_id inner join wp_posts wp on wtr.object_id = wp.id where wp.id = :pid";
    
    $query_params = array(
        ':pid' => $pdctid
    );
    
    try {
        $stmt   = $dbo->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!" . $ex->getMessage();
        echo(json_encode($response));
        
    }
    $StoreID="";
	$StoreName ="";
      
    //fetching all the rows from the query
 $rows = $stmt->fetchAll();
                           
    if ($rows) {
      foreach ($rows as $row)
                            {
                            //$CellNo = $row['VALUE'];
							$CategID=$row['term_id'];
							$CategName =$row['name'];
							}
							return $CategID . '|'.$CategName;
					
 }
 else {
         return "Error";
 }
	
}











//******************************************************
//
//	Create Invoice Number
//
//******************************************************

	   $query = "INSERT INTO `wp_walleto_ordermeta` (  `order_id`, `ometa_key`, `ometa_value`) VALUES (:oid,'proformainv_num',(select max(ometa_value)+1 from `wp_walleto_ordermeta` om1 where ometa_key = 'proformainv_num')) ";
    
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':oid' => $oid, 
    );
   
    //time to run our query, and create the user
    try {
        $stmt   = $dbo->prepare($query);
        $result = $stmt->execute($query_params);
		$invid = $dbo->lastInsertId();
		
		$response["success"] = 1;
        $response["message"] = "Invoice number created!" . $ex->getMessage();
        echo(json_encode($response));
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!" . $ex->getMessage();
        echo(json_encode($response));
    }





//******************************************************
//
//	Create Payment Transactions
//
//******************************************************

	   $query = "INSERT INTO `wp_walleto_payment_transactions`(`uid`, `reason`, `datemade`, `amount`, `tp`, `uid2`) 
	   VALUES (:uid, :reason, :dt, :amt,  :tp, 0) ";
	   
	   if ($uid != '87') {
	   		$reason = "Paid through ". $ptype . " against invoice ".$invid;
			$tp = 1;
	   }
	   else {
		   	   $reason = "USER PAID against invoice ".$invid. " via ". $ptype;
			$tp = 0;
	   }
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':uid' => $uid,
		':reason' => $reason, 
		':dt' => $tm,
		':amt' => $_POST['amt'],
		':tp' => $tp,		
    );
   
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
		$invid = $db->lastInsertId();
		
		//$stmt   = $db->prepare($query);
        //$result = $stmt->execute($query_params);
		
		 $response["success"] = 1;
        $response["message"] = "Payment transaction added!";
        echo(json_encode($response));
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!" . $ex->getMessage();
        die(json_encode($response));
    }

?>
