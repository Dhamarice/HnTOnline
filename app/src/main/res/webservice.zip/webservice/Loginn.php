<?php
 
/*
* Database Constants 
*/
$DB_HOST = "localhost";
$DB_USERNAME = "hammeran_hntdbur";
$DB_PASSWORD = "password";
$DB_NAME = "hammeran_shpdb";
 
//Connecting to the database
$con = mysqli_connect ($DB_HOST, $DB_USERNAME, $DB_PASSWORD, $DB_NAME);

//checking the successful connection
if($con) {
 //getting the credentials from request 
 
  $hasher = new PasswordHash(8, TRUE);
$user_login =(isset($_GET['user_login'])
$hasher->CheckPassword( $_POST['password'], $row['user_pass'] ) = (isset($_GET['user_pass'])


// Secure the credentials

$user_login = mysql_real_escape_string(isset($_POST['user_login']));
$user_pass = mysql_real_escape_string(isset($_POST['user_pass']);
  
 //Comparing values to database
$query = "SELECT * FROM wp_users WHERE user_login = '$user_login' AND user_password = '$user_pass';";
$result = mysql_query($query) or die("Unable to verify user because " . mysql_error());
$row = mysql_fetch_assoc($result);

if ($row['total'] == 1) {

    // success

    $response["success"] = 1;

    // echoing JSON response

    echo json_encode($response);
}
else {

    // username and password not found
    // failed

    $response["failed"] = 1;

    // echoing JSON response

    echo json_encode($response);
 }
 //else
 //{
	 $status = 'FAILED';
 //}
}
//echo json_encode (array ("response"=> $response));

mysqli_close ($con);
?>
