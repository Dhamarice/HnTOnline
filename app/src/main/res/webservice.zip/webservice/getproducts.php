<?php

/*
Our "config.inc.php" file connects to database every time we include or require
it within a php script.  Since we want this script to add a new user to our db,
we will be talking with our database, and therefore,
let's require the connection to happen:
*/
require("config.inc.php");

if ($_POST['categoryid'] !='NewArrivals' & $_POST['categoryid'] !='OnSpecial' & $_POST['categoryid'] !='Popular')
{
//initial query
$query = "SELECT p.ID, p.post_title, tt.taxonomy, (SELECT guid FROM wp_posts WHERE id = m.meta_value ) AS `imgurl`, m1.meta_value as 'price' FROM wp_posts p inner join `wp_term_relationships` tr on p.ID=tr.object_id inner JOIN wp_term_taxonomy tt on tt.term_taxonomy_id = tr.term_taxonomy_id left outer join wp_postmeta m on p.id = m.post_id AND m.meta_key = '_thumbnail_id' left outer join wp_postmeta m1 on p.id = m1.post_id AND m1.meta_key = 'price' where p.post_type='product' and tt.parent=".$_POST['categoryid']." and post_status='publish' having `imgurl` like '%.png%' Order By Rand() LIMIT 75  ";
}

if ($_POST['categoryid'] =='NewArrivals')
{
//initial query
$query = "SELECT p.ID, p.post_title, tt.taxonomy,p.post_date, (SELECT guid FROM wp_posts WHERE id = m.meta_value ) AS `imgurl`, m1.meta_value as 'price' FROM wp_posts p inner join `wp_term_relationships` tr on p.ID=tr.object_id inner JOIN wp_term_taxonomy tt on tt.term_taxonomy_id = tr.term_taxonomy_id left outer join wp_postmeta m on p.id = m.post_id AND m.meta_key = '_thumbnail_id' left outer join wp_postmeta m1 on p.id = m1.post_id AND m1.meta_key = 'price' where p.post_type='product' and post_status='publish' having `imgurl` like '%.png%' Order By p.post_date desc LIMIT 60";
}


if ( $_POST['categoryid'] =='OnSpecial' )
{
//initial query
$query = "SELECT p.ID, p.post_title, tt.taxonomy, (SELECT guid FROM wp_posts WHERE id = m.meta_value ) AS `imgurl`, m1.meta_value as 'price' FROM wp_posts p inner join `wp_term_relationships` tr on p.ID=tr.object_id inner JOIN wp_term_taxonomy tt on tt.term_taxonomy_id = tr.term_taxonomy_id left outer join wp_postmeta m on p.id = m.post_id AND m.meta_key = '_thumbnail_id' left outer join wp_postmeta m1 on p.id = m1.post_id AND m1.meta_key = 'price' where p.post_type='product' and tt.parent=".$_POST['categoryid']." and post_status='publish' having `imgurl` like '%.png%' Order By Rand() LIMIT 60  ";
}

if (  $_POST['categoryid'] =='Popular')
{
//initial query
$query = "SELECT p.ID, p.post_title, tt.taxonomy, (SELECT guid FROM wp_posts WHERE id = m.meta_value ) AS `imgurl`, m1.meta_value as 'price',m2.meta_value as 'views'
FROM wp_posts p 
inner join `wp_term_relationships` tr on p.ID=tr.object_id 
inner JOIN wp_term_taxonomy tt on tt.term_taxonomy_id = tr.term_taxonomy_id
left outer join wp_postmeta m on p.id = m.post_id AND m.meta_key = '_thumbnail_id' 
left outer join wp_postmeta m1 on p.id = m1.post_id AND m1.meta_key = 'price' 
left outer join wp_postmeta m2 on p.id = m2.post_id AND m2.meta_key = 'views' 
where p.post_type='product'
and post_status='publish' having `imgurl` like '%.png%'
ORDER BY m2.meta_value DESC
Limit 60";
}


//execute query
try {
    $stmt   = $db->prepare($query);
    $result = $stmt->execute();
}
catch (PDOException $ex) {
    $response["success"] = 0;
    $response["message"] = "Database Error!";
    die(json_encode($response));
}

// Finally, we can retrieve all of the found rows into an array using fetchAll 
$rows = $stmt->fetchAll();


if ($rows) {
    $response["success"] = 1;
    $response["message"] = "Post Available!";
    $response["posts"]   = array();
    
    foreach ($rows as $row) {
        $post             = array();
		$post["post_id"]  = $row["ID"];
        $post["name"] = $row["post_title"]; 
        $post["imgurl"] = $row["imgurl"]; 
        $post["price"] = $row["price"]; 
        
        
        //update our repsonse JSON data
        array_push($response["posts"], $post);
    }
    
    // echoing JSON response
    echo json_encode($response);
    
    
} else {
    $response["success"] = 0;
    $response["message"] = "No Post Available!";
    die(json_encode($response));
}

?>
