<?php

/*
Our "config.inc.php" file connects to database every time we include or require
it within a php script.  Since we want this script to add a new user to our db,
we will be talking with our database, and therefore,
let's require the connection to happen:
*/
require("config.inc.php");

//initial query
$query = "SELECT DISTINCT pid, price, quant, name
FROM `wp_walleto_variations_content`
INNER JOIN wp_terms ON term_id = replace( variation_string, '_', '' )
WHERE pid =".$_POST['productid']."
AND price <> ''";

//execute query
try {
    $stmt   = $db->prepare($query);
    $result = $stmt->execute();
}
catch (PDOException $ex) {
    $response["success"] = 0;
    $response["message"] = "Get Product Details Database Error!".$stmt;
    die(json_encode($response));
}

// Finally, we can retrieve all of the found rows into an array using fetchAll 
$rows = $stmt->fetchAll();


if ($rows) {
    $response["success"] = 1;
    $response["message"] = "Product Details Loaded!";
    $response["posts"]   = array();
    
    foreach ($rows as $row) {
        $post             = array();
		$post["key"]  = $row["pid"];
        $post["value"] = $row["name"]; 
        $post["price"] = $row["price"]; 
		$post["quant"] = $row["quant"]; 
        
        //update our repsonse JSON data
        array_push($response["posts"], $post);
    }
    
    // echoing JSON response
    echo json_encode($response);
    
    
} else {
    $response["success"] = 0;
    $response["message"] = "No Product Details Found!";
    die(json_encode($response));
}

?>
