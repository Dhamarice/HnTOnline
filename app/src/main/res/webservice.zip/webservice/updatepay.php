<?php

/*
Our "config.inc.php" file connects to database every time we include or require
it within a php script.  Since we want this script to add a new user to our db,
we will be talking with our database, and therefore,
let's require the connection to happen:
*/
require("devconfig.inc.php");
$tm = $_SERVER['REQUEST_TIME'] ;

//if posted data is not empty
if (!empty($_POST)) {

    
    $query = "UPDATE wp_walleto_order_contents
SET paid=1, paid_on=:TM
WHERE orderid=:ORDERID ;";
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
	':TM' => $tm ,
        ':ORDERID' => $_REQUEST['oid'],
    );            
          
    
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        //$response["success"] = 0;
        //$response["message"] = "Database Error2. Please Try Again!";
        //die(json_encode($response));
    }
    
    //If we have made it this far without dying, we have successfully added
    //a new user to our database.  We could do a few things here, such as 
    //redirect to the login page.  Instead we are going to echo out some
    //json data that will be read by the Android application, which will login
    //the user (or redirect to a different activity, I'm not sure yet..)
    $response["success"] = 1;
    $response["message"] = "Account successfully updated!";
    echo json_encode($response);
    
    //for a php webservice you could do a simple redirect and die.
    //header("Location: login.php"); 
    //die("Redirecting to login.php");
	
    
    
} else {
	
	  $response["success"] = 0;
    $response["message"] = "Update failed!";
    echo json_encode($response);
	}
	
	
	
	

    
    $query = "UPDATE wp_walleto_orders
SET paid=1, paid_on=:TM
WHERE id=:ORDERID ;";
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
	':TM' => $tm ,
    ':ORDERID' => $_REQUEST['oid'],
    );            
          
    
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        //$response["success"] = 0;
        //$response["message"] = "Database Error2. Please Try Again!";
        //die(json_encode($response));
    }
    
    //If we have made it this far without dying, we have successfully added
    //a new user to our database.  We could do a few things here, such as 
    //redirect to the login page.  Instead we are going to echo out some
    //json data that will be read by the Android application, which will login
    //the user (or redirect to a different activity, I'm not sure yet..)
    $response["success"] = 1;
    $response["message"] = "Account successfully updated!";
    echo json_encode($response);
    
    //for a php webservice you could do a simple redirect and die.
    //header("Location: login.php"); 
    //die("Redirecting to login.php");
	
	
	
	//******************************************************
//
//	Send SMS Confirmation
//
//******************************************************



$query  = " select Oc.seller,U.user_email,ud.VALUE from wp_walleto_order_contents Oc inner join wp_users u on u.ID=Oc.seller inner join wp_cimy_uef_data ud on ud.FIELD_ID=4 and ud.USER_ID=Oc.seller where Oc.orderid = :oid";
    //now lets update what :user should be
    $query_params = array(
        ':oid' => $orderid
    );
    


    //Now let's make run the query:
    try { 
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
		
		
		 //$response["success"] = 1;
        //$response["message"] = "Phone number fetched" .$result;
        //echo(json_encode($response));
		
    }
    catch (PDOException $ex) {
        
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!";
        echo(json_encode($response));
    }
    
    $row = $stmt->fetch();
    if ($row) {
        
                            $telno = $row['VALUE'];
							$email = $row['user_email'];
						


        $response["success"] = 1;
        $response["message"] = "Phone number fetched" .$telno;
        echo(json_encode($response));
	}
 else {
         $telno = "Error";

$response["success"] = 0;
        $response["message"] = "Phone number not fetched:".$row['VALUE'];
		
        echo(json_encode($response));
		
 }






function send_sms($sender,$cell,$message)
{
	//$sender = 'HTAH';
	
    $user = 'calvinm';
    $pass = 'h4mm3r';
	//$message = 'Dear Customer, You have placed an order of $".$_POST["totalprice"].", for invoice  #". $oid ." You will be notified when it is ready for delivery/pick up. Thank you HTSM';
	//$cell = isset($_POST['telno']);
    
    $url = "http://api.infobip.com/api/v3/sendsms/plain?user=".$user."&password=".$pass."&sender=" . $sender . "&SMSText=".urlencode($message)."&GSM=". $cell ."&type=longSMS"; 
    $answer = file_get_contents($url);
    return $answer; 
	 //var_dump(parse_url($url));


    $oid = $id;
//$code = $_SESSION['startNum'];

    //$cell = $CellNo;
}

 


send_sms('HTAH', $telno, "Dear Customer, Your order number is ". $oid . " verification code is " .$HTOC. " You will be notified when it is ready for delivery/pick up. Thank you HTSM team");

mail($email, 'PAYMENT ONLINE SHOPPING MALL', 'PAYMENT was made for product $pid');
	
	
    
?>



