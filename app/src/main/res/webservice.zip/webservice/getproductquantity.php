<?php

/*
Our "config.inc.php" file connects to database every time we include or require
it within a php script.  Since we want this script to add a new user to our db,
we will be talking with our database, and therefore,
let's require the connection to happen:
*/
require("config.inc.php");




		 $Pid = $_POST['productid'];




//initial query
$query = "SELECT ID, p.post_title, p.post_content, m1.meta_value as price, m2.meta_value as quantity,
(SELECT guid FROM wp_posts WHERE id = m.meta_value ) AS `imgurl`
FROM wp_posts p inner join `wp_term_relationships` tr on p.ID=tr.object_id
left outer join wp_postmeta m on p.id = m.post_id AND m.meta_key = '_thumbnail_id'
inner JOIN wp_postmeta m1 on p.id=m1.post_id and m1.meta_key='Price'
left outer join wp_postmeta m2 on p.id=m2.post_id and m2.meta_key='quant'
where p.post_type='product'  
and ID =  '".$Pid."'
Order By p.post_modified LIMIT 10";

//execute query
try {
    $stmt   = $db->prepare($query);
    $result = $stmt->execute();
}
catch (PDOException $ex) {
    $response["success"] = 0;
    $response["message"] = "Get Product Details Database Error!".$ex;
    die(json_encode($response));
}

// Finally, we can retrieve all of the found rows into an array using fetchAll 
$rows = $stmt->fetchAll();


if ($rows) {
  
    
    foreach ($rows as $row) {
        $post             = array();
		$post["post_id"]  = $row["ID"];
        $post["name"] = $row["post_title"]; 
        $post["imgurl"] = $row["imgurl"]; 
		//$post["content"] = $row["post_content"];
      	$post["price"] = $row["price"];
       	$post["quantity"] = $row["quantity"];
       	
       	
       	  $response["success"] = 1;
    $response["message"] = "Product Details Loaded!";
    $response["posts"]   = array();
        
        //update our repsonse JSON data
        array_push($response["posts"], $post);
    }
    // echoing JSON response
    echo json_encode($response);
    
    
} else {
    $response["success"] = 0;
    $response["message"] = "No Product Details Found!";
    die(json_encode($response));
}
		

?>
