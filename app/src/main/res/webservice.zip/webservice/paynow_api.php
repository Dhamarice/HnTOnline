<?php

 
require("config.inc.php");
	
global $pn_sls_order_id, $pn_sls_amount, $integration_id, $integration_key, $pn_initiate_transaction_url, $pn_sls_checkout_url, $pn_sls_resulturl, $pn_sls_returnurl, $pn_sls_additionalinfo, $pn_sls_reference;
$pn_sls_order_id = 14210;//  $_POST['o_id'];
$pn_sls_amount =  GetOrderTotal($pn_sls_order_id, $db);
$integration_id = 3200;// GetOption('Walleto_paynow_iID', $db);
$integration_key_enc = '9ad46ebb-4f29-45a4-829d-2fc2a858054f';//GetOption('Walleto_paynow_iKey', $db);
/* Decrypt the key from database */
$integration_key = '9ad46ebb-4f29-45a4-829d-2fc2a858054f'; //oops this MUST BE SECRET, take it from a Database, encrypted or something
$authemail = '';
$pn_initiate_transaction_url = 'https://www.paynow.co.zw/Interface/InitiateTransaction';
//$pn_sls_checkout_url = add_query_arg( 'vst', 'f', get_permalink(get_option('Walleto_my_account_all_orders_page_id')));
$pn_sls_resulturl = "https://hammerandtongues.com/?pay_for_item=paynow&pn_action=notify&hsh=$pn_sls_order_id";
$pn_sls_returnurl = "https://hammerandtongues.com/?pay_for_item=paynow&pn_action=return&hsh=$pn_sls_order_id";
$pn_sls_additionalinfo =  'HAMMER AND TONGUES MALL SITE ORDER';
$pn_sls_reference =  "Order #$pn_sls_order_id" ;


 $local_order_id = $pn_sls_order_id;
	
	
	//set POST variables
	$values = array('resulturl' => $pn_sls_resulturl,
			'returnurl' =>  $pn_sls_returnurl,			
			'reference' =>  $pn_sls_reference,
			'amount' =>  $pn_sls_amount,
			'id' =>  $integration_id,
			'additionalinfo' =>  $pn_sls_additionalinfo,
			'status' =>  'Message'); //just a simple message
			
	$fields_string = CreateMsg($values, $integration_key);
	
	//open connection
	//$ch = curl_init();
	$url = $pn_initiate_transaction_url;
	
	/*echo "amount:   ". GetOrderTotal($pn_sls_order_id, $db); 
		echo "<br>";
	
	echo "id:   ". $integration_id;
	echo "<br>";
	echo "key:   ". $integration_key_enc; 
	echo "<br>";
	
	echo $fields_string;
	*/
	$response["success"] = 1;
    $response["message"] = "Values";
	 $response["posts"]   = array();
        $post             = array();
		$post["postdata"] = $fields_string; 
		$post["url"] = $pn_initiate_transaction_url; 
        //update our repsonse JSON data
        array_push($response["posts"], $post);
		     
	    echo die(json_encode($response));
	
function CreateMsg($values, $MerchantKey){
	$fields = array();
	foreach($values as $key=>$value) {
	   $fields[$key] = urlencode($value);
	}

	$fields["hash"] = urlencode(CreateHash($values, $MerchantKey));

	$fields_string = UrlIfy($fields);
	return $fields_string;
}	


function CreateHash($values, $MerchantKey){
	$string = "";
	foreach($values as $key=>$value) {
		if( strtoupper($key) != "HASH" ){
			$string .= $value;
		}
	}
	$string .= $MerchantKey;
	
	$hash = hash("sha512", $string);
	return strtoupper($hash);
}



function UrlIfy($fields) {
	$delim = "";
	$fields_string = "";
	foreach($fields as $key=>$value) {
		$fields_string .= $delim . $key . '=' . $value;
		$delim = "&";
	}

	return $fields_string;
}

 


function e_hash_data( $encdata ) {
	$key = "h4mm3r2017";
	$data = trim($encdata);
	return rtrim( mcrypt_decrypt( MCRYPT_RIJNDAEL_256, md5($key), base64_decode($data), MCRYPT_MODE_CBC, md5( md5( $key ) ) ), "\0" );
}



function GetOption($Key, $dbo){

 $query = "SELECT * FROM `wp_options` WHERE option_name = :key LIMIT 1";
    
    $query_params = array(
        ':key' => $Key
    );
    
    try {
        $stmt   = $dbo->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one to product JSON data:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!";
        echo(json_encode($response));
        
    }
    $Value="";
    //This will be the variable to determine whether or not the user's information is correct.
    //we initialize it as false.
    $validated_info = false;
    
    //fetching all the rows from the query
 $rows = $stmt->fetchAll();
                           
    if ($rows) {
      foreach ($rows as $row)
                            {
                            $Value = $row['option_value'];
							}
							//print_r($rows);
	return $Value;
 }
 else {
         return "No Option";
 }
}




function GetOrderTotal($Oid, $dbo){

 $query1 = "SELECT * FROM `wp_walleto_orders` where id= :oid";
    
    $query_params1 = array(
        ':oid' => $Oid
    );
    
    try {
        $stmt1   = $dbo->prepare($query1);
        $result1 = $stmt1->execute($query_params1);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one to product JSON data:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!";
        echo(json_encode($response));
        
    }
    $Value="";
     
    //fetching all the rows from the query
 $rows1 = $stmt1->fetchAll();
                           
    if ($rows1) {
      foreach ($rows1 as $row)
                            {
                            $Value = $row['totalprice'];
							}
							//print_r($rows);
	return $Value;
 }
 else {
         return "No Order";
 }
}

	