<?php

/*
Our "config.inc.php" file connects to database every time we include or require
it within a php script.  Since we want this script to add a new user to our db,
we will be talking with our database, and therefore,
let's require the connection to happen:
*/
require("config.inc.php");

if (!isset($_POST['storeid']))
{
//initial query
$query = "SELECT ID, p.post_title, p.post_content, (SELECT guid FROM wp_posts WHERE id = m.meta_value ) AS `imgurl` FROM wp_posts p left outer join wp_postmeta m on p.id = m.post_id AND m.meta_key = 'shop_slider_image' where p.post_type='shop' and post_status='publish' and p.ID in(5838,51775,9451,31713,19084)";
}
else
{
	$query = "SELECT ID, p.post_title, p.post_content,(SELECT guid FROM wp_posts WHERE id = m.meta_value ) AS `imgurl` FROM wp_posts p left outer join wp_postmeta m on p.id = m.post_id AND m.meta_key = 'shop_slider_image' where p.post_type='shop'  and post_status='publish' and  p.post_title not like '%Super%' and ID=".$_POST['storeid']." HAVING imgurl is not null Order By p.post_title LIMIT 1";
}
//execute query
try {
    $stmt   = $db->prepare($query);
    $result = $stmt->execute();
}
catch (PDOException $ex) {
    $response["success"] = 0;
    $response["message"] = "Database Error!";
    die(json_encode($response));
}

// Finally, we can retrieve all of the found rows into an array using fetchAll 
$rows = $stmt->fetchAll();


if ($rows) {
    $response["success"] = 1;
    $response["message"] = "Post Available!";
    $response["posts"]   = array();
    
    foreach ($rows as $row) {
        $post             = array();
		$post["post_id"]  = $row["ID"];
        $post["name"] = $row["post_title"];
		$post["imgurl"] = $row["imgurl"]; 
		$post["desc"] = $row["post_content"]; 
        
        
        //update our repsonse JSON data
        array_push($response["posts"], $post);
    }
    
    // echoing JSON response
    echo json_encode($response);
    
    
} else {
    $response["success"] = 0;
    $response["message"] = "No Post Available! 113010";
    die(json_encode($response));
}

?>
