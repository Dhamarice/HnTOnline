<?php
/***************************************************************************
*
*	Walleto - copyright (c) - sitemile.com
*	The best wordpress premium theme for having a marketplace. Sell and buy all kind of products, including downloadable goods. 
*	Have a niche marketplace website in minutes. Turn-key solution.
*
*	Coder: Andrei Dragos Saioc
*	Email: sitemile[at]sitemile.com | andreisaioc[at]gmail.com
*	More info about the theme here: http://sitemile.com/products/walleto-wordpress-marketplace-theme/
*	since v1.0.1
*
*	Dedicated to my wife: Alexandra
*
***************************************************************************/
	if(session_id() == '') {
		ob_start(); 		
		session_start();
	}	
	//load_theme_textdomain( 'Walleto', TEMPLATEPATH . '/languages' );
	
	DEFINE("WALLETOTHEME_VERSION", "2.1.0");
	DEFINE("WALLETOTHEME_RELEASE", "28 Feb 2015");
	DEFINE('SHORTNAME','walleto_coupons');
	global $default_search;
	$default_search = ("Begin to search by typing here...");
	 
	//--------------------------------------
	
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 230, 250 );
	add_image_size('pro-thumb', 230, 250 );
	
	global $current_theme_locale_name, $category_url_link, $products_url_thing, $shop_url_thing;
	$current_theme_locale_name = 'Walleto';
	
	$category_url_link 	= "product-category";
	$products_url_thing = "products";
	$shop_url_thing 	= "shops";
	
	/************************************
	*
	*	INCLUDES HERE - ;)
	*
	*************************************/
	include 'classes/php_cookie.php';
	
	include 'lib/admin_menu.php';
	include 'lib/first_run.php';
	include 'lib/first_run_emails.php';
	include 'lib/post_new.php';
	include 'lib/advanced_search.php';
	
	include 'lib/widgets/browse-by-category.php';
	include 'lib/widgets/latest-posted-products.php';
	include 'lib/widgets/most-visited-products.php';
	include 'lib/widgets/featured-products.php';
	include 'lib/widgets/search-widget.php';
	include 'lib/widgets/browse_shops.php';
	
	//----- my account includes ---------
	
	include 'lib/my_account/my_account.php';
	include 'lib/my_account/private_messages.php';
	include 'lib/my_account/reviews.php';
	include 'lib/my_account/personal_info.php';
	include 'lib/my_account/shop_loyalty_points.php';
	include 'lib/my_account/buyer_common_basket.php';
	include 'lib/my_account/finances.php';
	
	include 'lib/my_account/outstanding_payments.php';
	include 'lib/my_account/all_orders.php';
	include 'lib/my_account/not_shipped.php';
	include 'lib/my_account/shipped_items.php';
	
	include 'lib/my_account/shipped_orders.php';
	include 'lib/my_account/awaiting_shipping.php';
	include 'lib/my_account/awaiting_payments.php';
	include 'lib/my_account/active_products.php';
	include 'lib/my_account/out_of_stock.php';
	include 'lib/my_account/order_content.php';
	include 'lib/my_account/order_content2.php';
	include 'lib/my_account/pay_4_item.php';
	include 'lib/my_account/pay_4_item_virtual.php';
	include 'lib/my_account/pay_for_item_cod.php';
	include 'lib/my_account/my_shop_setup.php';
	include 'lib/my_account/purchase_membership.php';
	include 'lib/my_account/purchase_membership_credits.php';
	include 'lib/my_account/cancel_order.php';
	
	include 'lib/login_register/custom2.php';
	
	include 'lib/my_cart.php';
	include 'lib/checkout.php';	
	include 'lib/set_delivery.php';
	include 'lib/set_pickup.php';
	include 'lib/shops.php';
	include 'lib/watchlist.php';
	include 'lib/all_categories.php';
	include 'lib/blog.php';
	include 'lib/my_account/seller_dashboard.php';
	include 'lib/wl_manage_locations.php';
	include 'lib/wl_manage_packages.php';
	include 'lib/wl_manage_rewards.php';
	include 'lib/wl_dashboard_stats.php';
	include 'lib/wl_manage_draws.php';
	include 'lib/wl_odr_cln_verification.php';
	include 'lib/wl_odr_dlv_invoice.php';
	include 'lib/wl_pro_csv_import.php';
	include 'lib/wl_odr_cmb_invoices.php';
	
	
	add_shortcode('walleto_my_account_home', 							'Walleto_my_account_display_home_page');
	add_action('widgets_init',	 										'Walleto_framework_init_widgets' );
	add_action('init', 													'walleto_create_post_type' );
	add_action('admin_menu', 											'Walleto_admin_main_menu_scr');
	add_action('admin_head', 											'walleto_admin_main_head_scr');
	add_action("template_redirect", 									'walleto_template_redirect');
	add_action('query_vars', 											'walleto_add_query_vars'); 
	add_action('wp_enqueue_scripts', 									'walleto_add_theme_styles');
	add_filter('wp_head',												'walleto_add_max_nr_of_images');
	
	add_image_size( 'main-image-post', 170, 135, false );
	add_image_size( 'main-image-post2', 205, 155, true );  
	add_image_size( 'small-image-post', 65, 65, false );
	add_image_size( 'image-single-product-page', 350, 200, true );
	add_image_size( 'slider-image', 150, 110, false );
	
	
	
	
	add_action("manage_posts_custom_column", 					"walleto_my_custom_columns");
	add_filter("manage_edit-product_columns",					"walleto_my_products_columns");
	add_filter("manage_edit-shop_columns",						"walleto_my_shops_columns");
	add_action('save_post',										'walleto_save_custom_fields');
	add_action( 'init', 										'walleto_register_my_menus' );
	add_action('generate_rewrite_rules', 						'walleto_rewrite_rules' );
	
	add_shortcode( 'walleto_my_account' , 									'Walleto_my_account_display_home_page' );
	add_shortcode( 'walleto_my_account_priv_mess' , 						'Walleto_my_account_display_priv_mess_page' );
	add_shortcode( 'walleto_my_account_reviews' , 							'Walleto_my_account_display_reviews_page' );
	add_shortcode( 'walleto_my_account_pers_info' , 						'Walleto_my_account_display_persinfo_page' );
	add_shortcode( 'walleto_my_account_shp_lty_pnts' , 						'Walleto_my_account_display_shp_lty_pnts' );
	add_shortcode( 'walleto_my_account_byr_cmn_bskt' , 						'Walleto_my_account_display_byr_cmn_bskt' );		
	add_shortcode( 'walleto_my_account_finances' , 							'Walleto_my_account_display_finances_page' );	
	
	add_shortcode( 'walleto_my_account_all_orders' , 						'Walleto_my_account_display_all_orders_page' );
	add_shortcode( 'walleto_my_account_outstand_pay' , 						'Walleto_my_account_display_outstanding_pay_page' );
	add_shortcode( 'walleto_my_account_not_shipped' , 						'Walleto_my_account_display_not_shipped_page' );
	add_shortcode( 'walleto_my_account_shipped_cust' , 						'Walleto_my_account_display_shipped_cust_page' );
	
	add_shortcode( 'walleto_my_account_active_items' , 						'Walleto_my_account_display_active_items_page' );
	add_shortcode( 'walleto_my_account_out_of_stock' , 						'Walleto_my_account_display_out_of_stock_page' );	
	add_shortcode( 'walleto_my_account_aw_pay' , 							'Walleto_my_account_display_awa_pay_page' );
	add_shortcode( 'walleto_my_account_aw_shp' , 							'Walleto_my_account_display_awa_shp_page' );	
	add_shortcode( 'walleto_my_account_shipped_orders' ,					'Walleto_my_account_display_shipped_orders_page' );
	add_shortcode( 'walleto_theme_shopping_cart' ,							'walleto_cart_area_function' );
	add_shortcode( 'walleto_theme_checkout_page' ,							'walleto_checkout_area_function' );
	add_shortcode( 'walleto_theme_set_delivery_page' ,						'walleto_delivery_area_function' );	
	add_shortcode( 'walleto_theme_set_pickup_page' ,						'walleto_pickup_area_function' );	
	add_shortcode( 'walleto_my_account_order_cnt_pg' ,						'walleto_get_my_order_content_area_function' );
	add_shortcode( 'walleto_theme_post_new' ,								'walleto_post_new_product_content_area_function' );
	add_shortcode( 'walleto_theme_adv_search' ,								'walleto_advanced_search_content_area_function' );
	add_shortcode( 'walleto_my_account_pay_4_item' ,						'walleto_pay_4_item_content_area_function' );
	add_shortcode( 'walleto_my_account_pay_4_item_virt' ,					'walleto_pay_4_item_virt_content_area_function' );
	add_shortcode( 'walleto_my_account_cash_on_delivery' ,					'walleto_pay_4_item_cod_content_area_function' );
	add_shortcode( 'walleto_theme_shops_page' ,								'walleto_shops_show_area_function' );
	add_shortcode( 'walleto_watch_list' ,									'walleto_watchlist_area_function' );
	add_shortcode( 'walleto_show_all_categories' ,							'walleto_all_cats_area_function' );
	add_shortcode( 'walleto_blog_posts' ,									'walleto_blog_posts_area_function' );
	add_shortcode( 'walleto_my_account_purchase_mem' ,						'walleto_purchase_membership_area_function' );
	add_shortcode( 'walleto_my_account_my_shop_setup' ,						'walleto_my_shop_setup_area_function' );
	add_shortcode( 'walleto_my_account_purchase_mem_crds' ,					'walleto_purchase_membership_area_function_crds' );
	add_shortcode( 'walleto_my_account_order_cnt_pg2' ,						'walleto_get_my_order_content_area_function2' );
	add_shortcode( 'walleto_my_account_cancel_order' ,						'Walleto_my_account_display_cancel_order_page' );


/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
/*class walleto_Walker_Nav_Menu extends Walker_Nav_Menu {
  function start_lvl(&$output, $depth) {
    $indent = str_repeat("\t", $depth);
    $output .= "\n$indent<ul class=\"dropdown\">\n";
  }
}*/

function walleto_remove_cookie($name)
{
	
	$PHP_COOKIE = new PHP_COOKIE($name);
	//$PHP_COOKIE->put("my_cart", $cart);
	$PHP_COOKIE->clrs();	
}

function walleto_get_custom_taxonomy_count2($post_type, $tax_term, $taxonomy_name) 
{
	$taxonomy = 'my_taxonomy'; // this is the name of the taxonomy
    $args = array(
        'post_type' => $post_type, 'posts_per_page' => '1',
		'meta_query' => array(
				array(
					'key' => 'closed',
					'value' => '0',
					'compare' => '='
				)
			),		
        'tax_query' => array(
                    array(
                        'taxonomy' => $taxonomy_name,
                        'field' => 'slug',
                        'terms' => $tax_term)
                )
        );

     $my_query = new WP_Query( $args );
	 return $my_query->found_posts;
	
}

function Walleto_myplugin_update_slug( $data, $postarr ) {
    if ( !in_array( $data['post_status'], array( 'draft', 'pending', 'auto-draft' ) ) ) {
		if($data['post_type'] == "shop")
        $data['post_name'] = sanitize_title( $data['post_title'] );
    }
    return $data;
}
add_filter( 'wp_insert_post_data', 'Walleto_myplugin_update_slug', 99, 2 );

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function walleto_get_order_content_link2($id, $uid)
{
	if(walleto_using_permalinks())
	{
		return get_permalink(get_option('Walleto_my_account_show_order_cnt_page_id2')). "?oid=". $id;	
	}
	else
	{
		return get_permalink(get_option('Walleto_my_account_show_order_cnt_page_id2'))."&oid=" . $id;
	}	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function Walleto_auction_clear_table($spm = '')
{
	return '<tr><td colspan="'.$spm.'"></td></tr>';	
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_clear_table($spm = '')
{
	return '<tr><td colspan="'.$spm.'"></td></tr>';	
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_get_product_category_fields_without_vals($catid, $clas_op = '')
{
	global $wpdb;
	$s = "select * from ".$wpdb->prefix."walleto_custom_fields order by ordr asc";	
	$r = $wpdb->get_results($s);
	
	$arr1 = array(); $i = 0;
	
	if($clas_op != "no") $clas_op = 'do_input';
	
	foreach($r as $row)
	{
		$ims 	= $row->id;
		$name 	= $row->name;
		$tp 	= $row->tp;
		
		if($row->cate == 'all')
		{ 
			$arr1[$i]['id'] 	= $ims; 
			$arr1[$i]['name'] 	= $name; 
			$arr1[$i]['tp'] 	= $tp; 
			$i++; 
		
		}
		else
		{
			$se = "select * from ".$wpdb->prefix."walleto_custom_relations where custid='$ims'";
			$re = $wpdb->get_results($se);
			
			if(count($re) > 0)
			foreach($re as $rowe) // = mysql_fetch_object($re))
			{
				if(count($catid) > 0)
				foreach($catid as $id_of_cat)
				{
				
					if($rowe->catid == $id_of_cat)
					{
						$flag_me = 1;
						for($k=0;$k<count($arr1);$k++)
						{
							if(	$arr1[$k]['id'] 	== $ims	) {  $flag_me = 0; break; }						
						}
						
						if($flag_me == 1)
						{
							$arr1[$i]['id'] 	= $ims; 
							$arr1[$i]['name'] 	= $name; 
							$arr1[$i]['tp'] 	= $tp;
							$i++;
						}
					}
				}
			}
		}
	}

	$arr = array();
	$i = 0;
	
	for($j=0;$j<count($arr1);$j++)
	{
		$ids 	= $arr1[$j]['id'];
		$tp 	= $arr1[$j]['tp'];
		
		$arr[$i]['field_name']  = $arr1[$j]['name'];
		$arr[$i]['id']  = '<input type="hidden" value="'.$ids.'" name="custom_field_id[]" />';
		
		if($tp == 1) 
		{
		
		$teka = ''; //!empty($pid) ? get_post_meta($pid, 'custom_field_ID_'.$ids, true) : "" ;
	
		$arr[$i]['value']  = '<input class="'.$clas_op.'" type="text" size="30" name="custom_field_value_'.$ids.'" 
		value="'.(isset($_GET['custom_field_value_'.$ids]) ? $_GET['custom_field_value_'.$ids] : $teka ).'" />';
		
		}
		
		if($tp == 5)
		{
		
			$teka 	= ''; //!empty($pid) ? get_post_meta($pid, 'custom_field_ID_'.$ids, true) : "" ;
			$value 	= isset($_GET['custom_field_value_'.$ids]) ? $_GET['custom_field_value_'.$ids] : $teka;
			
			$arr[$i]['value']  = '<textarea rows="5" cols="40" class="'.$clas_op.'" name="custom_field_value_'.$ids.'">'.$value.'</textarea>';
		
		}
		
		if($tp == 3) //radio
		{
			$arr[$i]['value']  = '';
			
				$s2 = "select * from ".$wpdb->prefix."walleto_custom_options where custid='$ids' order by ordr ASC ";
				$r2 = $wpdb->get_results($s2);
				
				if(count($r2) > 0)
				foreach($r2 as $row2) // = mysql_fetch_object($r2))
				{
					$teka 	= ''; //!empty($pid) ? get_post_meta($pid, 'custom_field_ID_'.$ids, true) : "" ;
					if(isset($_GET['custom_field_value_'.$ids]))
					{
						if($_GET['custom_field_value_'.$ids] == $row2->valval) $value = 'checked="checked"';
						else $value = '';
					}
					elseif(!empty($pid))
					{
						$v = ''; //get_post_meta($pid, 'custom_field_ID_'.$ids, true);
						if($v == $row2->valval) $value = 'checked="checked"';
						else $value = ''; 
					
					}				
					else $value = '';
					
					$arr[$i]['value']  .= '<input type="radio" '.$value.' value="'.$row2->valval.'" name="custom_field_value_'.$ids.'"> '.$row2->valval.'<br/>';
				}
		}
		
		
		if($tp == 4) //checkbox
		{
			$arr[$i]['value']  = '';
			
				$s2 = "select * from ".$wpdb->prefix."walleto_custom_options where custid='$ids' order by ordr ASC ";
				$r2 = $wpdb->get_results($s2);
				
				
				if(count($r2) > 0)
				foreach($r2 as $row2) // = mysql_fetch_object($r2))
				{
					$teka 	= $_GET['custom_field_value_'.$ids]; //!empty($pid) ? get_post_meta($pid, 'custom_field_ID_'.$ids) : "" ;

				
					if(is_array($teka))
					{	
						$tekam = '';
						
						foreach($teka as $te)
						{
							
							if($te == $row2->valval) { $tekam = "checked='checked'"; break; }
						}	
						
									
					}
					else $tekam = '';
					
			
					
					$arr[$i]['value']  .= '<input '.$tekam.' type="checkbox" value="'.$row2->valval.'" name="custom_field_value_'.$ids.'[]"> '.$row2->valval.'<br/>';
				}

		}
		
		if($tp == 2) //select
		{
			$arr[$i]['value']  = '<select class="'.$clas_op.'" name="custom_field_value_'.$ids.'" /><option value="">'.__('Select','Walleto').'</option>';
			
				$s2 = "select * from ".$wpdb->prefix."walleto_custom_options where custid='$ids' order by ordr ASC ";
				$r2 = $wpdb->get_results($s2);
				
				if(count($r2) > 0)
				foreach($r2 as $row2) // = mysql_fetch_object($r2))
				{
					$teka 	= ''; //!empty($pid) ? get_post_meta($pid, 'custom_field_ID_'.$ids) : "" ;
					
					if(!empty($teka))
					{	
						foreach($teka as $te)
						{
							if($te == $row2->valval) { $teka = "selected='selected'"; break; }
						}	
						
						$teka = '';			
					}
					else $teka = '';
					
					if(isset($_GET['custom_field_value_'.$ids]) && $_GET['custom_field_value_'.$ids] == $row2->valval)
					$value = "selected='selected'" ;
					else $value = $teka;
					
					
					$arr[$i]['value']  .= '<option '.$value.' value="'.$row2->valval.'">'.$row2->valval.'</option>';
				
				}
			$arr[$i]['value']  .= '</select>';
		}
		
		$i++;
	}
	
	return $arr;
}


/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function walleto_get_CATID($slug)
{
	$c = get_term_by('slug', $slug, 'product_cat');	
	return $c->term_id;
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_get_trial_link()
{
	$perm = walleto_using_permalinks();
	
	if($perm) return get_permalink(get_option('Walleto_my_account_shop_setup_page_id')) . "?activate_trial=1";
	return get_permalink(get_option('Walleto_my_account_shop_setup_page_id')) . "&activate_trial=1";	
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_get_product_variations()
{
	global $wpdb;
	$s = "select * from ".$wpdb->prefix."walleto_variations order by name asc";
	$r = $wpdb->get_results($s);
	if(count($r) > 0)
	{
		return $r;	
	}
	return false;
}


/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/


function walleto_get_categories_slug($taxo, $selected = "", $include_empty_option = "", $ccc = "")
{
	$args = "orderby=name&order=ASC&hide_empty=0&parent=0";
	$terms = get_terms( $taxo, $args );
	
	$ret = '<select name="'.$taxo.'_cat" class="'.$ccc.'" id="'.$ccc.'">';
	if(!empty($include_empty_option)){
		
		if($include_empty_option == "1") $include_empty_option = "Select";
	 	$ret .= "<option value=''>".$include_empty_option."</option>";
	 }
	
	if(empty($selected)) $selected = -1;
	
	foreach ( $terms as $term )
	{
		$id = $term->slug;
		$ide = $term->term_id;
		
		$ret .= '<option '.($selected == $id ? "selected='selected'" : " " ).' value="'.$id.'">'.$term->name.'</option>';
		
		$args = "orderby=name&order=ASC&hide_empty=0&parent=".$ide;
		$sub_terms = get_terms( $taxo, $args );	
		
		if($sub_terms)
		foreach ( $sub_terms as $sub_term )
		{
			$sub_id = $sub_term->slug; 
			$ret .= '<option '.($selected == $sub_id ? "selected='selected'" : " " ).' value="'.$sub_id.'">&nbsp; &nbsp;|&nbsp;  '.$sub_term->name.'</option>';
			
			$args2 = "orderby=name&order=ASC&hide_empty=0&parent=".$sub_term->term_id;
			$sub_terms2 = get_terms( $taxo, $args2 );	
			
			if($sub_terms2)
			foreach ( $sub_terms2 as $sub_term2 )
			{
				$sub_id2 = $sub_term2->slug; 
				$ret .= '<option '.($selected == $sub_id2 ? "selected='selected'" : " " ).' value="'.$sub_id2.'">&nbsp; &nbsp; &nbsp; &nbsp;|&nbsp;  
				'.$sub_term2->name.'</option>';
				
				$args3 = "orderby=name&order=ASC&hide_empty=0&parent=".$sub_term2->term_id;
				$sub_terms3 = get_terms( $taxo, $args3 );
				
				if($sub_terms3)
				foreach ( $sub_terms3 as $sub_term3 )
				{
					$sub_id3 = $sub_term3->slug; 
					$ret .= '<option '.($selected == $sub_id3 ? "selected='selected'" : " " ).' value="'.$sub_id3.'">&nbsp; &nbsp; &nbsp; &nbsp;|&nbsp;  
					'.$sub_term3->name.'</option>';
					
				}
			
			}
			
		}
		
	}
	
	$ret .= '</select>';
	
	return $ret;
	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function Walleto_send_email_when_item_is_paid_seller($oid, $the_seller_id,  $the_buyer_id) //received by seller
{
	$enable 	= get_option('Walleto_paid_order_seller_email_enable');
	$subject 	= get_option('Walleto_paid_order_seller_email_subject');
	$message 	= get_option('Walleto_paid_order_seller_email_message');	
	
	
	
	if($enable != "no"):
		
 
		$post_au 			= get_post($pid);
		$user 				= get_userdata($the_seller_id);
		$buyer 				= get_userdata($the_buyer_id);
		$site_login_url 	= Walleto_login_url();
		$site_name 			= get_bloginfo('name');
		$account_url 		= get_permalink(get_option('Walleto_my_account_page_id'));
		
		$post 		= get_post($pid);
		$item_name 	= $post_au->post_title;
		$item_link 	= get_permalink(get_option('Walleto_my_account_aw_pay_page_id'));

		$find 		= array('##order_id##', '##seller_user##', '##buyer_user##', '##site_login_url##', '##your_site_name##', '##your_site_url##' , '##my_account_url##', '##order_link##');
   		$replace 	= array($oid, $user->user_login, $buyer->user_login, $site_login_url, $site_name, get_bloginfo('siteurl'), $account_url, $item_link);
		
		$tag		= 'Walleto_send_email_when_item_is_purchased_for_buyer';
		$find 		= apply_filters( $tag . '_find', 	$find );
		$replace 	= apply_filters( $tag . '_replace', $replace );
		
		$message 	= Walleto_replace_stuff_for_me($find, $replace, $message);
		$subject 	= Walleto_replace_stuff_for_me($find, $replace, $subject);
		
		//---------------------------------------------
		
		$email = $user->user_email;
		Walleto_send_email($user->user_email, $subject, $message);
		
		/* Buyer Shop Based Loyalty Points Calculation */
		$lty_pnts_allowed = get_field('is_lty_pnts_allowed', $shp_id);
		$loyaltyPriceOption  =  intval(get_field('shp_lty_amt', $shp_id));
		$loyaltyPointsOption =  intval(get_field('shp_lty_pnts', $shp_id));
		if($lty_pnts_allowed == "yes" && !empty($loyaltyPriceOption) && !empty($loyaltyPointsOption)) {
			$perdollarloyalty = $pnts = 0;			
			$usr_shp_lty_key = "shp_".$shp_id."_loyalty_points";
			$perdollarloyalty = $loyaltyPointsOption/$loyaltyPriceOption;
			$userLoyaltyPoints = get_user_meta($the_buyer_id, $usr_shp_lty_key, true);
			$userLoyaltyPoints = ($userLoyaltyPoints) ? $userLoyaltyPoints : 0;
			$userLoyaltyPoints = $userLoyaltyPoints + ($perdollarloyalty*$orderSellerTotal);
			$pnts = round( $userLoyaltyPoints, 0, PHP_ROUND_HALF_DOWN );
			update_user_meta($the_buyer_id, $usr_shp_lty_key, $pnts);
		}			
		/* Buyer Shop Based Loyalty Points Calculation */			
		
	endif;
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function Walleto_send_email_when_item_is_paid_buyer($oid, $the_buyer_id) //received by buyer
{
	$enable 	   = get_option('Walleto_paid_order_buyer_email_enable');
	$subject 	   = get_option('Walleto_paid_order_buyer_email_subject');
	$message 	   = get_option('Walleto_paid_order_buyer_email_message');	

	if($enable != "no"):			
		$buyer 		    = get_userdata($the_buyer_id);	
		$site_login_url = Walleto_login_url();
		$site_name 		= get_bloginfo('name');
		$account_url 	= get_permalink(get_option('Walleto_my_account_page_id'));
		$tot_head		="";
		
		$lnk 		= walleto_get_order_content_link($oid);
		$find 		= array('##buyer_user##', '##site_login_url##', '##your_site_name##', '##your_site_url##' , '##my_account_url##', '##order_id##', '##order_link##');
   		$replace 	= array($buyer->user_login, $site_login_url, $site_name, get_bloginfo('siteurl'), $account_url, $oid, $lnk);
		
		$tag		= 'Walleto_send_email_when_item_is_paid_buyer';
		$find 		= apply_filters( $tag . '_find', 	$find );
		$replace 	= apply_filters( $tag . '_replace', $replace );
		
		$message 	= Walleto_replace_stuff_for_me($find, $replace, $message);
		$subject 	= Walleto_replace_stuff_for_me($find, $replace, $subject);
		
		//---------------------------------------------
			/*Spidanet: update buyer's loyalty points starts*/

		$loyaltyPriceOption  =  get_option('Walleto_loyalty_price');
		$loyaltyPointsOption =  get_option('Walleto_loyalty_points');
		if(!empty($loyaltyPriceOption) && !empty($loyaltyPointsOption)) {
			$perdollarloyalty = $pnts = 0;
			$orderDetails = walleto_get_order_obj($oid);
			$orderTotal = $orderDetails->totalprice;
			$perdollarloyalty = $loyaltyPointsOption/$loyaltyPriceOption;
			$userLoyaltyPoints = get_user_meta($the_buyer_id, 'loyalty_points',true);
			$userLoyaltyPoints = ($userLoyaltyPoints) ? $userLoyaltyPoints : 0;
			$userLoyaltyPoints = $userLoyaltyPoints + ($perdollarloyalty*$orderTotal);
			$pnts = round( $userLoyaltyPoints, 0, PHP_ROUND_HALF_DOWN );
			update_user_meta($the_buyer_id, 'loyalty_points',$pnts);
		}
		/*Spidanet: update buyer's loyalty points ends*/



		if($message!=''){
			Walleto_send_email($buyer->user_email, $subject, $message);
		}
	 
	
	endif;
	// Sending receipt of shipping in a separate email
	wl_send_dlvry_receipt($oid, $the_buyer_id);
	
	// Check if any draw is enabled and this user transaction is eligible for any enabled draw.
	Walleto_add_draw_entries($oid, $the_buyer_id); 
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function walleto_prepare_rating($fromuser, $touser, $order_id)
{

		global $wpdb;
		
		$s = "select * from ".$wpdb->prefix."walleto_ratings where touser='$touser' AND fromuser='$fromuser' AND orderid='$order_id'";
		$r = $wpdb->get_results($s);
		
		if(count($r) == 0)
		{
			
			$tm = current_time('timestamp',0);			
			$s = "insert into ".$wpdb->prefix."walleto_ratings (fromuser, touser, orderid, datemade) values('$fromuser',	'$touser', '$order_id', '$tm')";				
			$wpdb->query($s);
			
		
			
			$ratings_for_bid_id = get_option($pid,'ratings_for_ord_id_' . $order_id. $fromuser . $touser);
			
			if(empty($ratings_for_bid_id))
			{
				update_option('ratings_for_ord_id_' . $order_id. $fromuser . $touser, "donE");
				Walleto_send_email_when_review_needs_to_be_awarded($order_id, $fromuser, 	$touser);
				Walleto_send_email_when_review_needs_to_be_awarded($order_id, $touser, 		$fromuser);
			
			}
			
			 
		
		}
 
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_send_email_when_review_needs_to_be_awarded($oid, $rated_user_uid, $awarding_user_uid) //received by buyer
{
	$enable 	= get_option('Walleto_review_to_award_email_enable');
	$subject 	= get_option('Walleto_review_to_award_email_subject');
	$message 	= get_option('Walleto_review_to_award_email_message');	
	
	
	
	if($enable != "no"):
		
 
		$rated_user		= get_userdata($rated_user_uid);
		$awarding_user  = get_userdata($awarding_user_uid);
		
		$user 			= get_userdata($post->post_author);
		$site_login_url = Walleto_login_url();
		$site_name 		= get_bloginfo('name');
		$account_url 	= get_permalink(get_option('Walleto_my_account_page_id'));

		
		$find 		= array('##rated_user##', '##awarding_user##', '##site_login_url##', '##your_site_name##', '##your_site_url##' , '##my_account_url##', '##item_name##', '##item_link##');
   		$replace 	= array($rated_user->user_login, $awarding_user->user_login, $site_login_url, $site_name, get_bloginfo('siteurl'), $account_url, $post->post_title, get_permalink($pid));
		
		$tag		= 'Walleto_send_email_when_review_needs_to_be_awarded';
		$find 		= apply_filters( $tag . '_find', 	$find );
		$replace 	= apply_filters( $tag . '_replace', $replace );
		
		$message 	= Walleto_replace_stuff_for_me($find, $replace, $message);
		$subject 	= Walleto_replace_stuff_for_me($find, $replace, $subject);
		
		//---------------------------------------------

		Walleto_send_email($awarding_user->user_email, $subject, $message);
	
	endif;
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/	
function walleto_check_if_order_is_paid_fully($oid)
{
	global $wpdb;
	$s = "select id from ".$wpdb->prefix."walleto_order_contents where orderid='$oid' AND paid='0'";
	$r = $wpdb->get_results($s);
	
	if(count($r) == 0) return true;
	return false;	
}


/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_check_if_order_is_shipped_fully($oid)
{
	global $wpdb;
	$s = "select id from ".$wpdb->prefix."walleto_order_contents where orderid='$oid' AND delivered='0'";
	$r = $wpdb->get_results($s);
	
	if(count($r) == 0) return true;
	return false;	
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_send_email_posted_item_approved_admin($pid)
{
	$enable 	= get_option('Walleto_new_item_email_approve_admin_enable');
	$subject 	= get_option('Walleto_new_item_email_approve_admin_subject');
	$message 	= get_option('Walleto_new_item_email_approve_admin_message');	
	
	if($enable != "no"):
	
		$post 			= get_post($pid);
		$user 			= get_userdata($post->post_author);
		$site_login_url = Walleto_login_url();
		$site_name 		= get_bloginfo('name');
		$account_url 	= get_permalink(get_option('Walleto_my_account_page_id'));
		

		$find 		= array('##username##', '##username_email##', '##site_login_url##', '##your_site_name##', '##your_site_url##' , '##my_account_url##', '##item_name##', '##item_link##');
   		$replace 	= array($user->user_login, $user->user_email, $site_login_url, $site_name, get_bloginfo('siteurl'), $account_url, $post->post_title, get_permalink($pid));
		
		$tag		= 'Walleto_send_email_posted_item_approved_admin';
		$find 		= apply_filters( $tag . '_find', 	$find );
		$replace 	= apply_filters( $tag . '_replace', $replace );
		
		$message 	= Walleto_replace_stuff_for_me($find, $replace, $message);
		$subject 	= Walleto_replace_stuff_for_me($find, $replace, $subject);
		
		//---------------------------------------------
		
		$email = get_bloginfo('admin_email');
		Walleto_send_email($email, $subject, $message);
	
	endif;
}	

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_search_into($custid, $val)
	{
		global $wpdb;
		$s = "select * from ".$wpdb->prefix."walleto_custom_relations where custid='$custid'";
		$r = $wpdb->get_results($s);
		
		if(count($r) == 0) return 0;
		else
		foreach($r as $row) // = mysql_fetch_object($r))
		{
			if($row->catid == $val) return 1;
		}
	
		return 0;
	}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/	
function Walleto_send_email_posted_item_not_approved($pid)
{
	$enable 	= get_option('Walleto_new_item_email_not_approved_enable');
	$subject 	= get_option('Walleto_new_item_email_not_approved_subject');
	$message 	= get_option('Walleto_new_item_email_not_approved_message');	
	
	if($enable != "no"):
	
		$post 			= get_post($pid);
		$user 			= get_userdata($post->post_author);
		$site_login_url = Walleto_login_url();
		$site_name 		= get_bloginfo('name');
		$account_url 	= get_permalink(get_option('Walleto_my_account_page_id'));
		

		$find 		= array('##username##', '##username_email##', '##site_login_url##', '##your_site_name##', '##your_site_url##' , '##my_account_url##', '##item_name##', '##item_link##');
   		$replace 	= array($user->user_login, $user->user_email, $site_login_url, $site_name, get_bloginfo('siteurl'), $account_url, $post->post_title, get_permalink($pid));
		
		$tag		= 'Walleto_send_email_posted_item_not_approved';
		$find 		= apply_filters( $tag . '_find', 	$find );
		$replace 	= apply_filters( $tag . '_replace', $replace );
		
		$message 	= Walleto_replace_stuff_for_me($find, $replace, $message);
		$subject 	= Walleto_replace_stuff_for_me($find, $replace, $subject);
		
		//---------------------------------------------

		Walleto_send_email($user->user_email, $subject, $message);
	
	endif;	
	
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_send_email_posted_item_not_approved_admin($pid)
{
	$enable 	= get_option('Walleto_new_item_email_not_approve_admin_enable');
	$subject 	= get_option('Walleto_new_item_email_not_approve_admin_subject');
	$message 	= get_option('Walleto_new_item_email_not_approve_admin_message');	
	
	if($enable != "no"):
	
		$post 			= get_post($pid);
		$user 			= get_userdata($post->post_author);
		$site_login_url = Walleto_login_url();
		$site_name 		= get_bloginfo('name');
		$account_url 	= get_permalink(get_option('Walleto_my_account_page_id'));
		

		$find 		= array('##username##', '##username_email##', '##site_login_url##', '##your_site_name##', '##your_site_url##' , '##my_account_url##', '##item_name##', '##item_link##');
   		$replace 	= array($user->user_login, $user->user_email, $site_login_url, $site_name, get_bloginfo('siteurl'), $account_url, $post->post_title, get_permalink($pid));
		
		$tag		= 'Walleto_send_email_posted_item_not_approved_admin';
		$find 		= apply_filters( $tag . '_find', 	$find );
		$replace 	= apply_filters( $tag . '_replace', $replace );
		
		$message 	= Walleto_replace_stuff_for_me($find, $replace, $message);
		$subject 	= Walleto_replace_stuff_for_me($find, $replace, $subject);
		
		//---------------------------------------------
		
		$email = get_bloginfo('admin_email');
		Walleto_send_email($email, $subject, $message);
	
	endif;	
	
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
add_action('admin_notices', 						'walleto_admin_notices');
function walleto_admin_notices(){
    
		if(!function_exists('wp_pagenavi')) {
		echo '<div class="updated">
		   <p>For the <strong>Walleto Theme</strong> you need to install the wp pagenavi plugin. 
		   Install it from <a href="http://wordpress.org/extend/plugins/wp-pagenavi"><strong>here</strong></a>.</p>
		</div>';
								}
								
	if(!function_exists('bcn_display')) {
		echo '<div class="updated">
		   <p>For the <strong>Walleto Theme</strong> you need to install the Breadcrumb NavXT plugin. 
		   Install it from <a href="http://wordpress.org/extend/plugins/breadcrumb-navxt/"><strong>here</strong></a>.</p>
		</div>';
								}	
	}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_small_shop_display()
{
	global $post;
	
	?>
    
    
    
    <div class="post_sml small-padd-top" >
                <div class="image_holder2">
                <a href="<?php the_permalink(); ?>"><?php echo Walleto_get_first_post_image(get_the_ID(),50,50, 'attachment-50x50'); ?></a>
                </div>
                <div  class="title_holder2_shop" > 
                     <h4><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">
                        <?php   the_title();  ?></a></h4>
                        
                        <p class="mypostedon2">
                        <?php _e("Shop Category",'Walleto');?> <?php echo get_the_term_list( get_the_ID(), 'product_cat', '', ', ', '' ); ?><br/>
                       
					    
                        
                                <span class="product_price_m"><?php echo substr($post->post_content,0,110); ?></span>
                      
                       
                        </p>
                       
                     
                
                      
                     </div></div> <?php	
	
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_small_post($param = '')
{
			$ending 	= get_post_meta(get_the_ID(), 'ending', true);
			$sec 		= $ending - current_time('timestamp',0);
			$location 	= get_post_meta(get_the_ID(), 'Location', true);
			

			$price 		= get_post_meta(get_the_ID(), 'price', true);			
			$closed 	= get_post_meta(get_the_ID(), 'closed', true);
			$views 		= get_post_meta(get_the_ID(), 'views', true);
			$rnd = rand(1,999);
			
?>
				<div class="post_sml small-padd-top" >
                <div class="image_holder2">
                <a href="<?php the_permalink(); ?>"><?php echo Walleto_get_first_post_image(get_the_ID(),50,50, 'attachment-50x50'); ?></a>
                </div>
                <div  class="title_holder2" > 
                     <h4><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">
                        <?php   the_title();  ?></a></h4>
                        
                        <p class="mypostedon2">
                        <?php _e("Posted in",'Walleto');?> <?php echo get_the_term_list( get_the_ID(), 'product_cat', '', ', ', '' ); ?><br/>
                       
					    
                       <?php					   
					   		if($param == 'view'):							
							?>
                    		
							<?php _e("Views",'Walleto');?>: <?php echo $views; ?>
                    		
							<?php else: ?>
                       
                      		<span style="float:left"><?php _e("Price:",'Walleto');?>&nbsp; </span>
                                <span class="product_price_m"><?php echo walleto_get_show_price(Walleto_get_item_price(get_the_ID())); ?></span>
                      
                      <?php endif; ?> 
                        </p>
                       
                     
                
                     
                     </div></div> <?php	
}	

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/	
function walleto_is_owner_of_post()
{
	
	if(!is_user_logged_in())
		return false;
	
	global $current_user;
	get_currentuserinfo();
	
	$post = get_post(get_the_ID());
	if($post->post_author == $current_user->ID) return true;
	return false;	
	
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function walleto_get_current_view_grid_list()
{
	
		if(	$_SESSION['view_tp'] == "list") return "list"; else return "grid";
	
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_switch_link_from_home_page($tp)
{

	return get_bloginfo('siteurl')."?switch_grd=".$tp."&get_urls=" . urlencode(Walleto_curPageURL());
		
}
 
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
 
function Walleto_get_post_blog()
{
			
						 $arrImages =& get_children('post_type=attachment&post_mime_type=image&post_parent=' . get_the_ID());
						 $post_thumbnail_id = get_post_thumbnail_id( get_the_ID());

						 if(!empty($post_thumbnail_id )) 
						 {
							 
					        $sThumbUrl 	= wp_get_attachment_thumb_url($post_thumbnail_id );
					        $sImgString = '<a href="' . get_permalink() . '">' .
	                          '<img class="image_class" src="' . $sThumbUrl . '" width="100" height="100" />' .
                      		'</a>';
							 							 
						 }
						 else 
						 {
								$sImgString = '<a href="' . get_permalink() . '">' .
	                          '<img class="image_class" src="' . get_bloginfo('template_url') . '/images/nopic.png" width="100" height="100" />' .
                      			'</a>'; 
							 
						 }
					
			 
?>
				<div class="post vc_POST" id="post-<?php the_ID(); ?>">
                <div class="padd10">
                <div class="image_holder" style="width:120px">
                <?php echo $sImgString; ?>
                </div>
                <div  class="title_holder" style="width:510px" > 
                     <h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">
                        <?php the_title(); ?></a></h2>
                        <p class="mypostedon"><?php _e('Posted on','Walleto'); ?> <?php the_time('F jS, Y') ?>  <?php _e('by','Walleto'); ?> 
                       <?php the_author() ?>
                  </p>
                       <p class="blog_post_preview"> <?php the_excerpt(); ?></p>
                       
                      
                        <a href="<?php the_permalink() ?>" class="post_bid_btn"><?php _e('Read More','Walleto'); ?></a>
                         
                     </div></div>
                     
                   
                     
                     </div>
<?php
}


/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_get_purchase_mem_link($mem)
{
	$id = get_option('Walleto_my_account_pur_mem_page_id');
	if(walleto_using_permalinks()) return get_permalink($id). "?mem=" . $mem;
	return get_permalink($id). "&mem=" . $mem;	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_get_purchase_mem_link_ewallet($mem, $agree = '')
{
	$id = get_option('Walleto_my_account_pur_mem_crds_page_id');
	if(walleto_using_permalinks()) return get_permalink($id). "?mem=" . $mem. $agree;
	return get_permalink($id). "&mem=" . $mem. $agree;	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_send_email_posted_item_approved($pid)
{
	$enable 	= get_option('Walleto_new_item_email_approved_enable');
	$subject 	= get_option('Walleto_new_item_email_approved_subject');
	$message 	= get_option('Walleto_new_item_email_approved_message');	
	
	if($enable != "no"):
	
		$post_au 			= get_post($pid);
		$user 			= get_userdata($post_au->post_author);
		$site_login_url = Walleto_login_url();
		$site_name 		= get_bloginfo('name');
		$account_url 	= get_permalink(get_option('Walleto_my_account_page_id'));
		
		$post 		= get_post($pid);
		$item_name 	= $post_au->post_title;
		$item_link 	= get_permalink($pid);

		$find 		= array('##username##', '##username_email##', '##site_login_url##', '##your_site_name##', '##your_site_url##' , '##my_account_url##', '##item_name##', '##item_link##');
   		$replace 	= array($user->user_login, $user->user_email, $site_login_url, $site_name, get_bloginfo('siteurl'), $account_url, $item_name, $item_link);
		
		$tag		= 'Walleto_send_email_posted_item_approved';
		$find 		= apply_filters( $tag . '_find', 	$find );
		$replace 	= apply_filters( $tag . '_replace', $replace );
		
		$message 	= Walleto_replace_stuff_for_me($find, $replace, $message);
		$subject 	= Walleto_replace_stuff_for_me($find, $replace, $subject);
		
		//---------------------------------------------
		
		$email = $user->user_email;
		Walleto_send_email($user->user_email, $subject, $message);
		
	endif;		
	
}


function Walleto_send_email_when_item_is_purchased_for_buyer($order_id, $buyer_id)
{
	

	$the_buyer_id = $buyer_id;
	$oid          = $order_id;
	$enable 	= get_option('Walleto_buy_now_order_buyer_email_enable');
	$subject 	= get_option('Walleto_buy_now_order_buyer_email_subject');
	$message 	= get_option('Walleto_buy_now_order_buyer_email_message');
	$odr_vat 	= (get_option('Walleto_purchase_vat')) ? get_option('Walleto_purchase_vat') : 15;
	$odr_vat_perc = $odr_vat / 100;

	$orderDetails  	= walleto_get_order_obj($oid);
	$orderTotal   	= $orderDetails->totalprice;
	$orderDis      	= $orderDetails->discount;
	$orderShp		= $orderDetails->shipping;
	$orig_orderShp	= $orderShp / (1+$odr_vat_perc); // Original delivery amount(without VAT)
	$orig_orderShp 	= Walleto_formats($orig_orderShp, 2);
	$orderShpTax 	= $orderShp - $orig_orderShp;
	$orderPkup		= 0;
	$orderPkupTax 	= 0;
	$orderPkup_ttl	= 0;
	$Pkupinf		= $orderDetails->pickup;
	if(!empty($Pkupinf)) {
		$infarr = "";
		$infarr = explode('|', $orderDetails->pickup);
		$orderPkup_ttl = $infarr[1]; // Total pick up amount including VAT
		$orderPkup = $orderPkup_ttl / (1+$odr_vat_perc); // Original pick up amount(without VAT)
		$orderPkup = Walleto_formats($orderPkup, 2);
		$orderPkupTax = $orderPkup_ttl - $orderPkup;
	}
	
	if($orderDis>0)
		$orderOldTotal = $orderTotal+$orderDis;
	else {
		$orderOldTotal = $orderTotal;
		$orderDis = 0;
	}	
	$cust_details  ='';
	$invoice_head  = '';

	
	if($enable != "no"):
	
		/*Spidanet: Sending proforma invoice starts */

		global $wpdb;
		
		$buyer 		    = get_userdata($the_buyer_id);

		$orderConentSql ="SELECT pid,sid,stitle,price,quant,discount FROM ".$wpdb->prefix."walleto_order_contents WHERE orderid='$oid'";
		$orderRs = $wpdb->get_results($orderConentSql);
		$userAdd 			= ""; 
		$regAdd 			= ""; 
		$inv_no 			= "";
		$add1 				= get_cimyFieldValue($the_buyer_id, "ADDRESS_LINE_1");
		$add2 				= get_cimyFieldValue($the_buyer_id, "ADDRESS_LINE_2");
		//$userAdd			= $add1.$add2;
		$userAdd = $add1;
		if(!empty($add2)) {
			$userAdd .= "\n".$add2;
		}
		$userTel 			= get_cimyFieldValue($the_buyer_id, "TELEPHONE");
		
		$userCity 			= get_cimyFieldValue($the_buyer_id, "CITY");
		$usercty 			= Walleto_get_city($userCity);
		
		$userCountry 		= get_cimyFieldValue($the_buyer_id, "COUNTRY");
		
		$userRgn 			= get_cimyFieldValue($the_buyer_id, "REGION");
		$userrgn 			= Walleto_get_region($userRgn);
		
		$userSbrb 			= get_cimyFieldValue($the_buyer_id, "SUBURB");
		$usersbrb 			= Walleto_get_suburb($userSbrb);
		
		$userZip 			= get_cimyFieldValue($the_buyer_id, "ZIP");		
		$item_details		='';
		$logo_details		='<table><tbody>';
		
		foreach ($orderRs as $logoKey => $logoValue) {			
		    $postLogo=get_field('shop_logo',$logoValue->sid);
			$logoImg = $postLogo["url"];

			if($logoImg!=""){
				$logo_details  .= '<tr><td><img src="'.$logoImg.'" width="150px" /><td></tr>';
			}
		}
		/* Generate proforma invoice number and store it for further use */
		$inv_no = wl_generate_odr_proinvnum();
		if(empty($inv_no)) {
			$inv_no = rand( 100000 , 99999999 );
		}
		
		wl_update_order_meta($oid, "proformainv_num", $inv_no);

		/* Store buyer city for further use */
		wl_update_order_meta($oid, "buyer_city", $usercty->cty_name);
		
		/* Store buyer registered address for further use in logistics panel*/
		$regAdd = $userAdd . "|" . $usersbrb->sbrb_name . "|" . $usercty->cty_name . "|" . $userrgn . "|" . $userCountry;
		if(!empty($userZip)) {
			$regAdd .= "|" . $userZip;
		}
		update_user_meta($the_buyer_id, 'reg_add', $regAdd);
		$logo_details .="</table>";
		$invoice_head = '<table  style="border-collapse:collapse;width:90%"><tr><td style="border:1px solid #000000; text-align:center;" colspan="5">HAMMER AND TONGUES AFRICA HOLDINGS</td></tr><tr><td style="border:1px solid #000000; text-align:center;" colspan="1"><img alt="Hammer and Tongues Africa Holdings" src="http://shopping.hammerandtongues.com/wp-content/themes/Walleto/images/online_logo.png?chk=1" /></td><td style="border-top: 1px solid #000000; border-left: 1px solid #000000; border-bottom: 1px solid #000000;" colspan="3">'.__("All prices are inclusive of VAT.", "Walleto").'<br/><strong>'.__("BUYER PROFORMA INVOICE", "Walleto").'</strong><table  style="border-collapse: collapse;margin-bottom:5px;"><tbody><tr><td style="border:1px solid #000000;">'.__("INVOICE DATE: ", "Walleto").'</td><td style="border:1px solid #000000;">'.date( 'Y-m-d', current_time( 'timestamp', 0 ) ).'</td></tr><tr><td style="border:1px solid #000000;">'.__("INVOICE NO: ", "Walleto").'</td><td style="border:1px solid #000000;">'.intval($inv_no).'</td></tr><tr><td style="border:1px solid #000000;">'.__("ORDER NO. ", "Walleto").'</td><td style="border:1px solid #000000;">'.$oid.'</td></tr></tbody></table></td><td style= "border-top: 1px solid #000000;border-bottom: 1px solid #000000; border-right: 1px solid #000000;" >&nbsp;</td></tr></tbody>';
		$cust_details = '<tbody><tr><td style="border:1px solid #000000;" colspan="2"><u>'.__("CUSTOMER", "Walleto").'</u><br />'.$buyer->first_name.' '.$buyer->last_name.'<br />'.cimy_uef_sanitize_content($userAdd).'<br />'.$usersbrb->sbrb_name.'<br />'.$usercty->cty_name.'<br />'.$userrgn.'<br />'.cimy_uef_sanitize_content($userCountry).'<br />'.cimy_uef_sanitize_content($userZip).'</td><td style="border-top: 1px solid rgb(0, 0, 0); border-bottom: 1px solid rgb(0, 0, 0); border-left: 1px solid rgb(0, 0, 0);" colspan="2">TEL: '.cimy_uef_sanitize_content($userTel).'<br />CUST NO.: '.$buyer->ID.'</td><td style= "border-top: 1px solid #000000; border-bottom: 1px solid #000000;border-right: 1px solid #000000;">&nbsp;</td></tr></tbody>';
		$item_details  = '<tbody><tr><th style="border:1px solid #000000;">STOCK NR</th><th style="border:1px solid #000000;">DESCRIPTION</th><th style="border:1px solid #000000;">SHOP</th><th style="border:1px solid #000000;">QUANTITY</th><th style="border:1px solid #000000;">AMOUNT</th></tr>';
		$rowTotal=0;
		$shopAddressArr=array();
		foreach ($orderRs as $key => $value) {
			$abt_off = "";
			$shopspost=array($value->sid, $value->stitle);
			if($value->discount) {
				$abt_off = '<p style="font-size: 11px;margin: 0;">'.Walleto_get_show_price($value->discount).__(" discount applied", "Walleto").'</p>';
			}			
			array_push($shopAddressArr,$shopspost);
			$item_details  .= '<tr><td style="border:1px solid #000000;text-align:center;">'.$value->pid.'</td><td style="border:1px solid #000000;text-align:center;" ><strong>'.get_the_title($value->pid).$abt_off.'</strong></td><td style="border:1px solid #000000;text-align:center;" >'.$shopspost[1].'</td><td style="border:1px solid #000000;text-align:center;">'.$value->quant.'</td><td style="border:1px solid #000000;text-align:center;" >'.Walleto_formats(($value->price*$value->quant), 2).'</td></tr>';
			$rowTotal +=$value->price*$value->quant;
				
		}		
		$item_details .= '</tbody></table>';
	
		$grand_tot = '<table  style="border-collapse: collapse;width:90%">';	
		$grand_tot .= '<tbody><tr><th></th><th></th><th>VAT</th><th></th></tr><tr><td style="border:1px solid #000000;" ><strong>'.__("SALES", "Walleto").'</strong></td><td style="border:1px solid #000000;">'.$orderOldTotal.'</td><td style="border:1px solid #000000;">0</td><td style="border:1px solid #000000;" >'.$orderOldTotal.'</td></tr>';
		
		// If discount available
		if($orderDis > 0){
			$grand_tot .= '<tr><td style="border:1px solid #000000;"><strong>'.__("DISCOUNT", "Walleto").'</strong></td><td style="border:1px solid #000000;">'.$orderDis.'</td><td style="border:1px solid #000000;">0</td><td style="border:1px solid #000000;">'.$orderDis.'</td></tr>';
		}
		// If shipping available
		if($orderShp > 0){
			$grand_tot .= '<tr><td style="border:1px solid #000000;"><strong>'.__("SHIPPING", "Walleto").'</strong></td><td style="border:1px solid #000000;">'.$orig_orderShp.'</td><td style="border:1px solid #000000;">'.$orderShpTax.'</td><td style="border:1px solid #000000;">'.$orderShp.'</td></tr>';
		} else {
			$orderShp = 0;
		}		
		// If pick up available
		if($orderPkup > 0){
			$grand_tot .= '<tr><td style="border:1px solid #000000;"><strong>'.__("PICKUP", "Walleto").'</strong></td><td style="border:1px solid #000000;">'.$orderPkup.'</td><td style="border:1px solid #000000;">'.$orderPkupTax.'</td><td style="border:1px solid #000000;">'.$orderPkup_ttl.'</td></tr>';
		}
		
		$grand_tot .= '<tr><td style="border:1px solid #000000;"><strong>'.__("TOTAL DUE", "Walleto").'</strong></td><td style="border:1px solid #000000;"><strong>'.($orig_orderShp + $orderTotal + $orderPkup).'</strong></td><td style="border:1px solid #000000;"><strong>'.($orderShpTax + $orderPkupTax).'</strong></td><td style="border:1px solid #000000;"><strong>'.($orderTotal + $orderShp + $orderPkup_ttl).'</strong></td></tr></tbody>';
		$grand_tot .= '</table>';

		/*Spidanet: Colletion points starts*/
		$collectionPoints = '';	
		$collectionPoints .= '<br/><br/><div><b>'.__("COLLECTION POINTS FOR PRODUCTS", "Walleto").'</b><br/><br/><table cellpadding="1" cellspacing="6">';

		$shopAddressArr = array_unique($shopAddressArr, SORT_REGULAR);
		$shpType = "";
		foreach ($shopAddressArr as $shp) {
			$shpAdd= get_post_meta($shp[0], 'address', true);
			$shpAdd2= get_post_meta($shp[0], 'address2', true);
			$shpCity= get_post_meta($shp[0], 'city', true);
			$shpCountry= get_post_meta($shp[0], 'country/region', true);
			$postLogo = get_field('shop_logo',$shp[0]);
			$shpType = get_field('shop_hnt_type',$shp[0]);
			$shpImg = $postLogo["url"];
			$shpFullAdd= $shpAdd.",&nbsp;".$shpAdd2.'<br/>'.$shpCity.",&nbsp;".$shpCountry;
			$collectionPoints .= '<tr><td>&nbsp;</td><td ><b>'.$shp[1].'</b></td></tr>';
			$collectionPoints .= '<tr><td><img src="'.$shpImg.'"  /></td>';
			$collectionPoints .= '<td >'.$shpFullAdd.'</td></tr>';

		}
		$collectionPoints .= '</table>';
		// To disable collection points in proforma in case of service
		if($shpType != "service") {
			$grand_tot .= $collectionPoints;
		}
		/*Spidanet: Colletion points ends*/


		$user 			= get_userdata($post->post_author);
		$site_login_url = Walleto_login_url();
		$site_name 		= get_bloginfo('name');
		$account_url 	= get_permalink(get_option('Walleto_my_account_page_id'));
		$tot_head		="";
		
		$lnk 		= walleto_get_order_content_link($oid);
		$find 		= array( '##invoicehead##', '##customerdetails##', '##totalhead##', '##itemdetails##','##grandtotal##', '##buyer_user##', '##site_login_url##', '##your_site_name##', '##your_site_url##' , '##my_account_url##', '##order_id##', '##order_link##');
   		$replace 	= array( $invoice_head, $cust_details, $tot_head, $item_details, $grand_tot , $buyer->user_login, $site_login_url, $site_name, get_bloginfo('siteurl'), $account_url, $oid, $lnk);
		

		$tag		= 'Walleto_send_email_when_item_is_purchased_for_buyer';
		$find 		= apply_filters( $tag . '_find', 	$find );
		$replace 	= apply_filters( $tag . '_replace', $replace );
		
		$message 	= Walleto_replace_stuff_for_me($find, $replace, $message);
		$subject 	= Walleto_replace_stuff_for_me($find, $replace, $subject);
		
		//---------------------------------------------
		
		if($message!=''){
			#Walleto_send_email($buyer->user_email, $subject, $message);
		}
		
		$inv_content = $message;
		if($message!='') {		
			require_once( get_template_directory().'/pdf/mpdf.php');
			$filename = "(BUYER)_PROFORMA_INVOICE_".date( 'Y-m-d H:i:s', current_time( 'timestamp', 0 ) ).".pdf";
			$filetitle = "(BUYER)_PROFORMA_INVOICE";
			$mpdf=new mPDF('','A4',11,'sans-serif');
			$mpdf->SetTitle($filetitle);
			//$mpdf->WriteHTML($inv_content);
			$mpdf->WriteHTML(utf8_encode($inv_content));
			$content = $mpdf->Output('', 'S');
			$content = chunk_split(base64_encode($content));
			$mailto = $buyer->user_email;
			$from_name = "admin";
			$from_mail = "online@hammerandtongues.com";
			$replyto = $from_mail;
			$uid = md5(uniqid(time()));		
			$txt_message = 'Hello '.$buyer->user_login.',<br /><br /><p>You have just placed an order with the order ID: <b>'.$oid.'</b> ( '.$lnk.' ).</p><p>You need to login into your account area, under outstanding payments and pay the item price.</p><p>Login here: '.$account_url.'</p><br /><br /><br /><p>Thank you,</p><p>'.$site_name.' Team</p>';

			//Headers of PDF and e-mail
			$header = "--$uid\r\n";
			$header .= "Content-Transfer-Encoding: 8bits\r\n";
			$header .= "Content-Type: text/html; charset=ISO-8859-1\r\n\r\n"; // or utf-8
			$header .= "$txt_message\r\n";
			$header .= "--$uid\r\n";
			$header .= "Content-Type: application/pdf; name=\"".$filename."\"\r\n";
			$header .= "Content-Disposition: attachment; filename=\"".$filename."\"\r\n";
			$header .= "Content-Transfer-Encoding: base64\r\n\r\n";
			$header .= "$content\r\n";
			$header .= "--$uid--\r\n";
			$header2 = "MIME-Version: 1.0\r\n";
			$header2 .= "From: ".$from_mail." \r\n";
			$header2 .= "Return-Path: $from_mail\r\n";
			$header2 .= "Content-type: multipart/mixed; boundary=\"$uid\"\r\n";
			$header2 .= "$uid\r\n";
			mail($mailto,$subject,$header,$header2, "-r".$from_mail);
		}	

		/*Send a copy to admin starts */

		$admin_email = get_option( 'admin_email' );
		$admiSubject = "PRO FORMA INVOICE SENT TO ".$buyer->user_login;
		
		if($message!=''){
			Walleto_send_email($admin_email, $admiSubject, $message);
	 	}

		
	endif;		
	
}

function Walleto_send_email_when_item_is_purchased_for_seller($order_id, $seller_id,$buyer_id)
{
	$enable 	= get_option('Walleto_buy_now_order_seller_email_enable');
	$subject 	= get_option('Walleto_buy_now_order_seller_email_subject');
	$message 	= get_option('Walleto_buy_now_order_seller_email_message');	
	
	if($enable != "no"):
	
		$seller 		= get_userdata($seller_id);
		$buyer 		    = get_userdata($buyer_id);
		
		$site_login_url = Walleto_login_url();
		$site_name 		= get_bloginfo('name');
		$account_url 	= get_permalink(get_option('Walleto_my_account_page_id'));

		$add1 				= get_cimyFieldValue($buyer_id, "ADDRESS_LINE_1");
		$add2 				= get_cimyFieldValue($buyer_id, "ADDRESS_LINE_2");
		//$userAdd			= $add1.$add2;
		$userAdd = $add1;
		if(!empty($add2)) {
			$userAdd .= "\n".$add2;
		}		
		$userTel 			= get_cimyFieldValue($buyer_id, "TELEPHONE");
		$userCity 			= get_cimyFieldValue($buyer_id, "CITY");
		$usercty 			= Walleto_get_city($userCity);
		
		$userRgn 			= get_cimyFieldValue($buyer_id, "REGION");
		$userrgn 			= Walleto_get_region($userRgn);		
		
		$userSbrb 			= get_cimyFieldValue($buyer_id, "SUBURB");
		$usersbrb 			= Walleto_get_suburb($userSbrb);
		
		$userZip 			= get_cimyFieldValue($buyer_id, "ZIP");		
		$userCountry 		= get_cimyFieldValue($buyer_id, "COUNTRY");		
		
		$lnk = walleto_get_order_content_link2($order_id,$seller_id);
		
		global $wpdb;
		$shp_id = 0;
		$orderSql ="SELECT pid,price,quant FROM ".$wpdb->prefix."walleto_order_contents WHERE orderid='$order_id'";
		$orderSellerRs = $wpdb->get_results($orderSql);
		
		$logoQuery = new WP_Query(array("author" => $seller_id,"post_type" =>"shop"));
		
		while ( $logoQuery->have_posts() ) {
			$logoQuery->the_post();
			$postLogo=get_field('shop_logo',get_the_ID());
			$postseller = get_field('seller',get_the_ID());						
			$shp_id = get_the_ID();
			$logoImg = $postLogo["url"];			
			if($logoImg !=""){
				$logoDetails  ='<table><tbody><tr>';
				
				$logoDetails .= '<td><img src="'.$logoImg.'" width="100px" /><td>';
				$logoDetails .="</tr></table>";				
			}
		}		
		 
	    $invoice_head = '<table  style="border-collapse:collapse;width:90%"><tr><td style="border: 1px solid #000000; text-align: center;"  colspan="1"><img alt="Hammer and Tongues Africa Holdings" src="http://shopping.hammerandtongues.com/wp-content/themes/Walleto/images/online_logo.png?chk=1" /><br/>'.$logoDetails.'</td><td style="border:1px solid #000000;" colspan="3"><table  style="border-collapse: collapse;margin-bottom:5px;"><tbody><tr><td style="border:1px solid #000000;">'.__("INVOICE DATE: ", "Walleto").'</td><td style="border:1px solid #000000;">'.date( 'Y-m-d', current_time( 'timestamp', 0 ) ).'</td></tr><tr><td style="border:1px solid #000000;">'.__("BUYER INVOICE NO: ", "Walleto").'</td><td style="border:1px solid #000000;">'.wl_get_order_proinvnum($order_id, $buyer_id).'</td></tr><tr><td style="border:1px solid #000000;">'.__("ORDER NO. ", "Walleto").'</td><td style="border:1px solid #000000;">'.$order_id.'</td></tr></tbody></table></td></tr></tbody>';
		$cust_details = '<tbody><tr><td style="border:1px solid #000000;" colspan="2"><u>'.__("CUSTOMER", "Walleto").'</u><br />'.$buyer->first_name.' '.$buyer->last_name.'<br />'.cimy_uef_sanitize_content($userAdd).'<br />'.$usersbrb->sbrb_name.'<br />'.$usercty->cty_name.'<br />'.$userrgn.'<br />'.cimy_uef_sanitize_content($userCountry).'<br />'.cimy_uef_sanitize_content($userZip).'</td><td style="border:1px solid #000000;" colspan="2">TEL: '.cimy_uef_sanitize_content($userTel).'<br />CUST NO.: '.$buyer->ID.'</td></tr></tbody>';
		$item_details  = '<tbody><tr><th style="border:1px solid #000000;">STOCK NR</th><th style="border:1px solid #000000;">DESCRIPTION</th><th style="border:1px solid #000000;">QUANTITY</th><th style="border:1px solid #000000;">AMOUNT</th></tr>';
		$rowTotal = 0;
		$orderSellerTotal = 0;
		
		foreach ($orderSellerRs as $itemkey => $itemvalue) {
			$prd = get_post($itemvalue->pid);
			if($seller_id == $prd->post_author){						
				$item_details  .= '<tr><td style="border:1px solid #000000;text-align:center">'.$itemvalue->pid.'</td><td style="border:1px solid #000000;text-align:center;" ><strong>'.get_the_title($itemvalue->pid).'</strong></td><td style="border:1px solid #000000;text-align:center;">'.$itemvalue->quant.'</td><td style="border:1px solid #000000;text-align:center;" >'.Walleto_formats(($itemvalue->price*$itemvalue->quant), 2).'</td></tr>';
				$rowTotal += $itemvalue->price*$itemvalue->quant;
				//$orderSellerTotal +=$rowTotal;				
			}				
		}		
		$orderSellerTotal = $rowTotal;
		$item_details  .= '<tr><td colspan="3" style="border:1px solid #000000;text-align:left;">'.__("TOTAL", "Walleto").'</td><td colspan="1" style="border:1px solid #000000;text-align:center;" >'.$rowTotal.'</td></tr>';
		$item_details .= '</tbody></table>';
		
		//echo $item_details;
		$grand_tot = '<table  style="border-collapse: collapse;width:90%">';	
		$grand_tot .= '<tbody><tr><th></th><th></th><th>VAT</th><th></th></tr><tr><td style="border:1px solid #000000;"><strong>'.__("SALES", "Walleto").'</strong></td><td style="border:1px solid #000000;">'.$orderSellerTotal.'</td><td style="border:1px solid #000000;">Inclusive</td><td style="border:1px solid #000000;">'.$orderSellerTotal.'</td></tr>';
		
		$grand_tot .= '<tbody><tr><td style="border:1px solid #000000;"><strong>'.__("TOTAL DUE", "Walleto").'</strong></td><td style="border:1px solid #000000;"><strong></strong></td><td style="border:1px solid #000000;"><strong>Inclusive</strong></td><td style="border:1px solid #000000;"><strong>'.$orderSellerTotal.'</strong></td></tr></tbody>';
		$grand_tot .= '</table>';
		
		$site_login_url = Walleto_login_url();
		$site_name 		= get_bloginfo('name');
		$account_url 	= get_permalink(get_option('Walleto_my_account_page_id'));
		$tot_head		="";
		
		$find 		= array('##invoicehead##', '##customerdetails##', '##totalhead##', '##itemdetails##','##grandtotal##', '##seller_user##', '##buyer_user##', '##site_login_url##', '##your_site_name##', '##your_site_url##' , '##my_account_url##', '##order_id##','##order_link##');
   		$replace 	= array($invoice_head, $cust_details, $tot_head, $item_details, $grand_tot, $seller->user_login, $buyer->user_login, $site_login_url, $site_name, get_bloginfo('siteurl'), $account_url, $order_id, $lnk);
		
		$tag		= 'Walleto_send_email_when_item_is_purchased_for_seller';
		$find 		= apply_filters( $tag . '_find', 	$find );
		$replace 	= apply_filters( $tag . '_replace', $replace );
		
		$message 	= Walleto_replace_stuff_for_me($find, $replace, $message);
		$subject 	= Walleto_replace_stuff_for_me($find, $replace, $subject);
		
		//---------------------------------------------

		Walleto_send_email($seller->user_email, $subject, $message);
		
	endif;
}

//==============================

function Walleto_send_email_when_item_is_shipped_for_buyer($order_id, $buyer_id, $seller_id)
{
	$enable 	= get_option('Walleto_ship_order_buyer_email_enable');
	$subject 	= get_option('Walleto_ship_order_buyer_email_subject');
	$message 	= get_option('Walleto_ship_order_buyer_email_message');	
	
	if($enable != "no"):
	
		$post_au 			= get_post($pid);
		$user 				= get_userdata($buyer_id);
		$user2 				= get_userdata($seller_id);
		$site_login_url 	= Walleto_login_url();
		$site_name 			= get_bloginfo('name');
		$account_url 		= get_permalink(get_option('Walleto_my_account_page_id'));
		
		$post 		= get_post($pid);
		$item_name 	= $post_au->post_title;
		$item_link 	= get_permalink(get_option('Walleto_my_account_all_orders_page_id'));

		$find 		= array('##order_id##', '##buyer_user##', '##seller_user##', '##site_login_url##', '##your_site_name##', '##your_site_url##' , '##my_account_url##', '##order_link##');
   		$replace 	= array($order_id, $user->user_login, $user2->user_login, $site_login_url, $site_name, get_bloginfo('siteurl'), $account_url, $item_link);
		
		$tag		= 'Walleto_send_email_when_item_is_shipped_for_buyer';
		$find 		= apply_filters( $tag . '_find', 	$find );
		$replace 	= apply_filters( $tag . '_replace', $replace );
		
		$message 	= Walleto_replace_stuff_for_me($find, $replace, $message);
		$subject 	= Walleto_replace_stuff_for_me($find, $replace, $subject);
		
		//---------------------------------------------
		
		$email = $user->user_email;
		Walleto_send_email($user->user_email, $subject, $message);
		
	endif;		
	
}

function Walleto_send_email_when_item_is_shipped_for_seller($order_id, $buyer_id, $seller_id)
{
	$enable 	= get_option('Walleto_ship_order_seller_email_enable');
	$subject 	= get_option('Walleto_ship_order_seller_email_subject');
	$message 	= get_option('Walleto_ship_order_seller_email_message');	
	
	if($enable != "no"):
	
		$post_au 			= get_post($pid);
		$user 				= get_userdata($buyer_id);
		$user2 				= get_userdata($seller_id);
		$site_login_url 	= Walleto_login_url();
		$site_name 			= get_bloginfo('name');
		$account_url 		= get_permalink(get_option('Walleto_my_account_page_id'));
		
		$post 		= get_post($pid);
		$item_name 	= $post_au->post_title;
		$item_link 	= get_permalink(get_option('Walleto_my_account_all_orders_page_id'));

		$find 		= array('##order_id##', '##buyer_user##', '##seller_user##', '##site_login_url##', '##your_site_name##', '##your_site_url##' , '##my_account_url##', '##order_link##');
   		$replace 	= array($order_id, $user->user_login, $user2->user_login, $site_login_url, $site_name, get_bloginfo('siteurl'), $account_url, $item_link);
		
		$tag		= 'Walleto_send_email_when_item_is_shipped_for_buyer';
		$find 		= apply_filters( $tag . '_find', 	$find );
		$replace 	= apply_filters( $tag . '_replace', $replace );
		
		$message 	= Walleto_replace_stuff_for_me($find, $replace, $message);
		$subject 	= Walleto_replace_stuff_for_me($find, $replace, $subject);
		
		//---------------------------------------------
		
		 
		Walleto_send_email($user2->user_email, $subject, $message);
		
	endif;		
	
}


/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_get_field_tp($nr)
{
		if($nr == "1") return "Text field";
		if($nr == "2") return "Select box";
		if($nr == "3") return "Radio Buttons";
		if($nr == "4") return "Check-box";
		if($nr == "5") return "Large text-area";	
		
		
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_check_if_shop_membership_is_valid($uid)
{
	$shop_id = walleto_get_auto_draft_shop($uid);	
	$dt = current_time('timestamp',0);
	
	$membership_available = get_post_meta($shop_id, 'membership_available', true);
	if( empty($membership_available) or $dt > $membership_available ) 
	{
		 
		return false;
		
	}
	else
	{
		return true;
	}
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_update_membership_for_shop($uid, $months)
{
	$shop_id = walleto_get_auto_draft_shop($uid);	
	$dt = current_time('timestamp',0);
	update_post_meta($shop_id, 'membership_available', $dt + ($months*30.5*24*3600));
	update_post_meta($uid, 'membership_available', $dt + ($months*30.5*24*3600));
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_get_shop_id($uid)
{
	return walleto_get_auto_draft_shop($uid);	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_send_email($recipients, $subject = '', $message = '') {
		
	$Walleto_email_addr_from 	= get_option('Walleto_email_addr_from');	
	$Walleto_email_name_from  	= get_option('Walleto_email_name_from');
	
	$message = stripslashes($message);
	$subject = stripslashes($subject); 
	
	if(empty($Walleto_email_name_from)) $Walleto_email_name_from  = "Walleto Theme";
	if(empty($Walleto_email_addr_from)) $Walleto_email_addr_from  = "Walleto@wordpress.org";
		
	$headers = 'From: '. $Walleto_email_name_from .' <'. $Walleto_email_addr_from .'>' . PHP_EOL;
	$Walleto_allow_html_emails = get_option('Walleto_allow_html_emails');
	if($Walleto_allow_html_emails != "yes") $html = false;
	else $html = true;

	$ok_send_email = true;
	$ok_send_email = apply_filters('Walleto_ok_to_send_emails', $ok_send_email);

	if($ok_send_email == true)
	{
		if ($html) {
			$headers .= "MIME-Version: 1.0\n";
			$headers .= "Content-Type: " . get_bloginfo('html_type') . "; charset=\"". get_bloginfo('charset') . "\"\n";
			$mailtext = "<html><head><title>" . $subject . "</title></head><body>" . nl2br($message) . "</body></html>";
			return wp_mail($recipients, $subject, $mailtext, $headers);
			
		} else {
			$headers .= "MIME-Version: 1.0\n";
			$headers .= "Content-Type: text/plain; charset=\"". get_bloginfo('charset') . "\"\n";
			$message = preg_replace('|&[^a][^m][^p].{0,3};|', '', $message);
			$message = preg_replace('|&amp;|', '&', $message);
			$mailtext = wordwrap(strip_tags($message), 80, "\n");
			return wp_mail($recipients, stripslashes($subject), stripslashes($mailtext), $headers);
		}

	}

}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_replace_stuff_for_me($find, $replace, $subject)
{
	$i = 0;
	foreach($find as $item)
	{
		$replace_with = $replace[$i];
		$subject = str_replace($item, $replace_with, $subject);	
		$i++;
	}
	
	return $subject;
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_register_my_menus() {
		register_nav_menu( 'primary-walleto-header', 'Walleto Top-Header Menu' );
		register_nav_menu( 'primary-walleto-main-header', 'Walleto Big Main Menu' );	
		
		//register variations
		
		
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/	
		
function Walleto_add_max_nr_of_images()
{
	?>
    
    <script type="text/javascript">
		<?php
		$Walleto_enable_max_images_limit = get_option('Walleto_enable_max_images_limit');
		if($Walleto_enable_max_images_limit == "yes")
		{
			$Walleto_nr_max_of_images = get_option('Walleto_nr_max_of_images');
			if(empty($Walleto_nr_max_of_images))	 $Walleto_nr_max_of_images = 10;
		}
		else $Walleto_enable_max_images_limit = 1000;
		
		if(empty($Walleto_nr_max_of_images)) $Walleto_nr_max_of_images = 100;
		
		/* Inactivity log out check */
		if(!session_id()) {
			ob_start(); 		
			session_start();
		}
		if (isset($_SESSION['LAST_ACTIVITY']) && (current_time('timestamp', 0) - $_SESSION['LAST_ACTIVITY'] > 5400)) {
			unset($_SESSION['LAST_ACTIVITY']);
			wp_logout();
		}
		$_SESSION['LAST_ACTIVITY'] = current_time('timestamp', 0);		
		?>
		
		
		
		var maxNrImages_PT = <?php echo $Walleto_nr_max_of_images; ?>;
		jQuery( document ).ready(function( $ ) {
			jQuery( "#shp_tandc" ).dialog({
				closeOnEscape: false,
				autoOpen: false,
				width: 700,
				modal: true,
			});		
			jQuery('a#shp_tc_clbk').click(function(event) {
				event.preventDefault();
				jQuery( "#shp_tandc" ).dialog( "open" );

			});
			/* On Checkout ask buyer to agree terms and conditions */			
			jQuery( "#wl_ckut_btn" ).click(function( event ) {
				event.preventDefault();
				jQuery( "#wl_ckut_cfrm_tandc" ).dialog( "open" );
			});
			jQuery( "#wl_ckut_cfrm_tandc" ).dialog({
				closeOnEscape: false,
				autoOpen: false,
				width: 700,
				modal: true,
				open: function(event, ui) { jQuery(".ui-dialog-titlebar-close", ui.dialog | ui).hide(); },
				buttons: {
					"Yes": function() {
					jQuery( "input[name='send_me_to_checkout']" ).click();
				},
					"No": function() {
					jQuery( "#n_tandc" ).submit();
				}
			}
			});
			/* On delivery/pick up button click, ask buyer to add products to common basket */
			jQuery( "#wl_dlvrypkup_btn" ).click(function( event ) {
				event.preventDefault();
				jQuery( "#dialog-cfrm-cmnbskt" ).dialog( "open" );
			});			
			jQuery( "#dialog-cfrm-cmnbskt" ).dialog({
				closeOnEscape: false,
				autoOpen: false,
				width: 800,
				modal: true,				
				buttons: {
					"Yes": function() {
					jQuery( "#wl_cmn_bskt" ).submit();
				},
					"No": function() {
					jQuery( "input[name='set_delivery_me']" ).click();					
				}
			}
			});
			/* On test drive button click, ask buyer to accept disclaimer before proceed */
			jQuery( "#wl_vhcle_tstdrive_btn" ).click(function( event ) {
				event.preventDefault();
				jQuery( "#vhcle_tstdrive" ).dialog( "open" );
			});			
			jQuery( "#vhcle_tstdrive" ).dialog({
				closeOnEscape: false,
				autoOpen: false,
				width: 800,
				modal: true,				
				buttons: {
				"Yes": function() {
					var chk = jQuery( "input[name='wl_cond_acpt']:checked" ).val();
					if(chk) {
						jQuery( "#frm_tstdrive" ).submit();
						jQuery( "#frm_tstdrive" ).reset();				
						jQuery( this ).dialog( "close" );
					} else {
						return false;
					}
				},
				"No": function() {
					jQuery( this ).dialog( "close" );					
				}
			}
			});			
		});	
	</script>
    
    <?php	
	if(!session_id()) {
		ob_start(); 		
		session_start();
	}
	if(isset($_SESSION['delivery_note']) && !empty($_SESSION['delivery_note'])) { ?>
	<script type="text/javascript">
	jQuery(function() {
		jQuery( "#dialog-confirm" ).dialog({
		  modal: true,
		  closeOnEscape: false,
		  width: 500,
		  buttons: {
			"Proceed to Payment": function() {
			  jQuery( "#alt_dlvry" ).submit();
			},
			"Try Other": function() {
			  jQuery( this ).dialog( "close" );
			}
		  }
		});
	});
	</script>
	<?php }

	if(isset($_SESSION['delivery_ask']) && !empty($_SESSION['delivery_ask'])) { ?>
	<script type="text/javascript">
	jQuery(function() {
		jQuery( "#dialog-ask" ).dialog({
		  modal: true,
		  closeOnEscape: false,
		  width: 500,
		  buttons: {
			"Proceed to Payment": function() {
				var chk = jQuery( "input[name='wl_dlvry_mtd']:checked" ).val();
				if(chk) {
				jQuery( "#wl_dlvry_mthd" ).submit();
				jQuery( "#wl_dlvry_mthd" ).reset();				
				jQuery( this ).dialog( "close" );
				} else {
					return false;
				}
			},
			"Try Other": function() {
			  jQuery( this ).dialog( "close" );
			}
		  }
		});
	});
	</script>	
	<?php }

	if(isset($_SESSION['delivery_pkupnote']) && !empty($_SESSION['delivery_pkupnote'])) { ?>
	<script type="text/javascript">
	jQuery(function() {
		jQuery( "#dialog-pkup" ).dialog({
		  modal: true,
		  closeOnEscape: false,
		  width: 500,
		  buttons: {
			"Proceed to Payment": function() {
			var chk = jQuery( "input[name='wl_pkup_loc']:checked" ).val();
			if(chk) {			
				jQuery( "#alt_dlvry" ).submit();
				jQuery( "#alt_dlvry" ).reset();				
				jQuery( this ).dialog( "close" );
			} else {
				return false;
			}			
			},
			"Try Other": function() {
			  jQuery( this ).dialog( "close" );
			}
		  }
		});
	});
	</script>
	<?php }
	global $pagenow;
	if(isset($_SESSION['buyer_agree_tandc']) && !empty($_SESSION['buyer_agree_tandc']) && $pagenow != 'wp-login.php') { ?>
	<script type="text/javascript">
	jQuery(function() {
		jQuery( "#dialog-cfrm-tandc" ).dialog({
		  modal: true,
		  closeOnEscape: false,
		  width: 520,
		  height: 'auto',
		  create: function(event, ui) {
		    jQuery("body").css({ overflow: 'hidden' })
		  },
		  beforeClose: function(event, ui) {
		    jQuery("body").css({ overflow: 'inherit' })
		  },
		  buttons: {
			"Yes": function() {
			  jQuery( this ).dialog( "close" );
			},
			"No": function() {
			  jQuery( "#n_tandc" ).submit();
			}
		  }
		});
	});
	</script>
	<?php }
	
	if(isset($_SESSION['wl_serv_ask']) && !empty($_SESSION['wl_serv_ask'])) { ?>
	<script type="text/javascript">
	jQuery(function() {
		jQuery( "#serv-ask" ).dialog({
		  modal: true,
		  closeOnEscape: false,
		  width: 500,
		  buttons: {
			"Proceed to Payment": function() {
				var chk = jQuery( "input[name='wl_serv_fee']" ).val();
				if(chk) {
				jQuery( "#wl_lgts_charge_frm" ).submit();
				jQuery( "#wl_lgts_charge_frm" ).reset();	
				jQuery( this ).dialog( "close" );
				} else {
					return false;
				}
			},
			"Try Other": function() {
			  jQuery( this ).dialog( "close" );
			}
		  }
		});
	});
	</script>	
	<?php }

	global $post;
	if(is_singular('shop') && wl_is_warning_enable($post->ID)) { ?>
	<script type="text/javascript">
	jQuery(function() {
		var shop_id = <?php echo $post->ID; ?>;
		var shop_agreed = getCookie("shop_"+shop_id);
		if (shop_agreed == "") {	
			jQuery( "#dialog-cfrm-byrage" ).dialog({
			  resizable: false,
			  modal: true,
			  closeOnEscape: false,
			  draggable: false,
			  create: function(event, ui) {
				jQuery("body").css({ overflow: 'hidden' })
			  },
			  open: function(event, ui) { jQuery(".ui-dialog-titlebar-close", ui.dialog | ui).hide(); },
			  beforeClose: function(event, ui) {
				jQuery("body").css({ overflow: 'inherit' })
			  },
			  width: 500,
			  buttons: {
				"Yes": function() {
					setCookie("shop_"+shop_id, "Yes", 1);
					jQuery( this ).dialog( "close" );
				},
				"No": function() {
				  window.location = "https://www.hammerandtongues.com";
				}
			  }
			});
		}
	});
	function getCookie(cname) {
		var name = cname + "=";
		var ca = document.cookie.split(';');
		for(var i=0; i<ca.length; i++) {
			var c = ca[i];
			while (c.charAt(0)==' ') c = c.substring(1);
			if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
		}
		return "";
	}
	function setCookie(cname, cvalue, exdays) {
		var d = new Date();
		d.setTime(d.getTime() + (exdays*24*60*60*1000));
		var expires = "expires="+d.toUTCString();
		document.cookie = cname + "=" + cvalue + ";";
	}
	</script>	
	<?php }
	if(!is_singular('product')) { ?>
	<script type="text/javascript">
	jQuery( document ).ready(function() {
		var item_to_scroll = window.location.hash.replace('#','');
		var scrto = getCookie('scrTo');
		if(typeof item_to_scroll != 'undefined' && item_to_scroll != "" && !isNaN(item_to_scroll)) {
			jQuery('html, body').animate({
				scrollTop: jQuery('#item-'+item_to_scroll).offset().top
			}, 1000);
		} else if(typeof scrto != 'undefined' && scrto != "" && !isNaN(scrto)) {
			jQuery('html, body').animate({
				scrollTop: jQuery('#item-'+scrto).offset().top
			}, 1000);		
		}
		function getCookie(cname) {
			var name = cname + "=";
			var ca = document.cookie.split(';');
			for(var i=0; i<ca.length; i++) {
				var c = ca[i];
				while (c.charAt(0)==' ') c = c.substring(1);
				if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
			}
			return "";
		}		
	});
	</script>
	<?php
	}
	
	$wl_tracking_code = get_option( 'Walleto_analytics_code' );
	$wl_tracking_code = trim($wl_tracking_code);
	if(!empty($wl_tracking_code)) {
		echo $wl_tracking_code;
	}
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_login_url()
{
	return get_bloginfo('siteurl') . "/wp-login.php";	
}

	
/*************************************************************
*
*	Walleto (c) sitemile.com - function
*
**************************************************************/
function walleto_get_order_content_link($id)
{
	if(walleto_using_permalinks())
	{
		return get_permalink(get_option('Walleto_my_account_show_order_cnt_page_id')). "?oid=". $id;	
	}
	else
	{
		return get_permalink(get_option('Walleto_my_account_show_order_cnt_page_id'))."&oid=" . $id;
	}	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function Walleto_get_item_price($pid)
{
	return get_post_meta($pid,'price',true);	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/ 
function walleto_get_remove_from_cart_link($pid)
{
	if(walleto_using_permalinks())
	{
		return get_permalink(get_option('Walleto_shopping_cart_page_id')). "?remove_from_cart=". $pid;	
	}
	else
	{
		return get_permalink(get_option('Walleto_shopping_cart_page_id'))."&remove_from_cart=" . $pid;
	}
}


function walleto_get_redirect_ok_link_carts()
{
	if(walleto_using_permalinks())
	{
		return get_permalink(get_option('Walleto_shopping_cart_page_id')). "?okok=". '1';	
	}
	else
	{
		return get_permalink(get_option('Walleto_shopping_cart_page_id'))."&okok=" . '1';
	}
}

/*************************************************************
*
*	Walleto (c) sitemile.com - function
*
**************************************************************/
function walleto_get_post_images($pid, $limit = -1)
{
	
		//---------------------
		// build the exclude list
		$exclude = array();
		
		$args = array(
		'order'          => 'ASC',
		'post_type'      => 'attachment',
		'post_parent'    => get_the_ID(),
		'meta_key'		 => 'another_reserved1',
		'meta_value'	 => '1',
		'numberposts'    => -1,
		'post_status'    => null,
		);
		$attachments = get_posts($args);
		if ($attachments) {
			foreach ($attachments as $attachment) {
			$url = $attachment->ID;
			array_push($exclude, $url);
		}
		}
		
		//-----------------
	
	
		$arr = array();
		
		$args = array(
		'order'          => 'ASC',
		'orderby'        => 'post_date',
		'post_type'      => 'attachment',
		'post_parent'    => $pid,
		'exclude'    		=> $exclude,
		'post_mime_type' => 'image',
		'numberposts'    => $limit,
		); $i = 0;
		
		$attachments = get_posts($args); 
		if ($attachments) {
		
			foreach ($attachments as $attachment) {
						
				$url = $attachment->ID;
				array_push($arr, $url);
			  
		}
			return $arr;
		}
		return false;
}
/*****************************************************************************
*
*	Function - walleto -
*
*****************************************************************************/
function walleto_get_auto_draft($uid)
{
	global $wpdb;	
	$querystr = "
		SELECT distinct wposts.* 
		FROM $wpdb->posts wposts where 
		wposts.post_author = '$uid' AND wposts.post_status = 'auto-draft' 
		AND wposts.post_type = 'product' 
		ORDER BY wposts.ID DESC LIMIT 1 ";
				
	$row = $wpdb->get_results($querystr, OBJECT);
	if(count($row) > 0)
	{
		$row = $row[0];
		return $row->ID;
	}
	
	return walleto_create_auto_draft($uid);	
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_get_auto_draft_shop($uid)
{
	global $wpdb;	
	$querystr = "
		SELECT distinct wposts.* 
		FROM $wpdb->posts wposts where 
		wposts.post_author = '$uid' AND (wposts.post_status = 'auto-draft' or wposts.post_status = 'draft' or wposts.post_status = 'publish')
		AND wposts.post_type = 'shop' 
		ORDER BY wposts.ID DESC LIMIT 1 ";
				
	$row = $wpdb->get_results($querystr, OBJECT);
	if(count($row) > 0)
	{
		$row = $row[0];
		return $row->ID;
	}
	
	return walleto_create_auto_draft_shop($uid);	
}

/*****************************************************************************
*
*	Function - walleto -
*
*****************************************************************************/
function walleto_create_auto_draft($uid)
{
		$my_post = array();
		$my_post['post_title'] 		= 'Auto Draft';
		$my_post['post_type'] 		= 'product';
		$my_post['post_status'] 	= 'auto-draft';
		$my_post['post_author'] 	= $uid;
		$pid =  wp_insert_post( $my_post, true );
		

		update_post_meta($pid,'featured_paid', 	"0");
		update_post_meta($pid,'featured', 		"0");
		update_post_meta($pid,'closed', 		"0");
		update_post_meta($pid,'quant', 			"1");
		update_post_meta($pid, "views", 		'0');
		
		return $pid;
		
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_create_auto_draft_shop($uid)
{
		$my_post = array();
		$my_post['post_title'] 		= 'Auto Draft';
		$my_post['post_type'] 		= 'shop';
		$my_post['post_status'] 	= 'auto-draft';
		$my_post['post_author'] 	= $uid;
		$pid =  wp_insert_post( $my_post, true );
		

		update_post_meta($pid,'featured_paid', 	"0");
		update_post_meta($pid,'featured', 		"0");
		update_post_meta($pid,'closed', 		"0");
		update_post_meta($pid,'quant', 			"1");
		update_post_meta($pid, "views", 		'0');
		update_post_meta($pid,'status',			'active');
		
		return $pid;
		
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_clear_sums_of_cash($cash)
{
	$cash = str_replace(" ","",$cash);
	$cash = str_replace(",","",$cash);
	//$cash = str_replace(".","",$cash);
	
	return strip_tags($cash);
}
/*****************************************************************************
*
*	Function - walleto -
*
*****************************************************************************/
function walleto_generate_thumb_upload_cls($img_ID )
{

	return walleto_wp_get_attachment_image($img_ID, array(80,80));
}
/*****************************************************************************
*
*	Function - walleto -
*
*****************************************************************************/
function walleto_formats_special($number, $cents = 1) { // cents: 0=never, 1=if needed, 2=always
  
	$dec_sep = '.';
	$tho_sep = ',';
  
  //dec,thou
  
  if (is_numeric($number)) { // a number
    if (!$number) { // zero
      $money = ($cents == 2 ? '0'.$dec_sep.'00' : '0'); // output zero
    } else { // value
      if (floor($number) == $number) { // whole number
        $money = number_format($number, ($cents == 2 ? 2 : 0), $dec_sep, '' ); // format
      } else { // cents
        $money = number_format(round($number, 2), ($cents == 0 ? 0 : 2), $dec_sep, '' ); // format
      } // integer or decimal
    } // value
    return $money;
  } // numeric
} // formatMoney
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

add_action('init', 		'walleto_myStartSession', 1);
add_action('wp_logout', 'walleto_myEndSession');
add_action('wp_login', 	'walleto_myEndSession');

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_myStartSession() {
    if(!session_id()) {
		ob_start(); 		
		session_start();
    }
    
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_myEndSession() {
    session_destroy ();
}
 

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function walleto_get_product_price_and_variance($pid, $variance)
{
	global $wpdb;
	$s = "select * from ".$wpdb->prefix."walleto_variations_content where pid='$pid' AND variation_string='$variance'";
	$r = $wpdb->get_results($s);
	
	if(count($r) > 0)
	{
		$row = $r[0];
		return $row->price;		
	}
}


function walleto_get_product_quant_and_variance($pid, $variance)
{
	global $wpdb;
	$s = "select * from ".$wpdb->prefix."walleto_variations_content where pid='$pid' AND variation_string='$variance'";
	$r = $wpdb->get_results($s);
	
	if(count($r) > 0)
	{
		$row = $r[0];
		return $row->quant;		
	}
}

function walleto_get_total_of_order_for_user($oid, $uid)
{
	global $wpdb;

	


	$s = "select * from ".$wpdb->prefix."walleto_order_contents cnt, $wpdb->posts posts where cnt.orderid='$oid' AND posts.post_author='$uid' AND cnt.paid='0' AND posts.ID=cnt.pid";
	$r = $wpdb->get_results($s);	
	
	$shp = 0;
	$sum = 0;
	foreach($r as $row)
	{
		$sum += $row->price*$row->quant;
		$shp		+= get_post_meta($row->pid, 'shipping', true)*$row->quant;
	}
	$ttlAmt= $sum + $shp;

	/* Spidanet checking if it is coupon enabled order, so update total..*/
	if($ttlAmt>0){
		$discountAvl= check_discount($oid);
		if( $discountAvl > 0){
			$ttlAmt -= $discountAvl;
		}
	}

	return $ttlAmt;

}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_get_order_obj($oid)
{
	global $wpdb;
	$s = "select * from ".$wpdb->prefix."walleto_orders where id='$oid'";
	$r = $wpdb->get_results($s);
	
	return $r[0];	
}

function Walleto_send_email_when_review_has_been_awarded($oid, $rated_user_uid, $awarding_user_uid) //received by buyer
{
	$enable 	= get_option('Walleto_review_received_email_enable');
	$subject 	= get_option('Walleto_review_received_email_subject');
	$message 	= get_option('Walleto_review_received_email_message');	
	
	
	
	if($enable != "no"):
		
		global $wpdb;
 
		$post 			= get_post($pid);
		$rated_user		= get_userdata($rated_user_uid);
		$awarding_user  = get_userdata($awarding_user_uid);
		
		$user 			= get_userdata($post->post_author);
		$site_login_url = Walleto_login_url();
		$site_name 		= get_bloginfo('name');
		$account_url 	= get_permalink(get_option('Walleto_my_account_page_id'));

		
		$find 		= array('##rated_user##', '##awarding_user##', '##site_login_url##', '##your_site_name##', '##your_site_url##' , '##my_account_url##', '##item_name##', '##item_link##');
   		$replace 	= array($rated_user->user_login, $awarding_user->user_login, $site_login_url, $site_name, get_bloginfo('siteurl'), $account_url, "#".$oid, get_permalink($pid));
		
		$tag		= 'Walleto_send_email_when_review_has_been_awarded';
		$find 		= apply_filters( $tag . '_find', 	$find );
		$replace 	= apply_filters( $tag . '_replace', $replace );
		
		$message 	= Walleto_replace_stuff_for_me($find, $replace, $message);
		$subject 	= Walleto_replace_stuff_for_me($find, $replace, $subject);
		
		//---------------------------------------------

		Walleto_send_email($rated_user->user_email, $subject, $message);
	
	endif;
}

function walleto_get_prod_stars($rating)
	{
		$full 	= get_bloginfo('template_url')."/images/full_star.gif";
		$empty 	= get_bloginfo('template_url')."/images/empty_star.gif";	
		
		$r = '';
		
		for($j=1;$j<=$rating;$j++)
		$r .= '<img src="'.$full.'" alt="star" />';
		
		
		for($j=5;$j>$rating;$j--)
		$r .= '<img src="'.$empty.'" alt="star" />';
		
		return $r;
		
	}

function ProjectTheme_array_cartesian_product($arrays)
{
  if(is_array($arrays))
  {
    $result = array();
    $arrays = array_values($arrays);
    $sizeIn = sizeof($arrays);
    $size = $sizeIn > 0 ? 1 : 0;
    foreach ($arrays as $array)
        $size = $size * sizeof($array);
    for ($i = 0; $i < $size; $i ++)
    {
        $result[$i] = array();
        for ($j = 0; $j < $sizeIn; $j ++)
            array_push($result[$i], current($arrays[$j]));
        for ($j = ($sizeIn -1); $j >= 0; $j --)
        {
            if (next($arrays[$j]))
                break;
            elseif (isset ($arrays[$j]))
                reset($arrays[$j]);
        }
    }
    return $result;
  }
  return array();
}

function ProjectTheme_get_product_variance($slug)
{
	global $wpdb;
	$s = "select * from ".$wpdb->prefix."walleto_variations where slug='$slug'";	
	$r = $wpdb->get_results($s);
	
	if(count($r) >0) return $r[0];
	return false;
}

function walleto_template_redirect()
{
	if(isset($_GET['my_upload_of_images']))
	{
		get_template_part('lib/uploadify/uploady8');
		die();	
	}

/*Spidanet: for vpayments starts*/
if(isset($_GET['return_vpayments']))
{
	$re_url = add_query_arg('st','1', get_permalink(get_option('Walleto_my_account_my_finances_page_id')));
	wp_redirect($re_url);
	exit;	
}

if(isset($_GET['return_vpaymentsp']))
{
	$re_url = add_query_arg( 'pst', '1', get_permalink(get_option('Walleto_my_account_all_orders_page_id')));
	wp_redirect($re_url);
	exit;	
}

if(isset($_GET['return_vpaymentsf']))
{
	$re_url = add_query_arg( 'dst', 'f', get_permalink(get_option('Walleto_my_account_all_orders_page_id')));
	wp_redirect($re_url);
	exit;	
}	
/*Spidanet: for vpayments ends */
if(isset($_GET['return_visamastersp']) && isset($_GET['odr']))
{
	$hash = $_GET['odr']; 
	$hsh_ = get_option('hsh_' . $hash);
	delete_option('hsh_' . $hash);
	$cust = explode('|', $hsh_);
	$invoice_date = "";
	$bid_amt = 0;
	global $wpdb;
	$invoice_date = current_time('timestamp');
	
	$uid 					= $cust[0];
	$datemade 				= $cust[1];
	$orderId				= $cust[2];
	$sellerIds				= $cust[3];
	$chkUrl					= $cust[4];
	$selArr                 = explode(',',$sellerIds); 
	$postString				= "";
	$inv_num				= wl_get_order_proinvnum($orderId, $uid);
	$odr_vat 				= (get_option('Walleto_purchase_vat')) ? get_option('Walleto_purchase_vat') : 15;
	$odr_vat_perc 			= $odr_vat / 100;
	
	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $chkUrl);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postString);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	
	// receiving server response
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	if ($server_output)
	{
		$response = intval($server_output);
		if($response == 2) {
			$wpdb->query("update ".$wpdb->prefix."walleto_orders set paid='1',paid_on='$invoice_date' where id='$orderId'");
			$ttl_amt = walleto_get_total_for_order($orderId);
			$wpdb->query("update ".$wpdb->prefix."walleto_orders set paid='1',paid_on='$invoice_date' where id='$orderId'");			
			$wpdb->query("update ".$wpdb->prefix."walleto_order_contents set paid='1',paid_on='$invoice_date' where orderid='$orderId'");	
			
			$buyerId = $uid; 
			foreach ($selArr  as $key => $value) {
				Walleto_send_email_when_item_is_paid_seller($orderId,$value,$buyerId);
			}
			
			Walleto_send_email_when_item_is_paid_buyer($orderId, $buyerId);
			
			// H&T BANK UPDATE
			$bk_cr = Walleto_get_credits(87);
			Walleto_update_credits(87, $bk_cr + $ttl_amt);
			$bk_reason = sprintf(__("USER PAID against invoice %d via Visa/MasterCard.","Walleto"), $inv_num); 			
			walleto_add_history_log('1', $bk_reason, $ttl_amt, 87);			

			/*SMS*/
			$tel = $userTel = 0;
			$userTel = get_cimyFieldValue($uid, "TELEPHONE");
			$userTel = cimy_uef_sanitize_content($userTel);
			$userTel = intval($userTel);
			// COUNTRY TELEPHONE CODE
			$userCountry = get_cimyFieldValue($uid, "COUNTRY");
			$userCountry = cimy_uef_sanitize_content($userCountry);
			$tel = wl_get_ctry_dcode($userCountry);
			$tel .= $userTel;
			$curr_sym = walleto_get_currency();
			$msg = __("Dear Customer, You have made a payment of ".$curr_sym.$ttl_amt." through Visa/MasterCard for invoice ".$inv_num.". You will be notified when it is ready for delivery/pick up. Thank you HTSM", "Walleto");
			Walleto_send_sms($tel, $msg);				
			/*SMS*/

			$reason = sprintf(__("Paid through Visa/MasterCard against invoice %d.","Walleto"), $inv_num); 
			walleto_add_history_log('0', $reason, $ttl_amt, $uid);

			/* UPDATE PAID INFORMATION TO ORDER META */
			wl_update_order_meta($orderId, "paid_info", "Visa/MasterCard");
			
			$re_url = add_query_arg( 'pst', '1', get_permalink(get_option('Walleto_my_account_all_orders_page_id')));
			wp_redirect($re_url);
			exit;		
		}
	}
	else
	{
		$re_url = add_query_arg( 'vst', 'f', get_permalink(get_option('Walleto_my_account_my_finances_page_id')));
		wp_redirect($re_url);
		exit;
	}	
}

if(isset($_GET['return_visamastersf']))
{
	$re_url = add_query_arg( 'vst', 'f', get_permalink(get_option('Walleto_my_account_all_orders_page_id')));
	wp_redirect($re_url);
	exit;	
}


	
	if(isset($_GET['load_price']))
	{
		$variation_string = $_GET['variation_string'];
		$pid = $_GET['pid'];
		
		if(empty($variation_string) || $variation_string =="") {  
			
			$pr = get_post_meta($pid,'price',true);
			$pr = walleto_get_show_price($pr);
			echo $pr; die();
		}
		
		$walleto_get_product_price_and_variance = walleto_get_product_price_and_variance($pid,$variation_string );
		echo walleto_get_show_price($walleto_get_product_price_and_variance);
		die();	
		
	}
	
	//-----------------------------------
	
	if(isset($_GET['load_quants']))
	{
		$variation_string = $_GET['variation_string'];
		$pid = $_GET['pid'];
		
		if(empty($variation_string)) {  
			
			$pr = get_post_meta($pid,'quant',true);
			$pr =  ($pr);
			echo $pr; die();
		}
		
		$walleto_get_product_quant_and_variance = walleto_get_product_quant_and_variance($pid,$variation_string );
		echo ($walleto_get_product_quant_and_variance);
		die();	
		
	}
	
	if(isset($_GET['remove_from_cart']))
	{
		$pids = $_GET['remove_from_cart'];
		if(!session_id()) {
			ob_start(); 		
			session_start();
		}
		//$cart = $_COOKIE['my_cart']; 
		//$cart		= stripslashes($cart);
		//$cart		= unserialize($cart);
		//$cart = $cart['my_cart']; 
		$cart = $_SESSION['cart_items'];
		
		$i = 0;
		$crt = array();
		if(!empty($cart)) {
			foreach($cart as $itm)
			{
				if($itm['pid'] != $pids)  {					
					$crt[$i]['pid'] = $itm['pid'];
					$crt[$i]['quant'] = $itm['quant'];
					$crt[$i]['variation_string'] = $itm['variation_string'];
					$i++;
					 
				 }			 
			}
		}
		
		//walleto_remove_cookie('my_cart');
			
		//$PHP_COOKIE = new PHP_COOKIE("my_cart");
		//$PHP_COOKIE->put("my_cart", $crt);
		//$PHP_COOKIE->set();
		unset($_SESSION["cart_items"]);
		$_SESSION['cart_items'] = $crt;
			
		//--------------
		$gng = 1;
		
		global $apps;
		$apps = 1;
	}
	//****************************************************
	
	global $error1;
	$error1 = array();
	
	if(isset($_GET['pay_order_skrill']))
	{
		if(is_user_logged_in())
		{
			include 'lib/gateways/skrill_pay_order.php';	
		} else echo 'not_logged_skrill_order_pay';
		die();	
	}
	
	if(isset($_POST['update_card']))
	{
		$i = 0; $k = 0;
		if(!session_id()) {
			ob_start(); 		
			session_start();
		}		
		//$cart = $_COOKIE['my_cart']; 
		//$cart		= stripslashes($cart);
		//$cart		= unserialize($cart);
		//$cart = $cart['my_cart']; 
		$cart = $_SESSION['cart_items'];
	
		
		//--------------------------------------
		
		$crt = array();
		
		if(is_array($_POST['cart_id_c']))
		{
			foreach($_POST['cart_id_c'] as $itm)
			{
				$variation_string_p = $_POST['variation_string_c'][$k];
				$cnts = floor($_POST['cart_quant_' . $itm . $variation_string_p]);
				$cnts = abs($cnts);
				if($cnts == 0) $cnts = 1;
				
				 
				
				if(!empty($variation_string_p))
				{
					
					$quant = walleto_get_quant_of_pid_and_variance($itm, $variation_string_p);
					if($quant < $cnts) 
					{ 						
						$itm_pst 	= get_post($itm);
						$product_type = ' ['.walleto_get_variation_name_from_string($variation_string_p,', ')."]";
						$cnts 		= $quant;
						$error1[] 	= sprintf(__('The available quantity for this product: <b>%s</b> is smaller than the one you requested','Walleto'), $itm_pst->post_title . $product_type);
					}
				}
				else
				{
					$quant = get_post_meta($itm,'quant',true);
					if($quant < $cnts) { 
						
						$itm_pst 	= get_post($itm);
						$cnts 		= $quant;
						$error1[] 	= sprintf(__('The available quantity for this product: <b>%s</b> is smaller than the one you requested','Walleto'), $itm_pst->post_title);
					}
				}
				
				$crt[$i]['pid'] = $itm;
				$crt[$i]['quant'] = $cnts;
				$crt[$i]['variation_string'] = $variation_string_p;
				$i++;
				$k++;
			}
			
			//walleto_remove_cookie('my_cart');
			
			//$PHP_COOKIE = new PHP_COOKIE("my_cart");
			//$PHP_COOKIE->put("my_cart", $crt);
			//$PHP_COOKIE->set();
			unset($_SESSION["cart_items"]);
			$_SESSION['cart_items'] = $crt;
			
			//--------------
			$gng = 1;
		 
		}
		
		global $upds;
		$upds = 1;
		
	}
	
	
	
	//=================================
	
	
	if(isset($_GET['deposit_response_payza']))
	{
		include 'lib/gateways/deposit_response_payza.php'; die();	
	}
	
	
 	if(isset($_GET['no_paypal_email']))
	{
		include 'lib/no_paypal_email.php'; die();	
	}

	if(isset($_GET['a_action']) &&  $_GET['a_action']== 'deposit_vpayments')
	{
		
		include('lib/gateways/deposit_vpayments.php');
		die();
	}
	
	if(isset($_GET['a_action']) &&  $_GET['a_action']== 'deposit_visamaster')
	{
		
		include('lib/gateways/deposit_visamaster.php');
		die();
	}	
		
	if(isset($_GET['a_action']) &&  $_GET['a_action']== 'deposit_ecash')
	{
		include('lib/gateways/deposit_ecash.php');
		die();
	}
	
	if(isset($_GET['a_action']) &&  $_GET['a_action']== 'deposit_tcash')
	{
		include('lib/gateways/deposit_tcash.php');
		die();
	}	

	if(isset($_GET['a_action']) &&  $_GET['a_action']== 'deposit_paynow')
	{
		include('lib/gateways/deposit_paynow.php');
		die();
	}	
	
	if(isset($_GET['pay_for_item']) && $_GET['pay_for_item']=="vpay")
	{
		include('lib/my_account/pay_for_item_'.$_GET['pay_for_item'].'.php');
		die();	
	}

	if(isset($_GET['pay_for_item']) && $_GET['pay_for_item']=="ecash")
	{
		include('lib/my_account/pay_for_item_'.$_GET['pay_for_item'].'.php');
		die();	
	}
	
	if(isset($_GET['pay_for_item']) && $_GET['pay_for_item']=="tcash")
	{
		include('lib/my_account/pay_for_item_'.$_GET['pay_for_item'].'.php');
		die();	
	}	

	if(isset($_GET['pay_for_item']) && $_GET['pay_for_item']=="visamaster")
	{
		include('lib/my_account/pay_for_item_'.$_GET['pay_for_item'].'.php');
		die();	
	}	
	
	if(isset($_GET['pay_for_item']) && $_GET['pay_for_item']=="paynow")
	{
		include('lib/my_account/pay_for_item_'.$_GET['pay_for_item'].'.php');
		die();	
	}		


	/*Spida vpayments pay starts*/

if(isset($_GET['notify_paid_vpayments']))
	{
		$hash = $_GET['myhsh']; 
		$hsh_ = get_option('hsh_' . $hash);
		$cust = explode('|', $hsh_);
		$invoice_date = "";
		$bid_amt = 0;
		global $wpdb;
		$invoice_date = current_time('timestamp');
		$odr_vat = (get_option('Walleto_purchase_vat')) ? get_option('Walleto_purchase_vat') : 15;
		$odr_vat_perc = $odr_vat / 100;		
		
    	$uid 					= $cust[0];
		$datemade 				= $cust[1];
		$orderId				= $cust[2];
		$sellerIds				= $cust[3];
		$selArr                 = explode(',',$sellerIds); 
		$inv_num				= wl_get_order_proinvnum($orderId, $uid);
		$isPaid = $wpdb->get_var( "SELECT paid FROM ".$wpdb->prefix."walleto_orders WHERE id='$orderId'");

		if($isPaid==0){	
			$wpdb->query("update ".$wpdb->prefix."walleto_orders set paid='1',paid_on='$invoice_date' where id='$orderId'");
			$ttl_amt = walleto_get_total_for_order($orderId);
			$wpdb->query("update ".$wpdb->prefix."walleto_orders set paid='1',paid_on='$invoice_date' where id='$orderId'");
			$wpdb->query("update ".$wpdb->prefix."walleto_order_contents set paid='1',paid_on='$invoice_date' where orderid='$orderId'");

			$buyerId = $uid; 
			foreach ($selArr  as $key => $value) {
			Walleto_send_email_when_item_is_paid_seller($orderId,$value,$buyerId);
			}
			Walleto_send_email_when_item_is_paid_buyer($orderId, $buyerId);

			// H&T BANK UPDATE
			$bk_cr = Walleto_get_credits(87);
			Walleto_update_credits(87, $bk_cr + $ttl_amt);
			$bk_reason = sprintf(__("USER PAID against invoice %d via Vpayments.","Walleto"), $inv_num); 			
			walleto_add_history_log('1', $bk_reason, $ttl_amt, 87);			

			/*SMS*/
			$tel = $userTel = 0;
			$userTel = get_cimyFieldValue($uid, "TELEPHONE");
			$userTel = cimy_uef_sanitize_content($userTel);
			$userTel = intval($userTel);
			// COUNTRY TELEPHONE CODE
			$userCountry = get_cimyFieldValue($uid, "COUNTRY");
			$userCountry = cimy_uef_sanitize_content($userCountry);
			$tel = wl_get_ctry_dcode($userCountry);
			$tel .= $userTel;
			$curr_sym = walleto_get_currency();
			$msg = __("Dear Customer, You have made a payment of ".$curr_sym.$ttl_amt." through Vpayments for invoice ".$inv_num.". You will be notified when it is ready for delivery/pick up. Thank you HTSM", "Walleto");
			Walleto_send_sms($tel, $msg);				
			/*SMS*/

			$reason = sprintf(__("Paid through Vpayments against invoice %d.","Walleto"), $inv_num);
			walleto_add_history_log('0', $reason, $ttl_amt, $uid);
			
			/* UPDATE PAID INFORMATION TO ORDER META */
			wl_update_order_meta($orderId, "paid_info", "Vpayments");
		}
	}


/*Ecocash starts*/

 	if(isset($_GET['notify_paid_ecash']))
	{
		$hash = $_GET['myhsh']; 
		$hsh_ = get_option('hsh_' . $hash);
		$cust = explode('|', $hsh_);
		$invoice_date = "";
		
		global $wpdb;
		$invoice_date = current_time('timestamp');
		
    	$uid 					= $cust[0];
		$datemade 				= $cust[1];
		$orderId				= $cust[2];
		$sellerIds				= $cust[3];
		$selArr                 = explode(',',$sellerIds);
		$inv_num				= wl_get_order_proinvnum($orderId, $uid);
		$odr_vat 				= (get_option('Walleto_purchase_vat')) ? get_option('Walleto_purchase_vat') : 15;
		$odr_vat_perc 			= $odr_vat / 100;
		
		$isPaid = $wpdb->get_var( "SELECT paid FROM ".$wpdb->prefix."walleto_orders WHERE id='$orderId'");

		if($isPaid==0){	
			$ttl_amt = walleto_get_total_for_order($orderId);
			$wpdb->query("update ".$wpdb->prefix."walleto_orders set paid='1',paid_on='$invoice_date' where id='$orderId'");
			$wpdb->query("update ".$wpdb->prefix."walleto_order_contents set paid='1',paid_on='$invoice_date' where orderid='$orderId'");
				
			$buyerId = $uid; 
			


			foreach ($selArr  as $key => $value) {
					Walleto_send_email_when_item_is_paid_seller($orderId,$value,$buyerId);
			}
			Walleto_send_email_when_item_is_paid_buyer($orderId, $buyerId);
			
			// H&T BANK UPDATE
			$bk_cr = Walleto_get_credits(87);
			Walleto_update_credits(87, $bk_cr + $ttl_amt);
			$bk_reason = sprintf(__("USER PAID against invoice %d via EcoCash.","Walleto"), $inv_num); 			
			walleto_add_history_log('1', $bk_reason, $ttl_amt, 87);				

			/*SMS*/
			$tel = $userTel = 0;
			$userTel = get_cimyFieldValue($uid, "TELEPHONE");
			$userTel = cimy_uef_sanitize_content($userTel);
			$userTel = intval($userTel);
			// COUNTRY TELEPHONE CODE
			$userCountry = get_cimyFieldValue($uid, "COUNTRY");
			$userCountry = cimy_uef_sanitize_content($userCountry);
			$tel = wl_get_ctry_dcode($userCountry);
			$tel .= $userTel;
			$curr_sym = walleto_get_currency();
			$msg = __("Dear Customer, You have made a payment of ".$curr_sym.$ttl_amt." through EcoCash for invoice ".$inv_num.". You will be notified when it is ready for delivery/pick up. Thank you HTSM", "Walleto");
			Walleto_send_sms($tel, $msg);				
			/*SMS*/

			$reason = sprintf(__("Paid through EcoCash against invoice %d.","Walleto"), $inv_num); 
			walleto_add_history_log('0', $reason, $ttl_amt, $uid);

			/* UPDATE PAID INFORMATION TO ORDER META */
			wl_update_order_meta($orderId, "paid_info", "EcoCash");
		}
		
	}	


if(isset($_GET['notify_deposit_ecash']))
{

	//write a file to show that paynow silently visisted us sometime
	file_put_contents('deposit_ecash_visit.txt', date('d m y h:i:s') . ' Ecocash visited us ' . PHP_EOL , FILE_APPEND | LOCK_EX);
	$get_post = file_get_contents('php://input');

	$ecocash_array = json_decode($get_post, TRUE);
	//$referenceCode = $ecocash_array['referenceCode'];
	$amount = $ecocash_array['paymentAmount']['charginginformation']['amount'];
	$transactionOperationStatus = $ecocash_array['transactionOperationStatus'];
	$version = $ecocash_array['version'];

	if($transactionOperationStatus == "COMPLETED" AND $version == 1) {
		
		global $wpdb;
		//$status = $_POST['status'];
		//$amount = $referenceCode;
		$hash = $_GET['myhsh']; 
		
		$hsh_ = get_option('hsh_' . $hash);
		$exp = explode('|', $hsh_);
		
		$uid = $exp[0];
		$datemade = $exp[1];
		
		$op = get_option('Walleto_deposit_'.$uid.$datemade.$exp[2]);
		
		//----------------------------------------------------------

		$data = $wpdb->get_results("SELECT * FROM `wp_walleto_logs` WHERE `id` = '" . $exp[2] . "'", OBJECT);
		if($data[0]->status == 0 AND $version == 1)
		{
			//write a file to show that paynow silently visisted us sometime
			file_put_contents('deposit_ecash_payment.txt', date('d m y h:i:s') . ' Ecocash confirmed payment for ' . implode('|||' , $data[0]) . PHP_EOL , FILE_APPEND | LOCK_EX);

			$mc_gross = (int)str_replace(",", "", $amount);
			$amt_show = Walleto_get_show_price($mc_gross);
			
			$cr = Walleto_get_credits($uid);
			
			if($version == 1)
			{
				Walleto_update_credits($uid, $mc_gross + $cr);

				// H&T BANK UPDATE
				$bk_cr = Walleto_get_credits(87);
				Walleto_update_credits(87, $bk_cr + $mc_gross);		
				// H&T BANK UPDATE
				$bk_reason = __("USER DEPOSIT via EcoCash. Ref: HL" . $data[0]->id ,"Walleto"); 			
				Walleto_add_history_log('1', $bk_reason, $mc_gross, 87);
				
				update_option('Walleto_deposit_'.$uid.$datemade, "1");
				$reason = __("Deposit through EcoCash. Ref: HL" . $data[0]->id ,"Walleto"); 
				Walleto_add_history_log('1', $reason, $mc_gross, $uid);
			}
				

			$usrobj = get_user_by('id', $uid);
			$admin_email = get_option( 'admin_email' );								
			
			$reason = __("Deposit through EcoCash.","Walleto"); 			
			$message = __('Hi '.$usrobj->user_login.PHP_EOL.PHP_EOL.'Your account has been credited with '.$mc_gross.PHP_EOL.'You can log on to our website for further process.','Walleto');
			$adm_message = __('Hi Administrator'.PHP_EOL.PHP_EOL.$usrobj->user_login.' has deposited '.$amt_show.' amount via EcoCash payment method'.PHP_EOL,'Walleto');
			Walleto_send_email($usrobj->user_email, $reason, $message);
			Walleto_send_email($admin_email, "USER DEPOSIT", $adm_message);
			Walleto_send_sms('263776214825', 'Ecocash visit log id ' . $data[0]->id );
			Walleto_send_email('ekamundaranga@hammerandtongues.com', "ECOCASH DEPOSIT", "PLEASE CHECK Walleto_log_id" . $data[0]->id . PHP_EOL  . implode('|||' , $data[0]) . PHP_EOL . implode('|||', $ecocash_array));

			/*SMS*/
			$tel = $userTel = 0;
			$userTel = get_cimyFieldValue($uid, "TELEPHONE");
			$userTel = cimy_uef_sanitize_content($userTel);
			$userTel = intval($userTel);
			// COUNTRY TELEPHONE CODE
			$userCountry = get_cimyFieldValue($uid, "COUNTRY");
			$userCountry = cimy_uef_sanitize_content($userCountry);
			$tel = wl_get_ctry_dcode($userCountry);
			$tel .= $userTel;
			$msg = __("your payment of ".$mc_gross." through EcoCash has been deposited to your ewallet. Thanks HT team", "Walleto");
			Walleto_send_sms($tel, $msg);				
			/*SMS*/				
			/*update table of succesful transaction*/
			$wpdb->update("wp_walleto_logs", array("status" => 1), array('id' => $exp[2]));
			die();
		}
		else
		{
			Walleto_send_email('ekamundaranga@hammerandtongues.com', "ECOCASH DEPOSIT FAILED ERROR CODE: 1", "PLEASE CHECK " . implode('|||' , $data[0]) . PHP_EOL . implode('|||', $ecocash_array));
		}
	}	
	else
	{
		Walleto_send_email('ekamundaranga@hammerandtongues.com', "ECOCASH DEPOSIT FAILED ERROR CODE 2", "PLEASE CHECK " . implode('|||' , $data[0]) . PHP_EOL . implode('|||', $ecocash_array));
	}
}

	if(isset($_GET['notify_deposit_vpayments']))
	{
		$status = $_POST['status'];
		$amount = $_POST['Amount'];
		$hash = $_GET['myhsh']; 
		
		$hsh_ = get_option('hsh_' . $hash);
		$exp = explode('|', $hsh_);
		
		$uid = $exp[0];
		$datemade = $exp[1];
		
		$op = get_option('Walleto_deposit_'.$uid.$datemade);
		
		//----------------------------------------------------------
		
		if($op != "1")
		{
			$mc_gross = (int)str_replace(",", "", $amount);
			$amt_show = $mc_gross;
			
			$cr = Walleto_get_credits($uid);
			Walleto_update_credits($uid, $mc_gross + $cr);

			// H&T BANK UPDATE
			$bk_cr = Walleto_get_credits(87);
			Walleto_update_credits(87, $bk_cr + $mc_gross);				

			$usrobj = get_user_by('id', $uid);	
			$admin_email = get_option( 'admin_email' );				
			
			$reason = __("Deposit through Vpayments.","Walleto"); 			
			$message = __('Hi '.$usrobj->user_login.PHP_EOL.PHP_EOL.'Your account has been credited with '.$mc_gross.PHP_EOL.'You can log on to our website for further process.','Walleto');
			$adm_message = __('Hi Administrator'.PHP_EOL.PHP_EOL.$usrobj->user_login.' has deposited '.$amt_show.' amount via Vpayments payment method'.PHP_EOL,'Walleto');
			Walleto_send_email($usrobj->user_email, $reason, $message);
			Walleto_send_email($admin_email, "USER DEPOSIT", $adm_message);

			// H&T BANK UPDATE
			$bk_reason = __("USER DEPOSIT via Vpayments.","Walleto"); 			
			Walleto_add_history_log('1', $bk_reason, $mc_gross, 87);			
			
			update_option('Walleto_deposit_'.$uid.$datemade, "1");
			$reason = __("Deposit through Vpayments.","Walleto"); 
			Walleto_add_history_log('1', $reason, $mc_gross, $uid);

			/*SMS*/
			$tel = $userTel = 0;
			$userTel = get_cimyFieldValue($uid, "TELEPHONE");
			$userTel = cimy_uef_sanitize_content($userTel);
			$userTel = intval($userTel);
			// COUNTRY TELEPHONE CODE
			$userCountry = get_cimyFieldValue($uid, "COUNTRY");
			$userCountry = cimy_uef_sanitize_content($userCountry);
			$tel = wl_get_ctry_dcode($userCountry);
			$tel .= $userTel;
			$msg = __("your payment of ".$mc_gross." through Vpayments has been deposited to your ewallet. Thanks HT team", "Walleto");
			Walleto_send_sms($tel, $msg);				
			/*SMS*/

			
			//$reason = __("PayPal deposit fee.","Walleto"); 
			//Walleto_add_history_log('0', $reason, $_POST['mc_fee'], $uid);
		
		}
		
		die();	
	}
		
	if(isset($_GET['notify_deposit_visamaster']))
	{
		$hash = $_GET['hsh']; 
		$hsh_ = get_option('hsh_' . $hash);
		delete_option('hsh_' . $hash);
		$dpot = explode('|', $hsh_);
		
		$uid = $dpot[0];
		$datemade = $dpot[1];
		$amount = $dpot[2];
		$chkUrl = $dpot[3];
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $chkUrl);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $postString);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		
		// receiving server response
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		
		$server_output = curl_exec($ch);
		curl_close ($ch);
		
		if ($server_output)
		{
			$response = intval($server_output);
			if($response == 2) {
				$op = get_option('Walleto_deposit_'.$uid.$datemade);
				if($op != "1")
				{
					$mc_gross = (int)str_replace(",", "", $amount);
					$amt_show = $mc_gross;
					
					$cr = Walleto_get_credits($uid);
					Walleto_update_credits($uid, $mc_gross + $cr);

					// H&T BANK UPDATE
					$bk_cr = Walleto_get_credits(87);
					Walleto_update_credits(87, $bk_cr + $mc_gross);					

					$usrobj = get_user_by('id', $uid);	
					$admin_email = get_option( 'admin_email' );				
					
					$reason = __("Deposit through Visa/MasterCard.","Walleto"); 			
					$message = __('Hi '.$usrobj->user_login.PHP_EOL.PHP_EOL.'Your account has been credited with '.$mc_gross.PHP_EOL.'You can log on to our website for further process.','Walleto');
					$adm_message = __('Hi Administrator'.PHP_EOL.PHP_EOL.$usrobj->user_login.' has deposited '.$amt_show.' amount via Visa/MasterCard payment method'.PHP_EOL,'Walleto');
					$msg = __("Your payment deposit through Visa/MasterCard.","Walleto"); 			
					Walleto_send_email($usrobj->user_email, $reason, $message);
					Walleto_send_email($admin_email, "USER DEPOSIT", $adm_message);

					// H&T BANK UPDATE
					$bk_reason = __("USER DEPOSIT via Visa/MasterCard.","Walleto"); 			
					Walleto_add_history_log('1', $bk_reason, $mc_gross, 87);					
					
					update_option('Walleto_deposit_'.$uid.$datemade, "1");
					$reason = __("Deposit through Visa/MasterCard.","Walleto"); 
					Walleto_add_history_log('1', $reason, $mc_gross, $uid);	

					/*SMS*/
					$tel = $userTel = 0;
					$userTel = get_cimyFieldValue($uid, "TELEPHONE");
					$userTel = cimy_uef_sanitize_content($userTel);
					$userTel = intval($userTel);
					// COUNTRY TELEPHONE CODE
					$userCountry = get_cimyFieldValue($uid, "COUNTRY");
					$userCountry = cimy_uef_sanitize_content($userCountry);
					$tel = wl_get_ctry_dcode($userCountry);
					$tel .= $userTel;
					$msg = __("your payment of ".$mc_gross." through Visa/MasterCard has been deposited to your ewallet. Thanks HT team", "Walleto");
					Walleto_send_sms($tel, $msg);				
					/*SMS*/

					$re_url = add_query_arg('st','1', get_permalink(get_option('Walleto_my_account_my_finances_page_id')));
					wp_redirect($re_url);
					exit;					
				}
			} else {
				$re_url = add_query_arg('fst','1', get_permalink(get_option('Walleto_my_account_my_finances_page_id')));
				wp_redirect($re_url);
				exit;			
			}
		} else {
			$re_url = add_query_arg('fst','1', get_permalink(get_option('Walleto_my_account_my_finances_page_id')));
			wp_redirect($re_url);
			exit;		
		}
	}	
	
	global $wp;
	global $wp_query, $wp_rewrite, $post;
	$paagee 	=  $wp_query->query_vars['my_custom_page_type'];
	$w_action 	=  $wp_query->query_vars['w_action'];
	
	$my_pid = $post->ID;
	$Walleto_post_new_page_id 					= get_option('Walleto_post_new_page_id');
	$Walleto_my_account_page_id					= get_option('Walleto_my_account_page_id');
	$Walleto_my_cart_page_id 					= get_option('Walleto_shopping_cart_page_id');
	$Walleto_checkout_page_id					= get_option('Walleto_checkout_page_id');
	$Walleto_my_account_pur_mem_page_id 		= get_option('Walleto_my_account_pur_mem_page_id');
	$Walleto_my_account_pur_mem_crds_page_id	= get_option('Walleto_my_account_pur_mem_crds_page_id');
	$Walleto_set_delivery_page_id				= 1700;
	$Walleto_set_pickup_page_id					= 5836;
	$Walleto_cmnbskt_page_id					= 21026;
	
	if(isset($_GET['switch_grd']))
	{
		 
		$_SESSION['view_tp'] = $_GET['switch_grd'];
		wp_redirect($_GET['get_urls']);
		die();
		
	}
	
				
	if($post->post_parent == $Walleto_my_account_page_id or $my_pid == $Walleto_my_account_page_id or $Walleto_checkout_page_id == $my_pid or $my_pid == $Walleto_my_account_pur_mem_page_id or
	 $my_pid == $Walleto_my_account_pur_mem_crds_page_id or $my_pid == $Walleto_set_delivery_page_id or $my_pid == $Walleto_set_pickup_page_id or $my_pid == $Walleto_cmnbskt_page_id or $my_pid == $Walleto_my_cart_page_id)
	{
		if(!is_user_logged_in())
		{
			wp_redirect(get_bloginfo('siteurl') . "/wp-login.php?redirect_to=" . walleto_sm_replace_me(walleto_curPageURL_me()));
			exit;	
		}
			
	}
	
	if ( in_array( $GLOBALS['pagenow'], array( 'wp-login.php') ) && is_user_logged_in() ) {
		wp_redirect(Walleto_my_account_link());
		exit;
	}
	
	if($my_pid == $Walleto_my_account_pur_mem_crds_page_id)
	{
		if($_GET['confirm'] == "nok") 
		{
			wp_redirect(get_permalink(get_option('Walleto_my_account_pur_mem_page_id')));
			die();	
		}
	}
	
	if($my_pid == $Walleto_post_new_page_id)
	{
		if(!is_user_logged_in())
		{
			wp_redirect(get_bloginfo('siteurl') . "/wp-login.php?redirect_to=" . walleto_sm_replace_me(walleto_curPageURL_me()));
			exit;	
		}
		
		if(!isset($_GET['product_id'])) $set_ad = 1; else $set_ad = 0;
		global $current_user;
		get_currentuserinfo();
		
		if(walleto_check_if_shop_membership_is_valid($current_user->ID) == false)
		{
			$Walleto_shop_subscriptions = get_option('Walleto_shop_subscriptions');
			if($Walleto_shop_subscriptions != 'no'):
				wp_redirect(get_permalink(get_option('Walleto_my_account_shop_setup_page_id'))); die();	
			endif;
		}
		
		if($set_ad == 1)
		{
			$pid 		= walleto_get_auto_draft($current_user->ID);
			wp_redirect(walleto_post_new_with_pid_stuff_thg($pid));
		}
		
		if(!empty($_GET['product_id']))
		{
			$my_main_post = get_post($_GET['product_id']);
			if($my_main_post->post_author != $current_user->ID)
			{
				wp_redirect(get_bloginfo('siteurl')); exit;	
			}
			
		}
		
		do_action('Walleto_product_post_post_new_redirect');
		
		include 'lib/post_new_post.php';		
	}
	
	if(isset($_GET['_ad_delete_pid']))
	{
		if(is_user_logged_in())
		{
			$pid	= $_GET['_ad_delete_pid'];
			$pstpst = get_post($pid);
			global $current_user;
			get_currentuserinfo();
			
			//if($pstpst->post_author == $current_user->ID)
			//{
				wp_delete_post($_GET['_ad_delete_pid']);	
				echo "done";
			//}
		}
		exit;	
	}
	
	
	
	if($w_action == 'skrill_order_response')
	{
		include 'lib/gateways/skrill_order_response.php';
		die();
	}
	
	if($w_action == 'user_feedback')
	{
		include 'lib/user_feedback.php';
		die();
	}
	
	
	if($w_action == 'deposit_pay')
	{
		include 'lib/gateways/deposit_pay.php';
		die();
	}
	
	if($w_action == 'deposit_pay_moneybookers')
	{
		include 'lib/gateways/deposit_pay_moneybookers.php';
		die();
	}
	
	if($w_action == 'mb_deposit_response')
	{
		include 'lib/gateways/mb_deposit_response.php';
		die();
	}
	
	
	if(isset($_GET['register_category_for_pid']))
	{
		if(is_user_logged_in())
		{
			$term = get_term( $_POST['category'], 'product_cat' );	
			$product_category = $term->slug;
			$pid = $_POST['pid'];
			wp_set_object_terms($_POST['pid'], array($product_category),'product_cat');
			$xx = $term->term_id;
			//------------------------------------------------------
			
					global $wpdb;
					$kk = 0;
					
					if($xx > 0):	
						
						 
						$s1 = "select * from ".$wpdb->prefix."walleto_variations where category_id='$xx' or category_id='0' order by order_id asc";
						$r1 = $wpdb->get_results($s1);
						
						if(count($r1) > 0):
							
							foreach($r1 as $row1):
								
								$taxonomies = get_terms( $row1->slug, 'hide_empty=0' ); 
								if(count($taxonomies) > 0):
									
									$main_array[] = $taxonomies;
								
								endif;								
							endforeach;
						endif;		
						
						if(is_array($main_array))		
						$result_array = ProjectTheme_array_cartesian_product($main_array);				
						
						if(count($result_array) > 0)
						{
							?>
                            
                            	<li>
                                	<h3 class="variety_name"><?php _e('Product Variance','Walleto'); ?></h3>
                                </li>
                                
                               <li>
                                	<span class="small_fonts"><?php _e('Please fill in at least the quantity field to take into consideration. Leave empty if the product variance is not available. Also if price is left empty the base price will be considered.','Walleto'); ?></span>
                                </li>
                            
                            <?php
							
							foreach($result_array as $combination)
							{
								if(is_array($combination))
								{
									$cnts = count($combination);
									$string_array_name = '';
									$variance_internal_sku = '';
									
									$terms_ids = array();
									$terms_taxes = array();
									
									foreach($combination as $single_variance)
									{
										$ProjectTheme_get_product_variance = ProjectTheme_get_product_variance($single_variance->taxonomy);
										if($ProjectTheme_get_product_variance != false) $ProjectTheme_get_product_variance = $ProjectTheme_get_product_variance->name . ": ";										
										//-----------------
										
										$string_array_name .= $ProjectTheme_get_product_variance.$single_variance->name;
										$cnts--;
										
										if(	$cnts > 0) $string_array_name .= ', ';
										//$variance_internal_sku .= $single_variance->term_id.'_';	
										
										$terms_ids[] = 	$single_variance->term_id;
										$terms_taxes[] = 	$single_variance->taxonomy;							
									}
									
									asort($terms_ids);
									foreach($terms_ids as $tms) {  $variance_internal_sku .= $tms.'_';	 }
										
									$sf = "select * from ".$wpdb->prefix."walleto_variations_content where pid='$pid' and variation_string='$variance_internal_sku'";
									$rf = $wpdb->get_results($sf);
									
									if(count($rf) > 0)
									{
										$price_variance_ 	= $rf[0]->price;	
										$quant_variance_ 	= $rf[0]->quant;
										$weight_variance_ 	= $rf[0]->weight;
									}
									else
									{
										$price_variance_ 	= '';	
										$quant_variance_ 	= '';
										$weight_variance_ 	= '';
									}
									
									?>
										
									 <li><h2 class="prod_variances_h2"><?php echo $string_array_name; ?></h2>
											<p>
												<?php _e('Price:','Walleto'); ?> <input type="text" class="do_input" name="price_variance_<?php echo $variance_internal_sku ?>"  size="10" value="<?php echo $price_variance_ ?>" /> 
												<?php _e('Quantity:','Walleto'); ?> <input type="text" class="do_input" name="quant_variance_<?php echo $variance_internal_sku ?>" size="10" value="<?php echo $quant_variance_ ?>" />
												<?php _e('Weight:','Walleto'); ?> <input type="text" class="do_input" name="weight_variance_<?php echo $variance_internal_sku ?>" size="10" value="<?php echo $weight_variance_ ?>" /> 
											
											</p>
										</li>
										<hr color="#f2f2f2" />
						
									
									<?php
								}
								
							}					
							
						}
										
                   endif; 
                        
                         if($kk > 0) { echo '<li>&nbsp;</li>'; }  
			
			//------------------------------------------------------
		}
		
		 
		die();	
	}
	
	if(isset($_POST['deposit_pay_me']))
	{
		global $am_err;
		$amount = trim($_POST['amount']);
		if(empty($amount)) $am_err = 1;	
		elseif(!is_numeric($amount)) $am_err = 1;
		else
		{
			wp_redirect(get_bloginfo('siteurl') . "/?w_action=deposit_pay&am=" . $amount);	 exit;		
		}
	}

	/*Spidanet extra payments starts*/
	if(isset($_POST['deposit_vpayments_me']))
	{
		global $am_err;
		$amount = trim($_POST['amount']);
		if(empty($amount)) $am_err = 1;	
		elseif(!is_numeric($amount)) $am_err = 1;
		else
		{
			wp_redirect(get_bloginfo('siteurl') . "/?a_action=deposit_vpayments&am=" . $amount);	 exit;		
		}
	}
	
	if(isset($_POST['deposit_visamaster_me']))
	{
		global $am_err;
		$amount = trim($_POST['amount']);
		if(empty($amount)) $am_err = 1;	
		elseif(!is_numeric($amount)) $am_err = 1;
		else
		{
			wp_redirect(get_bloginfo('siteurl') . "/?a_action=deposit_visamaster&am=" . $amount);	 exit;		
		}
	}	
	
	if(isset($_POST['deposit_ecash_me']))
	{
		global $am_err;
		$amount = trim($_POST['amount']);
		if(empty($amount)) $am_err = 1;	
		elseif(!is_numeric($amount)) $am_err = 1;
		else
		{
			wp_redirect(get_bloginfo('siteurl') . "/?a_action=deposit_ecash&am=" . $amount);	 exit;		
		}
	}
	
	if(isset($_POST['deposit_tcash_me']))
	{
		global $am_err;
		$amount = trim($_POST['amount']);
		if(empty($amount)) $am_err = 1;	
		elseif(!is_numeric($amount)) $am_err = 1;
		else
		{
			wp_redirect(get_bloginfo('siteurl') . "/?a_action=deposit_tcash&am=" . $amount);	 exit;		
		}
	}	
	
	if(isset($_POST['deposit_paynow_me']))
	{
		global $am_err;
		$amount = trim($_POST['amount']);
		if(empty($amount)) $am_err = 1;	
		elseif(!is_numeric($amount)) $am_err = 1;
		else
		{
			wp_redirect(get_bloginfo('siteurl') . "/?a_action=deposit_paynow&am=" . $amount);	 exit;		
		}
	}
	/*Spidanet extra payments ends*/
	if(isset($_POST['deposit_pay_alertpay']))
	{
		global $am_err;
		$amount = trim($_POST['amount']);
		if(empty($amount)) $am_err = 1;	
		elseif(!is_numeric($amount)) $am_err = 1;
		else
		{
			wp_redirect(get_bloginfo('siteurl') . "/?w_action=deposit_pay_alertpay&am=" . $amount);	 exit;		
		}
	}
	
	
	if(isset($_POST['deposit_pay_moneybookers']))
	{
		global $am_err;
		$amount = trim($_POST['amount']);
		if(empty($amount)) $am_err = 1;	
		elseif(!is_numeric($amount)) $am_err = 1;
		else
		{
			wp_redirect(get_bloginfo('siteurl') . "/?w_action=deposit_pay_moneybookers&am=" . $amount);	 exit;		
		}
	}
	
	//-------------------------------------------------------------------
	
	if(isset($_GET['pay_order_by_paypal']))
	{
		include 'lib/gateways/pay_order_by_paypal.php';
		die();	
	}
	
	if(isset($_GET['uploady_thing']))
	{
 
		include 'my-upload.php';
		die();	
	}
	
	if($w_action == 'rate_user')
	{
		include 'lib/my_account/rate_user.php';
		die();
	}
	
	
	if(isset($_POST['agree_and_pay']))
	{
		if(isset($_POST['con_dvry_type']) && !empty($_POST['con_dvry_type'])) {
			global $current_user;
			get_currentuserinfo();
			$uid = $current_user->ID;
			if(!session_id()) {
				ob_start(); 		
				session_start();
			}			
			$dlvry_type = $_POST['con_dvry_type'];
			if($dlvry_type == "pkup") :
				$userCity = intval($_POST['con_pkup_cty']);
				if(empty($userCity)) {
					$userCity = get_cimyFieldValue($uid, "CITY");
				}
				$usercty = Walleto_get_city($userCity);
				if($usercty->cltn_pnt_avail && $usercty->cltn_pnts) {
					// Get available pick up locations and their charges
					$cltn_pts = maybe_unserialize($usercty->cltn_pnts);
					$cltn_pnt_uptd = array();
					$j = 0;
					foreach($cltn_pts as $key => $cltn_pnt) {
						// Check whether buyer has applied a discount coupon for discount in pick up charges						
						if(isset($_SESSION['dlvry_dcnt']) && !empty($_SESSION['dlvry_dcnt'])) {
							$dlvry_discnt = $dcnt_pkup_tmp = 0;
							$dlvry_discnt = $_SESSION['dlvry_dcnt'];
							
							if($_SESSION['dlvry_dcnt_type'] == "percentage") {
								$dcnt_pkup_tmp = $cltn_pnt[1] * ($dlvry_discnt/100);
							} elseif($_SESSION['dlvry_dcnt_type'] == "flat") {
								$dcnt_pkup_tmp = $dlvry_discnt;
							}
							$dcnt_pkup_tmp = Walleto_formats($dcnt_pkup_tmp, 2);
							$cltn_pnt[1] -= $dcnt_pkup_tmp;
							$cltn_pnt_uptd[$j] = array($cltn_pnt[0], $cltn_pnt[1], $dcnt_pkup_tmp);
						} else {
							$dcnt_pkup_tmp = 0;
							$cltn_pnt_uptd[$j] = array($cltn_pnt[0], $cltn_pnt[1], $dcnt_pkup_tmp);
						}
						$j = $j +1;
					}
					$_SESSION['pickup_ask'] = maybe_serialize($cltn_pnt_uptd);
					$_SESSION['delivery_pkupnote'] = 2;
					$_SESSION['delivery_mthd'] = "pickup";					
				} else {
					$_SESSION['delivery_pkupnote'] = 1;
				}
				wp_redirect(get_permalink(1700));
				die();
			elseif($dlvry_type == "dvry") :
				global $current_user;
				get_currentuserinfo();
				$uid = $current_user->ID;				
				$dlvry_add = $_POST['con_address'];
				$wl_zne = "";
				if($dlvry_add == "alternate") {
					$usr_alt_add = "";
					$alt_add_line_1 = trim($_POST['alt_add_line1']);
					$usr_alt_add .= $alt_add_line_1.", ";
					
					$alt_add_line_2 = trim($_POST['alt_add_line2']);
					if(!empty($alt_add_line_2)) {
						$usr_alt_add .= $alt_add_line_2.", ";
					}
					
					$alt_add_suburb = intval(trim($_POST['alt_add_suburb']));
					$alt_add_suburb_obj = Walleto_get_suburb($alt_add_suburb);					
					$usr_alt_add .= $alt_add_suburb_obj->sbrb_name.", ";
					
					$alt_add_city = intval(trim($_POST['alt_add_city']));
					$alt_add_city_obj = Walleto_get_city($alt_add_city);
					$usr_alt_add .= $alt_add_city_obj->cty_name.", ";
					
					$alt_add_region = intval(trim($_POST['alt_add_region']));
					$alt_add_region_nme = Walleto_get_region($alt_add_region);
					$usr_alt_add .= $alt_add_region_nme.", ";
					
					$alt_add_cntry = trim($_POST['alt_add_cntry']);
					$usr_alt_add .= $alt_add_cntry;
					
					$wl_zne_id = Walleto_get_sbrb_zne($alt_add_suburb);
					$wl_zne = Walleto_get_zne($wl_zne_id);
					$enc_alt_add = json_encode(array($usr_alt_add, $wl_zne_id));
					$_SESSION['delivery_altadd'] = $enc_alt_add;
				} else {
					$sbrb_id = get_cimyFieldValue($uid, "SUBURB");
					$wl_zne_id = Walleto_get_sbrb_zne($sbrb_id);
					$wl_zne = Walleto_get_zne($wl_zne_id);
					$_SESSION['delivery_altadd'] = NULL;
				}
				// Iterating through cart available in session variable to get average item price			
				$wl_cty = Walleto_get_city($wl_zne->cty_id);
				if($wl_cty->dlvry_avail) {
					//$cart = $_COOKIE['my_cart'];
					//$cart = stripslashes($cart);
					//$cart = unserialize($cart);
					//$cart = $cart['my_cart'];
					$cart = $_SESSION['cart_items'];
					$prc_t = $quant = $avg_prc = $avg_itm_prc = 0; 	
					if(is_array($cart) and count($cart) > 0)
					{
						$discount = intval($_SESSION['coupon_total']);
						foreach($cart as $item)
						{							
							$pid	 			= $item['pid'];
							/* Check whether buyer has applied a discount coupon on this product */
							$cde_dcnt = wl_get_applied_cc($pid);							
							$pp	= Walleto_get_item_price($item['pid']);
							if(!empty($cde_dcnt)) {
								$pp	= $pp - $cde_dcnt;
							}
							$prc = $pp;	
							$quant += $item['quant'];							
							$prc_t += $prc*$item['quant'];
						}
					}
					
					if(!empty($discount)){
						$prc_t -= $discount;
					}
					$avg_itm_prc = $prc_t / $quant;
					$avg_prc = round( $avg_itm_prc, 0, PHP_ROUND_HALF_DOWN );
					$pkg_size = Walleto_get_package($avg_prc);
					$zne_charge = json_decode($wl_zne->zne_charge, true);
					$dlvry_type = "";
					$dlvry_charge = $nml_dlvry_charge = $exp_dlvry_charge = $ext_dlvry_charge = $dlvry_lmt = 0;
					$dlvry_lmt = intval(get_option("Walleto_free_delivery_lmt"));
					$dlvry_lmt = ($dlvry_lmt > 0) ? $dlvry_lmt : 249;
					//Check for free shipping benefit available for this user
					global $current_user;
					global $wpdb;
					get_currentuserinfo();
					$uid = $current_user->ID;
					$dcnt_nml_tmp = $dcnt_nml_bft_tmp = $dcnt_exp_bft_tmp = $dcnt_ext_bft_tmp = 0;					
					$byr_rwd_lvl = get_user_meta($uid, 'byr_rwd_lvl', true);
					$is_byr_fr_shp = get_user_meta($uid, 'byr_fr_shp', true);
					if($prc_t <= $dlvry_lmt && !wl_chk_lvl_benefit($byr_rwd_lvl, "Free Shipping") && $is_byr_fr_shp != "yes") {
						$nml_dlvry_charge = $zne_charge["normal"][$pkg_size];
						$exp_dlvry_charge = $zne_charge["express"][$pkg_size];
						$ext_dlvry_charge = $zne_charge["extended"][$pkg_size];
						
						// Check whether this user is eligible for discount in delivery charges depend on their membership level
						if(!empty($byr_rwd_lvl)) {
							$qry = "SELECT reward FROM $wpdb->prefix"."walleto_rewards WHERE reward_lvl='$byr_rwd_lvl'";
							$srlzd_rwds = $wpdb->get_var($qry);
							$wl_rwds_arr = maybe_unserialize($srlzd_rwds);
							$dlvry_discnt = 0;
							if(!empty($wl_rwds_arr)) {
								foreach($wl_rwds_arr as $wl_rwd) :
									if(strpos($wl_rwd, "DeliveryDiscount") !== false) {
										$wl_rwd_data = explode("|", $wl_rwd);
										$dlvry_discnt = $wl_rwd_data[1];
										break;
									}
								endforeach;
							}
							if($dlvry_discnt > 0) {
								$dcnt_nml_tmp = $nml_dlvry_charge * ($dlvry_discnt/100);
								$dcnt_nml_tmp = Walleto_formats($dcnt_nml_tmp, 2);
								$dcnt_nml_bft_tmp = $dcnt_nml_tmp;
								$nml_dlvry_charge -= $dcnt_nml_tmp;
								
								$dcnt_exp_tmp = $exp_dlvry_charge * ($dlvry_discnt/100);
								$dcnt_exp_tmp = Walleto_formats($dcnt_exp_tmp, 2);
								$dcnt_exp_bft_tmp = $dcnt_exp_tmp;
								$exp_dlvry_charge -= $dcnt_exp_tmp;
								
								$dcnt_ext_tmp = $ext_dlvry_charge * ($dlvry_discnt/100);
								$dcnt_ext_tmp = Walleto_formats($dcnt_ext_tmp, 2);
								$dcnt_ext_bft_tmp = $dcnt_ext_tmp;
								$ext_dlvry_charge -= $dcnt_ext_tmp;
							}
						}
						
						// Check whether buyer has applied a discount coupon for discount in delivery charge
						if(isset($_SESSION['dlvry_dcnt']) && !empty($_SESSION['dlvry_dcnt'])) {
							$dlvry_discnt = 0;
							$dlvry_discnt = $_SESSION['dlvry_dcnt'];
							if($_SESSION['dlvry_dcnt_type'] == "percentage") {
								$dcnt_nml_tmp = $nml_dlvry_charge * ($dlvry_discnt/100);
							} elseif($_SESSION['dlvry_dcnt_type'] == "flat") {
								$dcnt_nml_tmp = $dlvry_discnt;
							}
							$dcnt_nml_tmp = Walleto_formats($dcnt_nml_tmp, 2);
							$nml_dlvry_charge -= $dcnt_nml_tmp;
							
							if($_SESSION['dlvry_dcnt_type'] == "percentage") {
								$dcnt_exp_tmp = $nml_dlvry_charge * ($dlvry_discnt/100);
							} elseif($_SESSION['dlvry_dcnt_type'] == "flat") {
								$dcnt_exp_tmp = $dlvry_discnt;
							}							
							$dcnt_exp_tmp = Walleto_formats($dcnt_exp_tmp, 2);
							$exp_dlvry_charge -= $dcnt_exp_tmp;
							
							if($_SESSION['dlvry_dcnt_type'] == "percentage") {
								$dcnt_ext_tmp = $nml_dlvry_charge * ($dlvry_discnt/100);
							} elseif($_SESSION['dlvry_dcnt_type'] == "flat") {
								$dcnt_ext_tmp = $dlvry_discnt;
							}							
							$dcnt_ext_tmp = Walleto_formats($dcnt_ext_tmp, 2);
							$ext_dlvry_charge -= $dcnt_ext_tmp;						
						}						
						
					} else {
						$nml_dlvry_charge = 0;
						$exp_dlvry_charge = 0;
						$ext_dlvry_charge = 0;
					}
					// Check whether express delivery currently available or not
					$curHour = date('h:i a', current_time( 'timestamp', 0 ));
					$curDay = date('l', current_time( 'timestamp', 0 ));
					$date1 = DateTime::createFromFormat('h:i a', $curHour);
					$date2 = DateTime::createFromFormat('h:i a', "08:00 am");
					$date3 = DateTime::createFromFormat('h:i a', "12:00 pm");
					if($date1 >= $date2 && $date1 <= $date3 && $curDay != "Sunday") {
						$wl_dlvry_optns = json_encode(array("normal" => $nml_dlvry_charge."|".($dcnt_nml_tmp+$dcnt_nml_bft_tmp), "express" => $exp_dlvry_charge."|".($dcnt_exp_tmp+$dcnt_exp_bft_tmp), "extended" => $ext_dlvry_charge."|".($dcnt_ext_tmp+$dcnt_ext_bft_tmp)));
					} else {
						$wl_dlvry_optns = json_encode(array("normal" => $nml_dlvry_charge."|".($dcnt_nml_tmp+$dcnt_nml_bft_tmp), "extended" => $ext_dlvry_charge."|".($dcnt_ext_tmp+$dcnt_ext_bft_tmp)));
					}
					$_SESSION['delivery_ask'] = $wl_dlvry_optns;
					wp_redirect(get_permalink(1700));
					die();
				} elseif($wl_cty->cltn_pnt_avail && $wl_cty->cltn_pnts) {
					$_SESSION['delivery_note'] = 2;
					$_SESSION['delivery_mthd'] = "pickup";
					wp_redirect(get_permalink(1700));
					die();
				} else {
					$_SESSION['delivery_note'] = 1;
					wp_redirect(get_permalink(1700));
					die();
				}
			else :
				wp_redirect(get_permalink(1700));
				die();			
			endif;
		}
	}
	// If buyer select pick up location or still want to proceed if not available.
	if(isset($_POST['altdlvry_nonce']))
	{
		if( wp_verify_nonce($_POST['altdlvry_nonce'], 'altdlvry')) {
			$pkup_locinf_enc = trim($_POST['wl_pkup_loc']);
			$pkup_charge = 0;
			$infarr = "";
			$pkup_locinf = e_hash_data($pkup_locinf_enc);
			
			// Adding pick up charge and location to session variable
			$_SESSION['pkup_loc_fee'] = $pkup_locinf;
			// Adding discount to discount variable for further calculation
			$infarr = explode('|', $pkup_locinf);
			$_SESSION['dlvry_dcnt'] = $infarr[2];
			include 'lib/agree_and_pay.php';		
		}
	}

	// If buyer selects delivery method and proceed to payment	
	if(isset($_POST['dlvryask_nonce']))
	{
		if( wp_verify_nonce($_POST['dlvryask_nonce'], 'dlvryask')) {
			$dlvry_mthdinf_enc = trim($_POST['wl_dlvry_mtd']);
			$dlvry_charge = 0;
			$dlvry_mthdinf = e_hash_data($dlvry_mthdinf_enc);
			$infarr = explode('|', $dlvry_mthdinf);
			
			// Adding delivery charge to session variable
			$dlvry_charge = $infarr[1];
			$dlvry_charge = Walleto_formats($dlvry_charge, 2);
			$_SESSION['delivery_total'] = $dlvry_charge;
			$_SESSION['delivery_mthd'] = $infarr[0];
			$_SESSION['dlvry_dcnt'] = $infarr[2];
			include 'lib/agree_and_pay.php';
		}
	}
	
	// When buyer of service shop click proceed to pay
	if(isset($_POST['serv_agree_and_pay']))
	{
		if( wp_verify_nonce($_POST['_servnonce'], 'wl_serv_pay')) {
			global $current_user;
			get_currentuserinfo();
			$uid = $current_user->ID;				
			$dlvry_add = $_POST['con_address'];
			$wl_serv_type = trim($_POST['wl_serv_type']);
			$wl_serv_charge = 0;
			$dcnt_serv_fee_tmp = $dcnt_serv_fee_bft_tmp = 0;
			$enc_alt_add = "";
			$wl_zne = "";
			/* Get order items total */
			$cart = $_SESSION['cart_items'];
			$prc_t = $quant = $avg_prc = $avg_itm_prc = 0; 	
			if(is_array($cart) and count($cart) > 0)
			{
				$discount = intval($_SESSION['coupon_total']);
				foreach($cart as $item)
				{							
					$pid	 			= $item['pid'];
					/* Check whether buyer has applied a discount coupon on this product */
					$cde_dcnt = wl_get_applied_cc($pid);							
					$pp	= Walleto_get_item_price($item['pid']);
					if(!empty($cde_dcnt)) {
						$pp	= $pp - $cde_dcnt;
					}
					$prc = $pp;	
					$quant += $item['quant'];							
					$prc_t += $prc*$item['quant'];
				}
			}
			
			if(!empty($discount)){
				$prc_t -= $discount;
			}
			
			if($dlvry_add == "alternate") {
				$usr_alt_add = "";
				$alt_add_line_1 = trim($_POST['alt_add_line1']);
				$usr_alt_add .= $alt_add_line_1.", ";
				
				$alt_add_line_2 = trim($_POST['alt_add_line2']);
				if(!empty($alt_add_line_2)) {
					$usr_alt_add .= $alt_add_line_2.", ";
				}
				
				$alt_add_suburb = intval(trim($_POST['alt_add_suburb']));
				$alt_add_suburb_obj = Walleto_get_suburb($alt_add_suburb);					
				$usr_alt_add .= $alt_add_suburb_obj->sbrb_name.", ";
				
				$alt_add_city = intval(trim($_POST['alt_add_city']));
				$alt_add_city_obj = Walleto_get_city($alt_add_city);
				$usr_alt_add .= $alt_add_city_obj->cty_name.", ";
				
				$alt_add_region = intval(trim($_POST['alt_add_region']));
				$alt_add_region_nme = Walleto_get_region($alt_add_region);
				$usr_alt_add .= $alt_add_region_nme.", ";
				
				$alt_add_cntry = trim($_POST['alt_add_cntry']);
				$usr_alt_add .= $alt_add_cntry;
				
				$wl_zne_id = Walleto_get_sbrb_zne($alt_add_suburb);
				$wl_zne = Walleto_get_zne($wl_zne_id);
				$enc_alt_add = json_encode(array($usr_alt_add, $wl_zne_id));
				$_SESSION['delivery_altadd'] = $enc_alt_add;			
			} else {
				$_SESSION['delivery_altadd'] = NULL;
			}
			// Delivery charge calculation
			if($enc_alt_add) {
				$wl_serv_charge = intval($alt_add_city_obj->cty_ldry_charge);
			} else {
				$userCity = get_cimyFieldValue($uid, "CITY");
				$usercty = Walleto_get_city($userCity);
				$wl_serv_charge = intval($usercty->cty_ldry_charge);
			}
			$byr_rwd_lvl = get_user_meta($uid, 'byr_rwd_lvl', true);
			$is_byr_fr_shp = get_user_meta($uid, 'byr_fr_shp', true);
			if($wl_serv_type == "serv_pkup") {
				if(!wl_chk_lvl_benefit($byr_rwd_lvl, "Free Shipping") && $is_byr_fr_shp != "yes") {
					$wl_serv_charge = $wl_serv_charge * 1;
				} else {
					$wl_serv_charge = "NA";
				}
			} elseif($wl_serv_type == "serv_pkup_dlvry") {
				if(!wl_chk_lvl_benefit($byr_rwd_lvl, "Free Shipping") && $is_byr_fr_shp != "yes") {
					$wl_serv_charge = $wl_serv_charge * 2;
				} else {
					$wl_serv_charge = "NA";
				}				
			} elseif($wl_serv_type == "no_serv") {
				$wl_serv_charge = "NA";
			} else {
				$wl_serv_charge = "NA";
			}			
			
			// Check whether this user is eligible for discount in delivery charges depend on their membership level
			if(!empty($byr_rwd_lvl) && $wl_serv_charge != "NA") {
				global $wpdb;
				$qry = "SELECT reward FROM $wpdb->prefix"."walleto_rewards WHERE reward_lvl='$byr_rwd_lvl'";
				$srlzd_rwds = $wpdb->get_var($qry);
				$wl_rwds_arr = maybe_unserialize($srlzd_rwds);
				$dlvry_discnt = 0;
				if(!empty($wl_rwds_arr)) {
					foreach($wl_rwds_arr as $wl_rwd) :
						if(strpos($wl_rwd, "DeliveryDiscount") !== false) {
							$wl_rwd_data = explode("|", $wl_rwd);
							$dlvry_discnt = $wl_rwd_data[1];
							break;
						}
					endforeach;
				}
				if($dlvry_discnt > 0) {
					$dcnt_serv_fee_tmp = $wl_serv_charge * ($dlvry_discnt/100);
					$dcnt_serv_fee_tmp = Walleto_formats($dcnt_serv_fee_tmp, 2);
					$dcnt_serv_fee_bft_tmp = $dcnt_serv_fee_tmp;
					$wl_serv_charge -= $dcnt_serv_fee_tmp;					
				}
			}
			
			// Check whether buyer has applied a discount coupon for discount in delivery charge
			if(isset($_SESSION['dlvry_dcnt']) && !empty($_SESSION['dlvry_dcnt'])) {
				$dlvry_discnt = 0;
				$dlvry_discnt = $_SESSION['dlvry_dcnt'];
				if($_SESSION['dlvry_dcnt_type'] == "percentage") {
					$dcnt_serv_fee_tmp = $wl_serv_charge * ($dlvry_discnt/100);
				} elseif($_SESSION['dlvry_dcnt_type'] == "flat") {
					$dcnt_serv_fee_tmp = $dlvry_discnt;
				}
				
				$dcnt_serv_fee_tmp = Walleto_formats($dcnt_serv_fee_tmp, 2);
				$wl_serv_charge -= $dcnt_serv_fee_tmp;				
			}

			// Check whether buyer is eligible for the free delivery based on order total
			$ldry_odr_frdlv_tot = get_option('ldry_odr_fr_dvl_tot');
			$ldry_odr_frdlv_tot = intval( $ldry_odr_frdlv_tot );
			if( !empty($ldry_odr_frdlv_tot) && $prc_t > $ldry_odr_frdlv_tot ) {
				$wl_serv_charge = 0;
			}
			
			$_SESSION['wl_serv_ask'] = $wl_serv_charge."|".($dcnt_serv_fee_tmp+$dcnt_serv_fee_bft_tmp);
			wp_redirect(get_permalink(5836));
			die();
		}
	}
	
	// If buyer selects delivery method and proceed to payment	
	if(isset($_POST['servask_nonce']))
	{
		if( wp_verify_nonce($_POST['servask_nonce'], 'servask')) {
			$serv_charge_enc = trim($_POST['wl_serv_fee']);
			$lgts_serv_charge = 0;
			$lgts_serv_charge = e_hash_data($serv_charge_enc);
			$servinfarr = explode('|', $lgts_serv_charge);
			
			// Adding delivery charge to session variable
			$_SESSION['delivery_total'] = $servinfarr[0];
			$_SESSION['dlvry_dcnt'] = $servinfarr[1];
			$_SESSION['delivery_mthd'] = 'laundry';
			$_SESSION['serv_status'] = 2;
			include 'lib/agree_and_pay.php';
		}
	}
	
	// If buyer selects No for terms and conditions agreement pop up
	if(isset($_POST['n_agrtc_nonce']) && !empty($_POST['n_agrtc_nonce'])) {
		if( wp_verify_nonce($_POST['n_agrtc_nonce'], 'wl_n_agreetc')) {
			//unset($_SESSION['my_cart']);
			//unset($_COOKIE['my_cart']);
			//walleto_remove_cookie('my_cart');
			unset($_SESSION["cart_items"]);
			wp_clearcookie();
			wp_logout();		
		}
	}
	
	// If buyer selects Yes for test drive of a vehicle
	if(isset($_POST['tstdrive_nonce']) && !empty($_POST['tstdrive_nonce']) && !empty($_POST['wl_tstdrivepro']) && !empty($_POST['wl_cond_acpt'])) {
		$wl_tstdrive_cond = e_hash_data(trim($_POST['wl_cond_acpt']));
		$wl_tstdrive_pro = e_hash_data(trim($_POST['wl_tstdrivepro']));
		$pro_obj = get_post($wl_tstdrive_pro);
		if( wp_verify_nonce($_POST['tstdrive_nonce'], 'vhcletstdrive') && $wl_tstdrive_cond == "yes" && $pro_obj) {
			$msg = "";
			global $current_user;
			get_currentuserinfo();
			$uid = $current_user->ID;
			$byr_obj = get_user_by( 'id', $uid );
			$userTel = get_cimyFieldValue($uid, "TELEPHONE");
			
			$msg = "<p>Following user has requested test drive and accepted the disclaimer. Please see the details below.</p><br /><br />";
			$msg .= "<p><label>Name: </label><span>$byr_obj->display_name</span><br />";
			$msg .= "<p><label>Email: </label><span>$byr_obj->user_email</span><br />";
			$msg .= "<p><label>Mobile: </label><span>$userTel</span></p>";
			$msg .= "<p><label>Product ID: </label><span>$pro_obj->ID;</span></p>";
			$msg .= "<p><label>Product Name: </label><span>$pro_obj->post_title;</span></p><br /><br /><br />";
			$tstdrive_email = get_option( 'admin_email' );
			$tstdrive_sub = "TEST DRIVE REQUEST SUBMITTED BY ".$byr_obj->display_name;
			
			if($msg != ''){
				Walleto_send_email($tstdrive_email, $tstdrive_sub, $msg);
			}
		}
	}

	// If buyer wants to log in via Twitter and proceed.
	if( !empty($_GET['for_action']) && !empty($_REQUEST['_wpnonce']) && $_GET['for_action'] == 'Twitter' ) :
		$nonce = $user = $user_email = $sanitized_email = $redirect_url = "";
		$nonce = $_REQUEST['_wpnonce'];
		if ( ! wp_verify_nonce( $nonce, 'social_auth' ) ) {
			$redirect_url = add_query_arg( array( 'login' => 'failed' ), home_url() );
			wp_redirect( $redirect_url ); die(); 
		} else {
			load_template( '/home/hammerandtongues/public_html/shopping/hybridauth/Hybrid/Auth.php' );
			try{
				$hybridauth = new Hybrid_Auth( '/home/hammerandtongues/public_html/shopping/hybridauth/config.php' );
				$adapter = $hybridauth->authenticate( "Twitter" );
				//$user_profile = $adapter->getUserProfile();
			  	$usr_tw_info = $adapter->api()->get('account/verify_credentials.json');				
				$tw_userlogin = $usr_tw_info->screen_name;
				$tw_username = $usr_tw_info->name;
				$tw_usercity = strstr($usr_tw_info->location, ' ', true);
				/* Registration Process */
				$user_id = username_exists($tw_userlogin);
				if ( !$user_id ) {
					$user_pass = wp_generate_password( 12, false );
					$user_id = wp_create_user($tw_userlogin, $user_pass);
					if ( !is_wp_error( $user_id ) && wl_programmatic_login($tw_userlogin) ) {
						// add/update user meta fields
						$tm_reg = date('Y-m-d H:i:s', current_time( 'timestamp', 0 ));
						wp_update_user( array( 'ID' => $user_id, 'display_name' => $tw_username, 'first_name' => $tw_username, 'user_registered' => $tm_reg ) );
						update_user_meta( $user_id, 'pw_user_status', 'approved' );
						
						// create same user in auction site
						$mysqli = new mysqli("localhost", "root", "16743598", "hammeran_aucdb");
						if (mysqli_connect_error()) {
							die('Could not connect to auction site. Please contact administrator. Connect Error (' . mysqli_connect_errno() . ') '. mysqli_connect_error());
						} else {
							$login_qry = $mysqli->query("SELECT ID FROM hammeran_aucdb.ham_users WHERE user_login='$tw_userlogin'");	
							if($login_qry->num_rows) {			
								$mysqli->close();
							} else {
								$qry = "INSERT INTO hammeran_aucdb.ham_users (user_login, user_pass, user_nicename, user_registered, user_status, display_name) VALUES ('$tw_userlogin', '$user_pass', '$tw_userlogin', '$tm_reg', 0, '$tw_username')";
								$mysqli->query($qry);
								$auc_usr_id = $mysqli->insert_id;
								
								$qry_1 = "INSERT INTO hammeran_aucdb.ham_usermeta (user_id, meta_key, meta_value) VALUES ($auc_usr_id, 'ham_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}')";
								$mysqli->query($qry_1);
								
								$qry_2 = "INSERT INTO hammeran_aucdb.ham_usermeta (user_id, meta_key, meta_value) VALUES ($auc_usr_id, 'ham_user_level', 0)";
								$mysqli->query($qry_2);

								$qry_3 = "INSERT INTO hammeran_aucdb.ham_usermeta (user_id, meta_key, meta_value) VALUES ($auc_usr_id, 'pw_user_status', 'approved')";
								$mysqli->query($qry_3);

								$qry_4 = "INSERT INTO hammeran_aucdb.ham_usermeta (user_id, meta_key, meta_value) VALUES ($auc_usr_id, 'first_name', '$tw_username')";
								$mysqli->query($qry_4);
								
								$mysqli->close();
								unset($mysqli);
							}
						}
						// Flush API object and other variables after authentication
						$hybridauth->logoutAllProviders();
						$adapter->logout();
						unset($hybridauth);
						unset($adapter);
						if(!session_id()) {
							ob_start(); 		
							session_start();
						}
						$_SESSION['buyer_agree_tandc'] = "sw";
						$redirect_url = Walleto_my_account_link();
						wp_redirect( $redirect_url ); 
						die();						
					} else {
						$hybridauth->logoutAllProviders();
						$adapter->logout();
						unset($hybridauth);
						unset($adapter);					
						$redirect_url = add_query_arg( array( 'login' => 'failed' ), home_url() );
						wp_redirect( $redirect_url ); die();					
					}
				} else {
					$wl_user = get_user_by('login', $tw_userlogin);
					if($wl_user) {
						if(wl_programmatic_login($wl_user->user_login)) {
							if(!session_id()) {
								ob_start(); 		
								session_start();
							}
							$_SESSION['buyer_agree_tandc'] = "sw";
							$hybridauth->logoutAllProviders();
							$adapter->logout();
							unset($hybridauth);
							unset($adapter);
							$redirect_url = Walleto_my_account_link();
							wp_redirect( $redirect_url ); 
							die();
						} else {
							$hybridauth->logoutAllProviders();
							$adapter->logout();
							unset($hybridauth);
							unset($adapter);
							$redirect_url = add_query_arg( array( 'login' => 'failed' ), home_url() );
							wp_redirect( $redirect_url ); die();
						}
					} else {
						$hybridauth->logoutAllProviders();
						$adapter->logout();
						unset($hybridauth);
						unset($adapter);
						$redirect_url = add_query_arg( array( 'login' => 'failed' ), home_url() );
						wp_redirect( $redirect_url ); die();						
					}					
				}				
			}
			catch( Exception $e ){
				die( "<b>got an error!</b> " . $e->getMessage() ); 
			}
		}
	endif;	
	
	if(isset($_POST['continue_shopping_me']))
	{
		wp_redirect(get_bloginfo('siteurl'));
		die();	
	}
	
	if(isset($_POST['go_back_to_my_shopping_cart_me']))
	{
		wp_redirect(get_permalink(get_option('Walleto_shopping_cart_page_id')));
		die();	
	}
	if(isset($_POST['set_delivery_me']))
	{
		wp_redirect(get_permalink(1700));
		die();	
	}
	if(isset($_POST['cmn_inf']) && !empty($_POST['cmnbskt_nonce'])) {
		if( wp_verify_nonce($_POST['cmnbskt_nonce'], 'wl_cmn_bskt_pro')) {
			global $current_user;
			get_currentuserinfo();
			$uid = $current_user->ID;		
			if(!session_id()) {
				ob_start(); 		
				session_start();
			}
			//$cart = $_COOKIE['my_cart'];
			//$cart = stripslashes($cart);
			//$cart = unserialize($cart);
			//$cart = $cart['my_cart'];
			$cart = $_SESSION['cart_items'];
			$cmn_pros = "";
			$exists_cmn_pros = get_user_meta($uid, "cmn_bskt_pros", true);
			if(is_array($cart) and count($cart) > 0)
			{
				foreach($cart as $item)
				{	
					$cmn_pros .= $item['pid'].",";
				}
			}
			$cmn_pros = trim($cmn_pros, ",");
			if(!empty($exists_cmn_pros)) {
				update_user_meta($uid, 'cmn_bskt_pros', $exists_cmn_pros.",".$cmn_pros);
			} else {
				update_user_meta($uid, 'cmn_bskt_pros', $cmn_pros);
			}
		}
		wp_redirect(get_permalink(1700));
		die();		
	}	
	if(isset($_POST['set_pickup_me']))
	{
		wp_redirect(get_permalink(5836));
		die();	
	}	
	/*techinfini*/
	
	if($w_action == 'user_profile')
	{
		include 'lib/user_profile.php';
		die();
	}
	
	if($w_action == 'edit_product')
	{
		include 'lib/my_account/edit_product.php';
		die();
	}
	
	if($w_action == 'deposit_pay_alertpay')
	{
		include 'lib/gateways/deposit_pay_alertpay.php';
		die();
	}
	
	if($w_action == 'mark_shipped')
	{
		include 'lib/my_account/mark_shipped.php';
		die();
	}
	
	if($w_action == 'delete_product')
	{
		include 'lib/my_account/delete_product.php';
		die();
	}
	
	if($w_action == 'purchase_mem_paypal')
	{
		include 'lib/gateways/purchase_mem_paypal.php';
		die();
	}
	
	if($w_action == 'purchase_mem_skrill')
	{
		include 'lib/gateways/purchase_mem_skrill.php';
		die();
	}
	
	if($w_action == 'skrill_mem_response')
	{
		include 'lib/gateways/skrill_mem_response.php';
		die();
	}
	
	
	
	if($w_action == 'pause_selling')
	{
		include 'lib/my_account/pause_selling.php';
		die();
	}
	
	if($w_action == 'activate_selling')
	{
		include 'lib/my_account/activate_selling.php';
		die();
	}
	
	if($w_action == 'add_to_cart')
	{
 
		include 'lib/add_to_cart.php';
		die();
	}
	
	if($w_action == 'my_cart')
	{
		include 'lib/my_cart.php';
		die();
	}
	
	
}

function walleto_get_variance_type_on_id($id)
{
	global $wpdb;
	$s = "select * from ".$wpdb->prefix."walleto_variations_content where id='$id'";
	$r = $wpdb->get_results($s);
	 
	return $r[0];	
}

function walleto_get_quant_of_pid_and_variance($pid, $variation_string)
{
	global $wpdb;
	
	$s1 = "select * from ".$wpdb->prefix."walleto_variations_content where pid='$pid' AND variation_string='$variation_string'";
	$r1 = $wpdb->get_results($s1);	
	
	if(count($r1) > 0)
	{
		return $r1[0]->quant;	
	}
	
	return 0;
}

function walleto_get_variation_name_from_string($variation_string, $sep = ',')
{
	$str = '';
	
	$variation_string_arr = explode("_", $variation_string);
	foreach($variation_string_arr as $ids)
	{
		if(!empty($ids))
		{
			$tax = walleto_get_tax_for_term($ids);
			$term_main = get_term_by('id',$ids, $tax);
			$ProjectTheme_get_product_variance = ProjectTheme_get_product_variance($tax);
				
			$str .= $ProjectTheme_get_product_variance->name.': '.$term_main->name.$sep.' ';				
		}
	}	
	
	return $str;
}

function walleto_get_tax_for_term($term_id)
{
	global $wpdb;
	$g1 = "select * from ".$wpdb->prefix."term_taxonomy where term_id='$term_id'";
	$g2 = $wpdb->get_results($g1);	
	
	if(count($g2) > 0)
	return $g2[0]->taxonomy;
	
	return "false_tax_non_existent";
}

//******************************************************
//
//	Shipping Calculator
//
//******************************************************

function walleto_get_order_shipping($oid)
{
	
}


function walleto_get_order_shipping_based_on_seller($oid, $seller_id, $buyer_id)
{
	global $wpdb;
	$s = "select contents.* from ".$wpdb->prefix."walleto_order_contents contents, ".$wpdb->prefix."posts posts where 
	contents.orderid='$oid' AND contents.pid=posts.ID AND posts.post_author='$seller_id' AND contents.uid='$buyer_id'";	
	$r = $wpdb->get_results($s);
	$weight = 0;
	 
	if(count($r) > 0)
	{
		foreach($r as $row)
		{
			$pid = $row->pid;
			$weight += get_post_meta($pid,'weight',true);
		}		
		
	}
	else return 0;
	
}

/*****************************************************************************
*
*	Function - walleto -
*
*****************************************************************************/
function Walleto_get_browse__special_pg_link($page_id, $page)
{
	$using_perm = Walleto_using_permalinks();
	if($using_perm)	return get_permalink(get_option($page_id)). "?pj=" . $page ;
			else return get_bloginfo('siteurl'). "/?page_id=". get_option($page_id). "&pj=" . $page ;		
	
}

function walleto_sm_replace_me($s)
{
	return urlencode($s);
}
/*****************************************************************************
*
*	Function - walleto -
*
*****************************************************************************/
function walleto_curPageURL_me() {
	 $pageURL = 'http';
	 if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
	 $pageURL .= "://";
	 if ($_SERVER["SERVER_PORT"] != "80") {
	  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
	 } else {
	  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
	 }
	 return $pageURL;
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_curPageURL() {
 $pageURL = 'http';
 if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
 $pageURL .= "://";
 if ($_SERVER["SERVER_PORT"] != "80") {
  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 } else {
  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 }
 return $pageURL;
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_add_query_vars($public_query_vars) 
{  
    	$public_query_vars[] = 'jb_action';
		$public_query_vars[] = 'w_action'; 
		$public_query_vars[] = 'orderid';
		$public_query_vars[] = 'bid_id';
		 
		$public_query_vars[] = 'step'; 
		$public_query_vars[] = 'my_second_page';
		$public_query_vars[] = 'third_page';
		$public_query_vars[] = 'username';
		$public_query_vars[] = 'pid';
		$public_query_vars[] = 'term_search';		//job_sort, job_category, page
		$public_query_vars[] = 'method';
		$public_query_vars[] = 'post_author';
		$public_query_vars[] = 'page';
		$public_query_vars[] = 'rid';
		$public_query_vars[] = 'ids';
		$public_query_vars[] = 'pagem';
		
    	return $public_query_vars;  
}

function Walleto_get_adv_search_pagination_link($pg)
{
	$page_id = get_option('Walleto_adv_search_id');
	
	$using_perm = Walleto_using_permalinks();
	if($using_perm)	$ssk = get_permalink(($page_id)). "?pj=" . $pg ;
	else $ssk = get_bloginfo('siteurl'). "/?page_id=". ($page_id). "&pj=" . $pg ;		
	
	$trif = '';
	foreach($_GET as $key=>$value)
	{
		if($key != "pj" and $key != 'page_id' and $key != "custom_field_id")
		$trif .= '&'.$key."=".$value;
	}
	
	if(is_array($_GET['custom_field_id']))
	foreach($_GET['custom_field_id'] as $values)
	$trif .= "&custom_field_id[]=".$values;
	
	return $ssk.$trif;
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function walleto_get_times_bough_product($pid)
{
	global $wpdb;
	$s = "select count(id) cnts from ".$wpdb->prefix."walleto_order_contents where pid='$pid'";
	$r = $wpdb->get_results($s);
	$row = $r[0];
	
	return $row->cnts;
		
}

function walleto_active_products_get_product()
{
	$pid = get_the_ID();
	$status = get_post_meta($pid,'status',true);
	global $post;
	$st = $post->post_status;
	
	
	?>
    
    	<div class="post" id="post-ID-<?php the_ID(); ?>">
    		<div class="image_holder">
            	<a href="<?php the_permalink(); ?>"><?php echo walleto_get_first_post_image(get_the_ID(), 75, 75, 'attachment-75x75', 'small-image-post', 1); ?></a>
            </div>
            
            <div class="details_holder">
            	<div class="title_holder">
            	<h2><a class="my-title-post" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
            		
                    <p class="mypostedon"><?php echo sprintf(__("Posted on %s by <a href='%s'>%s</a>",'Walleto'), get_the_time('F jS, Y'), $lnk, get_the_author()) ;?> <br/>
                        <?php echo sprintf(__("Posted in %s","Walleto"), get_the_term_list( get_the_ID(), 'product_cat', '', ', ', '' )); ?> </p>
                        
                        
                       
            	
                </div>
                
                <div class="details_holder_inner1">
                	<ul class="inner_details_1">
                    	<li>
                        <h3><?php _e('Quantity','Walleto'); ?></h3>
                        <p><?php echo get_post_meta($pid,'quant',true); ?></p>
                        </li>
                        
                        <li>
                        <h3><?php _e('Was bought','Walleto'); ?></h3>
                        <p><?php
                        
						$times_bought = walleto_get_times_bough_product($pid);
						echo sprintf(__("%s times","Walleto"), $times_bought);
						
						?></p>
                        </li>
                        
                         <li>
                        <h3><?php _e('Status','Walleto'); ?></h3>
                        <p><?php echo ($status != "paused" ? __('Active','Walleto') : __('Paused','Walleto')); ?></p>
                        </li>
                    </ul>
                </div>
                
                <div class="details_holder_inner2">
                	<p class="price_me1"><?php
                    	
						$prc = walleto_get_show_price(walleto_get_product_price(get_the_ID()));
						echo sprintf(__('Price: %s','Walleto'), $prc);
					
					?></p>
                </div>
                
                <div class="mybtns">
                <?php
				
					if($st == "draft"):
					
						echo '<em>';
						_e('Your product is awaiting admin moderation.','Walleto');
						echo '</em>';
						
						?>
                         <a href="<?php bloginfo('siteurl') ?>/?w_action=delete_product&pid=<?php the_ID(); ?>" class="post_bid_btn_err"><?php echo __("Delete Product", "Walleto");?></a>
                        <?php
						
					else:
				?>
                
                
                
                 <!-- ######## -->
                        <a href="<?php the_permalink() ?>" class="post_bid_btn"><?php echo __("Read More", "Walleto");?></a> 
                        <a href="<?php bloginfo('siteurl') ?>/?w_action=edit_product&pid=<?php the_ID(); ?>" class="post_bid_btn"><?php echo __("Edit Product", "Walleto");?></a> 
                        <?php
                        
							if($status != "paused"):
						
						?>
                        <a href="<?php bloginfo('siteurl') ?>/?w_action=pause_selling&pid=<?php the_ID(); ?>" class="post_bid_btn"><?php echo __("Pause Selling", "Walleto");?></a>
                        
                        <?php
							else:
						?>                         
                         
                        <a href="<?php bloginfo('siteurl') ?>/?w_action=activate_selling&pid=<?php the_ID(); ?>" class="post_bid_btn"><?php echo __("Activate Selling", "Walleto");?></a>
                        
                        <?php endif; ?>
                         
                        <a href="<?php bloginfo('siteurl') ?>/?w_action=delete_product&pid=<?php the_ID(); ?>" class="post_bid_btn_err"><?php echo __("Delete Product", "Walleto");?></a>
                        
                        <?php endif; ?>
                        <!-- ########### -->
                   </div>     
                
                
            
            </div>
    	
        
        </div>
        
    <?php	
	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_get_avatar($uid, $w = 25, $h = 25)
{
	$av = get_user_meta($uid, 'avatar_new', true);
	if(empty($av)) return get_bloginfo('template_url')."/images/noav.jpg";
	else return walleto_wp_get_attachment_image($av, array($w, $h));  
}
 /*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_get_unread_number_messages($uid)
{
	global $wpdb;
	$s = "select * from ".$wpdb->prefix."walleto_pm where user='$uid' and show_to_destination='1' and rd='0'";
				$r = $wpdb->get_results($s);	
				return count($r);
}
	 
 /*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_get_payments_page_url($subpage = '', $id = '')
{
	$opt = get_option('Walleto_my_account_my_finances_page_id');
	if(empty($subpage)) $subpage = "home";
	
	$perm = Walleto_using_permalinks();
	
	if($perm) return get_permalink($opt). "?pg=".$subpage.(!empty($id) ? "&id=".$id : '');
	
	return get_permalink($opt). "&pg=".$subpage.(!empty($id) ? "&id=".$id : '');
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_my_shops_columns($columns) //this function display the columns headings
{

	//$columns["ending" ] 	= __("Membership Expires","Walleto");
	$columns["feat" ] 		= __("Featured","Walleto");
	$columns["thumbnail"] 	= __("Thumbnail","Walleto");
 	$columns["shop_seller"]	= __("Seller","Walleto");
	return $columns;
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_my_products_columns($columns) //this function display the columns headings
{
	unset($columns["author"]);
	unset($columns["comments"]);
	unset($columns["tags"]);		
	$columns["price" ] 		= __("Price","Walleto");
	$columns["feat" ] 		= __("Featured","Walleto");
	$columns["thumbnail"] 	= __("Thumbnail","Walleto"); 
	return $columns;
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_my_custom_columns($column)
{
	global $post;

	//Spidanet adds unique column
	if ("ID" == $column) echo $post->ID; //displays title

	if ("thumbnail" == $column) 
	{
		echo '<a href="'.get_bloginfo('siteurl').'/wp-admin/post.php?post='.$post->ID.'&action=edit">'.walleto_get_first_post_image($post->ID,75,65).'</a>'; //shows up our post thumbnail that we previously created.
	}
	
	elseif ("feat" == $column)
	{
		$f = get_post_meta($post->ID,'featured', true);	
		if($f == "1") echo __("Yes","Walleto");
		else  echo __("No","Walleto");
	}
	
	elseif ("price" == $column)
	{	
		echo walleto_get_show_price(walleto_get_product_price($post->ID));
	}
	
	elseif ("item_seller" == $column)
	{	
		$seller_info = get_user_by( 'id', $post->post_author );
		echo "<input type='hidden' id='$post->ID-shporigsel' val='$post->post_author'>".$seller_info->first_name." ".$seller_info->last_name;
	}	
	
	if ("shop_seller" == $column)
	{
		$seller_info = get_user_by( 'id', $post->post_author );
		echo $seller_info->first_name." ".$seller_info->last_name;
	}	
	
	elseif ("ending" == $column)
	{	
		$dt = current_time('timestamp',0);
		$membership_available = get_post_meta($post->ID,'membership_available', true);
		
		if($dt > $membership_available) echo __('Expired','Walleto'); else 
		echo date_i18n('d-M-Y H:i:s', $membership_available);	
	}
	
	elseif("itm_avail" == $column)
	{
		$itm_stk = get_post_meta($post->ID,'quant',true);
		if(!empty($itm_stk) && $itm_stk > 0) {
			echo __("Available","Walleto");
		} else {
			echo __("Out of Stock","Walleto");
		}
	}
}
 /*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function walleto_get_product_price($pid)
{
	return get_post_meta($pid,'price',true);		
}



/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_get_total_nr_of_product()
{
	$query = new WP_Query( "post_type=product&posts_per_page=1" );	
	return $query->found_posts;
}
/*************************************************************
*
*	Walleto (c) sitemile.com - function
*
**************************************************************/
function Walleto_get_total_nr_of_open_product()
{
	$query = new WP_Query( "meta_key=closed&meta_value=0&post_type=product&order=DESC&orderby=id&posts_per_page=1&paged=1" );	
	return $query->found_posts;
}
/*************************************************************
*
*	Walleto (c) sitemile.com - function
*
**************************************************************/
function Walleto_get_total_nr_of_closed_product()
{
	$query = new WP_Query( "meta_key=closed&meta_value=1&post_type=product&order=DESC&orderby=id&posts_per_page=1&paged=1" );	
	return $query->found_posts;
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function Walleto_get_option_drop_down($arr, $name)
{
	$opts = get_option($name);
	$r = '<select name="'.$name.'">';
	foreach ($arr as $key => $value)
	{
		$r .= '<option value="'.$key.'" '.($opts == $key ? ' selected="selected" ' : "" ).'>'.$value.'</option>';		
		
	}
    return $r.'</select>'; 
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_add_theme_styles()  
{ 
	global $wp_query;
  	$new_auction_step = $wp_query->query_vars['step'];
    $w_action			= $wp_query->query_vars['w_action'];
	
	
	
  	wp_register_style( 'bx_styles', get_bloginfo('template_url').'/css/bx_styles.css', array(), '', 'all' );
	//wp_register_script( 'social_pr', get_bloginfo('template_url').'/js/connect.js');
	
	
	wp_register_script( 'easing', get_bloginfo('template_url').'/js/jquery.easing.1.3.js');
	wp_register_script( 'bx_slider', get_bloginfo('template_url').'/js/jquery.bxSlider.min.js');
	//wp_register_script( 'jquery_cowntdown', get_bloginfo('template_url').'/js/jquery.countdown.js');
	wp_register_script( 'bootstrap_min', get_bloginfo('template_url').'/js/bootstrap.min.js');
	
	
	wp_register_style( 'bootstrap_style1', get_bloginfo('template_url').'/css/bootstrap_min.css', array(), '', 'all' );
  	wp_register_style( 'bootstrap_style2', get_bloginfo('template_url').'/css/css.css', array(), '', 'all' );
	wp_register_style( 'bootstrap_style3', get_bloginfo('template_url').'/css/bootstrap_responsive.css', array(), '', 'all' );
	wp_register_style( 'bootstrap_ie6', 	get_bloginfo('template_url').'/css/bootstrap_ie6.css', array(), '', 'all' );
	wp_register_style( 'bootstrap_gal', 	get_bloginfo('template_url').'/css/bootstrap_gal.css', array(), '', 'all' );
	wp_register_style( 'fileupload_ui', 	get_bloginfo('template_url').'/css/jquery.fileupload-ui.css', array(), '', 'all' );
	wp_register_style( 'uploadify_css', 	get_bloginfo('template_url').'/lib/uploadify/uploadify.css', array(), '', 'all' );
	wp_register_style( 'responsive_css', get_bloginfo('template_url').'/css/responsive.css', array(), time(), 'all');
	wp_register_style( 'meanmenu', get_bloginfo('template_url').'/css/meanmenu.css', array(), time(), 'all');
	wp_register_style( 'responsive-tables', get_bloginfo('template_url').'/css/tablesaw.css', array(), time(), 'all');
	wp_register_style( 'font_awesome_css', 'https://netdna.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css' );
	
	wp_register_script( 'html5_js', get_bloginfo('template_url').'/js/html5.js');
	wp_register_script( 'jquery_ui', get_bloginfo('template_url').'/js/vendor/jquery.ui.widget.js');
	wp_register_script( 'templ_min', get_bloginfo('template_url').'/js/templ.min.js');
	wp_register_script( 'load_image', get_bloginfo('template_url').'/js/load_image.min.js');
	wp_register_script( 'canvas_to_blob', get_bloginfo('template_url').'/js/canvas_to_blob.js');
	wp_register_script( 'iframe_transport', get_bloginfo('template_url').'/js/jquery.iframe-transport.js');
	wp_register_script( 'load_image', get_bloginfo('template_url').'/js/load_image.js');
	
	
	wp_register_style( 'fileupload_ui', 	get_bloginfo('template_url').'/css/fileupload_ui.css', array(), '', 'all' );
	wp_register_script( 'fileupload_main', get_bloginfo('template_url').'/js/jquery.fileupload.js');
	wp_register_script( 'fileupload_fp', get_bloginfo('template_url').'/js/jquery.fileupload-fp.js');
	wp_register_script( 'fileupload_ui', get_bloginfo('template_url').'/js/jquery.fileupload-ui.js');
	
	wp_register_script( 'locale_thing', get_bloginfo('template_url').'/js/locale.js');
	
	wp_register_script( 'main_thing', get_bloginfo('template_url').'/js/main.js');
	wp_register_script( 'js_cors_ie8', get_bloginfo('template_url').'/js/cors/jquery.xdr-transport.js');
	wp_register_script( 'jquery16', get_bloginfo('template_url').'/js/jquery16.js');
	wp_enqueue_script( 'megamenu', get_bloginfo('template_url') . '/js/jetmenu.js', array('jquery') );
	wp_enqueue_script( 'tablesaw_responsive', get_bloginfo('template_url') . '/js/tablesaw.js', array('jquery') );
	wp_enqueue_script( 'tablesaw_responsive' );
	wp_enqueue_script( 'megamenu' );
	
	//wp_deregister_script('jquery');
	//wp_register_script( 'jquery', get_bloginfo('template_url').'/js/jquery19.js');
	wp_register_script( 'my_scripts', get_bloginfo('template_url').'/js/my-script.js');
	wp_register_script( 'jquery_ui_min', get_bloginfo('template_url').'/js/jquery.ui.min.js');
 	wp_enqueue_script( 'dcjqmegamenu', get_bloginfo('template_url') . '/js/jquery.dcmegamenu.1.3.4.min.js', array('jquery') );
	wp_register_style( 'mega_menu_thing', 	get_bloginfo('template_url').'/css/menu.css', array(), '', 'all' );
 	
	wp_enqueue_script( 'jqueryhoverintent', get_bloginfo('template_url') . '/js/jquery.hoverIntent.minified.js', array('jquery') );
	
	global $wp_styles, $wp_scripts;
	// enqueing:
  	 	 wp_enqueue_script( 'jqueryhoverintent' );
		 wp_enqueue_style( 'bx_styles' );
		 wp_enqueue_script( 'social_pr' );
		 wp_enqueue_script( 'easing' );
		 wp_enqueue_script( 'bx_slider' );
		 wp_enqueue_script( 'jquery_cowntdown' );
		 wp_enqueue_script( 'dcjqmegamenu' );
		wp_enqueue_style( 'mega_menu_thing' );
		wp_enqueue_style('responsive_css');
		#wp_enqueue_style('meanmenu');
		wp_enqueue_style('responsive-tables');
		wp_enqueue_style('font_awesome_css');
		#wp_enqueue_script( 'meanmenu_script', get_bloginfo('template_url') . '/js/jquery.meanmenu.js', array('jquery') );
		
		
		if($new_auction_step == "2" or $new_auction_step == "1" or $w_action == "edit_product"  ):
		 
		 //wp_enqueue_script( 'jquery16' );
		 wp_enqueue_script( 'jquery_ui_min');
 
		
		 	  	// enqueing:
	  	if($new_auction_step == "2" or $w_action == "edit_product" )
		wp_enqueue_style( 'bootstrap_style1' );
	 	//wp_enqueue_style( 'bootstrap_style2' );
		//wp_enqueue_style( 'bootstrap_style3' );
		//wp_enqueue_style( 'bootstrap_ie6' );
		//wp_enqueue_style( 'bootstrap_gal' );
		wp_enqueue_style( 'fileupload_ui' );
		wp_enqueue_style( 'uploadify_css' );
		
		wp_enqueue_script( 'html5_js' );


		 
		 
		$uploaders = walleto_get_uploaders_tp();
		
		if($uploaders == "jquery")
		{
			wp_enqueue_script( 'jquery_ui' );
			wp_enqueue_script( 'templ_min' );
			wp_enqueue_script( 'load_image' );
			wp_enqueue_script( 'bootstrap_min' );
			wp_enqueue_script( 'canvas_to_blob' );
			wp_enqueue_script( 'iframe_transport' );
			wp_enqueue_script( 'fileupload_main' );
			wp_enqueue_script( 'fileupload_fp' );
			wp_enqueue_script( 'fileupload_ui' );
			wp_enqueue_script( 'main_thing' );
			wp_enqueue_script( 'js_cors_ie8' );
			
		}
		
		 wp_enqueue_script( 'locale_thing' );
		 wp_enqueue_script( 'uploadify_js' );
	 
	//$wp_styles->add_data('bootstrap_ie6', 'conditional', 'lte IE 7');
		else:
		
			//wp_enqueue_script('jquery');
			wp_enqueue_script('my_scripts');
		
		endif;
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function get_product_category_fields($catid, $pid = '')
{
	global $wpdb;
	$s = "select * from ".$wpdb->prefix."walleto_custom_fields order by ordr asc";	
	$r = $wpdb->get_results($s);
	
	$arr1 = array(); $i = 0;
	
	foreach($r as $row)
	{
		$ims 	= $row->id;
		$name 	= $row->name;
		$tp 	= $row->tp;
		
		if($row->cate == 'all')
		{ 
			$arr1[$i]['id'] 	= $ims; 
			$arr1[$i]['name'] 	= $name; 
			$arr1[$i]['tp'] 	= $tp; 
			$i++; 
		
		}
		else
		{
			$se = "select * from ".$wpdb->prefix."walleto_custom_relations where custid='$ims'";
			$re = $wpdb->get_results($se);
			
			if(count($re) > 0)
			foreach($re as $rowe) // = mysql_fetch_object($re))
			{
				if(count($catid) > 0)
				foreach($catid as $id_of_cat)
				{
				
					if($rowe->catid == $id_of_cat)
					{
						$flag_me = 1;
						for($k=0;$k<count($arr1);$k++)
						{
							if(	$arr1[$k]['id'] 	== $ims	) {  $flag_me = 0; break; }						
						}
						
						if($flag_me == 1)
						{
							$arr1[$i]['id'] 	= $ims; 
							$arr1[$i]['name'] 	= $name; 
							$arr1[$i]['tp'] 	= $tp;
							$i++;
						}
					}
				}
			}
		}
	}

	$arr = array();
	$i = 0;
	
	for($j=0;$j<count($arr1);$j++)
	{
		$ids 	= $arr1[$j]['id'];
		$tp 	= $arr1[$j]['tp'];
		
		$arr[$i]['field_name']  = $arr1[$j]['name'];
		$arr[$i]['id']  = '<input type="hidden" value="'.$ids.'" name="custom_field_id[]" />';
		
		if($tp == 1) 
		{
		
		$teka 	= !empty($pid) ? get_post_meta($pid, 'custom_field_ID_'.$ids, true) : "" ;
		
		$arr[$i]['value']  = '<input class="do_input" type="text" size="30" name="custom_field_value_'.$ids.'" 
		value="'.(isset($_POST['custom_field_value_'.$ids]) ? $_POST['custom_field_value_'.$ids] : $teka ).'" />';
		
		}
		
		if($tp == 5)
		{
		
			$teka 	= !empty($pid) ? get_post_meta($pid, 'custom_field_ID_'.$ids, true) : "" ;
			$teka 	= $teka[0];
			$value 	= isset($_POST['custom_field_value_'.$ids]) ? $_POST['custom_field_value_'.$ids] : $teka;
			
			$arr[$i]['value']  = '<textarea rows="5" cols="40" name="custom_field_value_'.$ids.'">'.$value.'</textarea>';
		
		}
		
		if($tp == 3) //radio
		{
			$arr[$i]['value']  = '';
			
				$s2 = "select * from ".$wpdb->prefix."walleto_custom_options where custid='$ids' order by ordr ASC ";
				$r2 = $wpdb->get_results($s2);
				
				if(count($r2) > 0)
				foreach($r2 as $row2) // = mysql_fetch_object($r2))
				{
					$teka 	= !empty($pid) ? get_post_meta($pid, 'custom_field_ID_'.$ids, true) : "" ;
					$teka 	= $teka[0];
					
					if(isset($_POST['custom_field_value_'.$ids]))
					{
						if($_POST['custom_field_value_'.$ids] == $row2->valval) $value = 'checked="checked"';
						else $value = '';
					}
					elseif(!empty($pid))
					{
						$v = get_post_meta($pid, 'custom_field_ID_'.$ids, true);
						if($v == $row2->valval) $value = 'checked="checked"';
						else $value = ''; 
					
					}				
					else $value = '';
					
					$arr[$i]['value']  .= '<input type="radio" '.$value.' value="'.$row2->valval.'" name="custom_field_value_'.$ids.'"> '.$row2->valval.'<br/>';
				}
		}
		
		
		if($tp == 4) //checkbox
		{
			$arr[$i]['value']  = '';
			
				$s2 = "select * from ".$wpdb->prefix."walleto_custom_options where custid='$ids' order by ordr ASC ";
				$r2 = $wpdb->get_results($s2);
				
				if(count($r2) > 0)
				foreach($r2 as $row2) // = mysql_fetch_object($r2))
				{
					$teka 		= !empty($pid) ? get_post_meta($pid, 'custom_field_ID_'.$ids) : "" ;
					//$teka 		= $teka[0];
					$teka_ch 	= '';
					
					if(is_array($teka))
					{	
						foreach($teka as $te)
						{
							
							if(trim($te) == trim($row2->valval)) { $teka_ch = "checked='checked'";  break; }
						}	
								
					}
					elseif($row2->valval == $teka) $teka_ch = "checked='checked'";
					else $teka_ch = '';
					
					$teka_ch 	= isset($_POST['custom_field_value_'.$ids]) ? "checked='checked'" : $teka_ch;
					
					$arr[$i]['value']  .= '<input type="checkbox" '.$teka_ch.' value="'.$row2->valval.'" name="custom_field_value_'.$ids.'[]"> '.$row2->valval.'<br/>';
				}
		}
		
		if($tp == 2) //select
		{
			$arr[$i]['value']  = '<select class="do_input" name="custom_field_value_'.$ids.'" /><option value="">'.__('Select','Walleto').'</option>';
			
				$s2 = "select * from ".$wpdb->prefix."walleto_custom_options where custid='$ids' order by ordr ASC ";
				$r2 = $wpdb->get_results($s2);
				
				if(count($r2) > 0)
				foreach($r2 as $row2) // = mysql_fetch_object($r2))
				{
					$teka 	= !empty($pid) ? get_post_meta($pid, 'custom_field_ID_'.$ids) : "" ;

					if(!empty($teka))
					{	
						foreach($teka as $te)
						{
							if(trim($te) == trim($row2->valval)) { $teka = "selected='selected'"; break; }
						}	
						
								
					}
					else $teka = '';
					
					if(isset($_POST['custom_field_value_'.$ids]) && $_POST['custom_field_value_'.$ids] == $row2->valval)
					$value = "selected='selected'" ;
					else $value = $teka;
					
					
					$arr[$i]['value']  .= '<option '.$value.' value="'.$row2->valval.'">'.$row2->valval.'</option>';
				
				}
			$arr[$i]['value']  .= '</select>';
		}
		
		$i++;
	}
	
	return $arr;
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_get_custom_taxonomy_count($ptype,$pterm) {
	global $wpdb;
	
	$s = "select * from ".$wpdb->prefix."terms where slug='$pterm'";
	$r = $wpdb->get_results($s);
	$r = $r[0];
	
	$term_id = $r->term_id;
	

	
	//--------
	
	$s = "select * from ".$wpdb->prefix."term_taxonomy where term_id='$term_id'";
	$r = $wpdb->get_results($s);
	$r = $r[0];
	
	$term_taxonomy_id = $r->term_taxonomy_id;

	
	//--------
	
	$s = "select distinct posts.ID from ".$wpdb->prefix."term_relationships rel, $wpdb->postmeta wpostmeta, $wpdb->posts posts 
	 where rel.term_taxonomy_id='$term_taxonomy_id' AND rel.object_id = wpostmeta.post_id AND posts.ID = wpostmeta.post_id AND posts.post_status = 'publish' AND posts.post_type = 'product' AND wpostmeta.meta_key = 'closed' AND wpostmeta.meta_value = '0'";
	$r = $wpdb->get_results($s);
	

	
	return count($r);
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_admin_main_head_scr()
{	
 	wp_enqueue_script("jquery-ui-core");
	wp_enqueue_script("jquery-ui-widget");
	wp_enqueue_script("jquery-ui-mouse");
	wp_enqueue_script("jquery-ui-tabs");
	wp_enqueue_script("jquery-ui-datepicker");
	wp_enqueue_script("jquery-ui-slider");
	wp_enqueue_script("jquery-ui-dialog");	
	
?>	
	
    <!-- <script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script> -->
    
    <link rel="stylesheet" href="<?php echo get_bloginfo('template_url'); ?>/css/admin.css" type="text/css" />    
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/colorpicker.css" type="text/css" />
    <link rel="stylesheet" media="screen" type="text/css" href="<?php bloginfo('template_url'); ?>/css/layout.css" />
	<link type="text/css" href="<?php bloginfo('template_url'); ?>/css/jquery-ui-1.8.16.custom.css" rel="stylesheet" />	
	
    <link rel="stylesheet" media="all" type="text/css" href="<?php echo get_bloginfo('template_url'); ?>/css/ui-thing.css" />
	<!-- <script type="text/javascript" language="javascript" src="<?php #echo get_bloginfo('template_url'); ?>/js/jquery-ui-timepicker-addon.js"></script> -->
    
	<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/idtabs.js"></script>	
 
		
		<script type="text/javascript">
			
			var $ = jQuery;
		jQuery(document).ready(function() {		
  jQuery("#usual2 ul").idTabs("tabs1"); 
		});
		</script>
	

 

<?php	
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/ 
function walleto_get_view_grd()
{
	if(isset($_SESSION['view_tp']))	
	{
		if(	$_SESSION['view_tp'] == "grid") return "grid"; else return "normal";
	}
	return "normal";
	
} 
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_get_uploaders_tp()
{
	$Walleto_uploader_type = get_option('Walleto_uploader_type');
	if(empty($Walleto_uploader_type)) return "html";
	
	return $Walleto_uploader_type;
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_get_images_cost_extra($pid)
{
	$Walleto_charge_fees_for_images 	= get_option('Walleto_charge_fees_for_images');
	$Walleto_extra_image_charge			= get_option('Walleto_extra_image_charge');

		
	if($Walleto_charge_fees_for_images == "yes")
	{
		$Walleto_nr_of_free_images = get_option('Walleto_nr_of_free_images');
		if(empty($Walleto_nr_of_free_images)) $Walleto_nr_of_free_images = 1;	
		
		$Walleto_get_post_nr_of_images = Walleto_get_post_nr_of_images($pid);
		
		$nr_imgs = $Walleto_get_post_nr_of_images - $Walleto_nr_of_free_images;
		if($nr_imgs > 0)
		{
			return $nr_imgs*	$Walleto_extra_image_charge;
		}
		
	}
	
	return 0;
	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_get_item_primary_cat($pid)
{
	$product_cat = wp_get_object_terms($pid, 'product_cat');	
	if(is_array($product_cat))
	{
		return 	$product_cat[0]->term_id;
	}
	
	return 0;
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_get_post_nr_of_images($pid)
{
	
		//---------------------
		// build the exclude list
		$exclude = array();
		
		$args = array(
		'order'          => 'ASC',
		'post_type'      => 'attachment',
		'post_parent'    => $pid,
		'meta_key'		 => 'another_reserved1',
		'meta_value'	 => '1',
		'numberposts'    => -1,
		'post_status'    => null,
		);
		$attachments = get_posts($args);
		if ($attachments) {
			foreach ($attachments as $attachment) {
			$url = $attachment->ID;
			array_push($exclude, $url);
		}
		}
		
		//-----------------
	
	
		$arr = array();
		
		$args = array(
		'order'          => 'ASC',
		'orderby'        => 'post_date',
		'post_type'      => 'attachment',
		'post_parent'    => $pid,
		'exclude'    		=> $exclude,
		'post_mime_type' => 'image',
		'numberposts'    => -1,
		); $i = 0;
		
		$attachments = get_posts($args); 
		if ($attachments) {
		
			foreach ($attachments as $attachment) {
						
				$url = wp_get_attachment_url($attachment->ID);
				array_push($arr, $url);
			  
		}
			return count($arr);
		}
		return 0;
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_wp_get_attachment_image($attachment_id, $size = 'thumbnail', $icon = false, $attr = '') {

	$html = '';
	$image = wp_get_attachment_image_src($attachment_id, $size, $icon);
	if ( $image ) {
		list($src, $width, $height) = $image;
		$hwstring = image_hwstring($width, $height);
		if ( is_array($size) )
			$size = join('x', $size);
		$attachment =& get_post($attachment_id);
		$default_attr = array(
			'src'	=> $src,
			'class'	=> "attachment-$size",
			'alt'	=> trim(strip_tags( get_post_meta($attachment_id, '_wp_attachment_image_alt', true) )), // Use Alt field first
			'title'	=> trim(strip_tags( $attachment->post_title )),
		);
		if ( empty($default_attr['alt']) )
			$default_attr['alt'] = trim(strip_tags( $attachment->post_excerpt )); // If not, Use the Caption
		if ( empty($default_attr['alt']) )
			$default_attr['alt'] = trim(strip_tags( $attachment->post_title )); // Finally, use the title

		$attr = wp_parse_args($attr, $default_attr);
		$attr = apply_filters( 'wp_get_attachment_image_attributes', $attr, $attachment );
		$attr = array_map( 'esc_attr', $attr );
		$html = rtrim("<img $hwstring");
		 
		$html = $attr['src'];
	}

	return $html;
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function walleto_create_post_type() {
  
	global $products_url_thing, $product_thing_list, $shop_url_thing;
	
  $icn = get_bloginfo('template_url')."/images/prodicon.png";
  register_post_type( 'product',
    array(
      'labels' => array(
        'name' 			=> __( 'Products','Walleto' ),
        'singular_name' => __( 'Product','Walleto' ),
		'add_new' 		=> __('Add New Product','Walleto'),
		'new_item' 		=> __('New Product','Walleto'),
		'edit_item'		=> __('Edit Product','Walleto'),
		'add_new_item' 	=> __('Add New Product','Walleto'),
		'search_items' 	=> __('Search Products','Walleto'),),
		
      'public' => true,
	  'menu_position' => 5,
	  'register_meta_box_cb' => 'walleto_products_set_metaboxes',
	  'has_archive' => "product-list",
    	'rewrite' => array('slug'=> $products_url_thing."/%product_cat%",'with_front'=>false), 
		'supports' => array('title','editor','author','thumbnail','excerpt','comments'),
	  '_builtin' => false,
	  'menu_icon' => $icn,
	  'publicly_queryable' => true,
	  'hierarchical' => false 

    ));
	
	

	$icn = get_bloginfo('template_url')."/images/shopsicon.png";
  register_post_type( 'shop',
    array(
      'labels' => array(
        'name' 			=> __( 'Shops','Walleto' ),
        'singular_name' => __( 'Shop','Walleto' ),
		'add_new' 		=> __('Add New Shop','Walleto'),
		'new_item' 		=> __('New Shop','Walleto'),
		'edit_item'		=> __('Edit Shop','Walleto'),
		'add_new_item' 	=> __('Add New Shop','Walleto'),
		'search_items' 	=> __('Search Shops','Walleto'),),
		
      'public' => true,
	  'menu_position' => 5,
	  'register_meta_box_cb' => 'walleto_shops_set_metaboxes',
	  'has_archive' => "shop-list",
    	'rewrite' => true, 
		'supports' => array('title','editor'),
	  '_builtin' => false,
	  'menu_icon' => $icn,
	  'publicly_queryable' => true,
	  'hierarchical' => false 

    ));

  /*Creating FAQ post type*/
  $faqicn = get_bloginfo('template_url')."/images/faqicon.png";
  register_post_type( 'faq',
    array(
      'labels' => array(
        'name' 			=> __( 'FAQs','Walleto' ),
        'singular_name' => __( 'FAQ','Walleto' ),
		'add_new' 		=> __('Add New FAQ','Walleto'),
		'new_item' 		=> __('New FAQ','Walleto'),
		'edit_item'		=> __('Edit FAQ','Walleto'),
		'add_new_item' 	=> __('Add New FAQ','Walleto'),
		'search_items' 	=> __('Search FAQs','Walleto'),),
		
      'public' => true,
	  'menu_position' => 6,
	  'register_meta_box_cb' => 'walleto_products_set_metaboxes',
	  'has_archive' => "faq-list",
	  'supports' => array('title'),
	  '_builtin' => false,
	  'menu_icon' => $faqicn,
	  'publicly_queryable' => true,
	  'hierarchical' => false 

    ));


   /*Creating reason post type*/
  $faqicn = get_bloginfo('template_url')."/images/faqicon.png";
  register_post_type( 'reason',
    array(
      'labels' => array(
        'name' 			=> __( 'Reasons','Walleto' ),
        'singular_name' => __( 'Reason','Walleto' ),
		'add_new' 		=> __('Add New Reason','Walleto'),
		'new_item' 		=> __('New Reason','Walleto'),
		'edit_item'		=> __('Edit Reason','Walleto'),
		'add_new_item' 	=> __('Add New Reason','Walleto'),
		'search_items' 	=> __('Search Reasons','Walleto'),),
		
      'public' => true,
	  'menu_position' => 7,
	  'supports' => array('title'),
	  '_builtin' => false,
	  'menu_icon' => $faqicn,
	  'publicly_queryable' => true,
	  'hierarchical' => false
    ));

	
  
  global $category_url_link, $location_url_link;

	register_taxonomy( 'product_cat', array('product'), array( 'hierarchical' => true, 'label' => __('Product Categories','Walleto'), 'rewrite' => true, 'i_order_terms' => true ) );
	
	//register_taxonomy( 'shop_location', array('shop'), array( 'hierarchical' => true, 'label' => __('Shop Locations','Walleto'), 'rewrite' => true ) );
 
 	
	
	global $wpdb;
		
		$s = "select * from ".$wpdb->prefix."walleto_variations";
		$r = $wpdb->get_results($s);
		
		foreach($r as $row):
		
		$label = $row->name;
		$slug = $row->slug;
		$show_in_nav_menus = false;
		
		register_taxonomy( $slug, 'product',
				        array(
				            'hierarchical' 				=> true,
	            			 
				            'labels' => array(
				                    'name' 						=> $label,
				                    'singular_name' 			=> $label,
				                    'search_items' 				=> __( 'Search', 'Walleto') . ' ' . $label,
				                    'all_items' 				=> __( 'All', 'Walleto') . ' ' . $label,
				                    'parent_item' 				=> __( 'Parent', 'Walleto') . ' ' . $label,
				                    'parent_item_colon' 		=> __( 'Parent', 'Walleto') . ' ' . $label . ':',
				                    'edit_item' 				=> __( 'Edit', 'Walleto') . ' ' . $label,
				                    'update_item' 				=> __( 'Update', 'Walleto') . ' ' . $label,
				                    'add_new_item' 				=> __( 'Add New', 'Walleto') . ' ' . $label,
				                    'new_item_name' 			=> __( 'New', 'Walleto') . ' ' . $label
				            	),
				            'show_ui' 					=> true,
				            'query_var' 				=> true,				             
				            'show_in_nav_menus' 		=> $show_in_nav_menus,
				            'rewrite' 					=> array( 'slug' => $product_attribute_base . sanitize_title( $tax->attribute_name ), 'with_front' => false, 'hierarchical' => $hierarchical ),
				        )  
				    );
		
		endforeach;	
	
	
	
 
	add_post_type_support( 'product', 'author' );
	//add_post_type_support( 'product', 'custom-fields' );
	//register_taxonomy_for_object_type('post_tag', 'product');
	
	flush_rewrite_rules();

}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_get_categories($taxo, $selected = "", $include_empty_option = "", $ccc = "", $tt = '')
{
	$args = "orderby=name&order=ASC&hide_empty=0&parent=0";
	$terms = get_terms( $taxo, $args );
	
	$ret = '<select name="'.$taxo.'_cat" class="'.$ccc.'" id="'.$ccc.'" '.$tt.'>';
	if(!empty($include_empty_option)) $ret .= "<option value=''>".$include_empty_option."</option>";
	
	if(empty($selected)) $selected = -1;
	
	foreach ( $terms as $term )
	{
		$id = $term->term_id;
		
		$ret .= '<option '.($selected == $id ? "selected='selected'" : " " ).' value="'.$id.'">'.$term->name.'</option>';
		
		$args = "orderby=name&order=ASC&hide_empty=0&parent=".$id;
		$sub_terms = get_terms( $taxo, $args );	
		
		if($sub_terms)
		foreach ( $sub_terms as $sub_term )
		{
			$sub_id = $sub_term->term_id; 
			$ret .= '<option '.($selected == $sub_id ? "selected='selected'" : " " ).' value="'.$sub_id.'">&nbsp; &nbsp;|&nbsp;  '.$sub_term->name.'</option>';
			
			$args2 = "orderby=name&order=ASC&hide_empty=0&parent=".$sub_id;
			$sub_terms2 = get_terms( $taxo, $args2 );	
			
			if($sub_terms2)
			foreach ( $sub_terms2 as $sub_term2 )
			{
				$sub_id2 = $sub_term2->term_id; 
				$ret .= '<option '.($selected == $sub_id2 ? "selected='selected'" : " " ).' value="'.$sub_id2.'">&nbsp; &nbsp; &nbsp; &nbsp;|&nbsp; 
				 '.$sub_term2->name.'</option>';
				 
				 $args3 = "orderby=name&order=ASC&hide_empty=0&parent=".$sub_id2;
				 $sub_terms3 = get_terms( $taxo, $args3 );	
				 
				 if($sub_terms3)
				 foreach ( $sub_terms3 as $sub_term3 )
				{
					$sub_id3 = $sub_term3->term_id; 
					$ret .= '<option '.($selected == $sub_id3 ? "selected='selected'" : " " ).' value="'.$sub_id3.'">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;|&nbsp; 
					 '.$sub_term3->name.'</option>';
				}
			}
		}
		
	}
	
	$ret .= '</select>';
	
	return $ret;
	
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function walleto_post_new_with_pid_stuff_thg($pid, $step = 1, $fin = '')
{
	$using_perm = walleto_using_permalinks();
	if($using_perm)	return get_permalink(get_option('Walleto_post_new_page_id')). "?product_id=" . $pid."&step=".$step.(!empty($fin) ? "&finalise=yes" : '');
			else return get_bloginfo('siteurl'). "/?page_id=". get_option('Walleto_post_new_page_id'). "&product_id=" . $pid."&step=".$step.(!empty($fin) ? "&finalise=yes" : '');	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function walleto_rewrite_rules( $wp_rewrite )
{

		global $category_url_link, $location_url_link;
		$new_rules = array( 
		

		$category_url_link.'/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$' => 'index.php?product_cat='.$wp_rewrite->preg_index(1)."&feed=".$wp_rewrite->preg_index(2),
        $category_url_link.'/([^/]+)/(feed|rdf|rss|rss2|atom)/?$' => 'index.php?product_cat='.$wp_rewrite->preg_index(1)."&feed=".$wp_rewrite->preg_index(2),
        $category_url_link.'/([^/]+)/page/?([0-9]{1,})/?$' => 'index.php?product_cat='.$wp_rewrite->preg_index(1)."&paged=".$wp_rewrite->preg_index(2),
        $category_url_link.'/([^/]+)/?$' => 'index.php?product_cat='.$wp_rewrite->preg_index(1),
		'shop/([^/]+)/page/([0-9]{1,})/?$' => 'index.php?shop='.$wp_rewrite->preg_index(1).'&pagem='.$wp_rewrite->preg_index(2),	


		);

		$wp_rewrite->rules = $new_rules + $wp_rewrite->rules;

}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

 function walleto_post_type_link_filter_function( $post_link, $id = 0, $leavename = FALSE ) {
	 
	global $category_url_link;
	 
    if ( strpos('%product_cat%', $post_link) === 'FALSE' ) {
      return $post_link;
    }
    $post = get_post($id);
    if ( !is_object($post) || $post->post_type != 'product' ) {
	
		if(walleto_using_permalinks())		
      return str_replace("product_cat", $category_url_link ,$post_link);
	  else return $post_link; 
    }
    $terms = wp_get_object_terms($post->ID, 'product_cat');
    if ( !$terms ) {
      return str_replace('%product_cat%', 'uncategorized', $post_link);
    }
    return str_replace('%product_cat%', $terms[0]->slug, $post_link);
  }
  
  /*****************************************************************************/
  
   function walleto_post_type_link_filter_function2( $post_link, $id = 0, $leavename = FALSE ) {
	 
	global $category_url_link;
	 
    if ( strpos('%shop_cat%', $post_link) === 'FALSE' ) {
      return $post_link;
    }
    $post = get_post($id);
    if ( !is_object($post) || $post->post_type != 'shop' ) {
	
		if(walleto_using_permalinks())		
      return str_replace("product_cat", $category_url_link ,$post_link);
	  else return $post_link; 
    }
    $terms = wp_get_object_terms($post->ID, 'product_cat');
    if ( !$terms ) {
      return str_replace('%shop_cat%', 'uncategorized', $post_link);
    }
    return str_replace('%shop_cat%', $terms[0]->slug, $post_link);
  }
	
	
add_filter('post_type_link', 'Walleto_post_type_link_filter_function', 1, 3);
add_filter('post_type_link', 'Walleto_post_type_link_filter_function2', 1, 3);

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
 function walleto_post_tax_link_filter_function( $post_link, $id = 0, $leavename = FALSE ) {
	global $category_url_link;
    
	if(!walleto_using_permalinks())	 return $post_link;
	return str_replace("product_cat",	$category_url_link ,$post_link);
  }

add_filter('term_link', 'walleto_post_tax_link_filter_function', 1, 3);
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_slider_post()
{
	do_action('walleto_slider_post');	
}

add_filter('walleto_slider_post', 'walleto_slider_post_function');
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_slider_post_function()
{
	?>
	
	<div class="slider-post">
		<a href="<?php the_permalink(); ?>"><?php echo walleto_get_first_post_image(get_the_ID(), 150, 110, 'attachment-150x110', 'slider-image', 1); ?></a>
                <br/>
                
                 <p><span class="slider-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">
                        <?php 
                      
                        the_title(); 
                  
                        
                        ?></a></span><br/>
                        <?php //echo get_the_term_list( get_the_ID(), 'shop_location', '', ', ', '' );   ?><br/>
                        <?php echo Walleto_get_show_price(Walleto_get_item_price(get_the_ID())); ?><br/><br/>
                        
                        
                        <a href="<?php the_permalink(); ?>" class="buttonlight"><?php _e('Buy Now','Walleto'); ?></a>
                        
                       </p>
		
	</div>
	
	<?php
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/ 
function walleto_get_post($arr = '')
{
	do_action('walleto_get_post', $arr);	
}

function walleto_get_post_shop($arr = '')
{
	do_action('walleto_get_post_shop', $arr);	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_get_post_normal_view($arr = '')
{
	do_action('walleto_get_post_normal_view', $arr);	
}

function walleto_get_post_list_view($arr = '')
{
	do_action('walleto_get_post_list_view', $arr);	
}


function walleto_get_shop_list_view($arr = '')
{
	do_action('walleto_get_shop_list_view', $arr);	
}


add_filter('walleto_get_post',						'walleto_get_post_function',0,1);
add_filter('walleto_get_post_shop',					'walleto_get_post_shop_function',0,1);
add_filter('walleto_get_post_normal_view',			'walleto_get_post_normal_view_function',0,1);

add_filter('walleto_get_post_list_view',			'walleto_get_post_list_view_function',0,1);
add_filter('walleto_get_shop_list_view',			'walleto_get_shop_list_view_function',0,1);

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function walleto_get_shop_list_view_function()
{
	global $post;
	
	?>
    			<div class="post_list_view" id="post-ID-<?php the_ID(); ?>">
                
                
                <?php if($featured == "1"): ?>
                <div class="featured-two"></div>
                <?php endif; ?>
                
                
    
                <div class="image_holder_list"><a href="<?php the_permalink(); ?>"><?php echo walleto_get_first_post_image(get_the_ID(),'','','','small-image-post',1); ?></a></div>
                <div class="details_holder_list"><?php 
				 
				$ttl = get_the_title();
				echo '<a href="'.get_permalink(get_the_ID()).'">'.$ttl."</a>";
				
				
				
				 ?></div>
                 
                 <div class="thing_shop_content"><?php echo substr($post->post_content,0,180); ?><br/><br/>
                 
                 <a href="<?php echo get_permalink(get_the_ID()); ?>" class="explore_shop"><?php _e('Expore this Shop','Walleto'); ?></a>
                 </div>
                 
                 
              
                </div>
    
    <?php	
}


/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_get_post_list_view_function( $arr = '')
{

			if($arr[0] == "winner") $pay_this_me = 1;
			if($arr[0] == "unpaid") $unpaid = 1;
			
			$paid = get_post_meta(get_the_ID(),'paid',true);
 
			$closed 		= get_post_meta(get_the_ID(), 'closed', true);
			$post 			= get_post(get_the_ID());
 
			$buy_now 		= get_post_meta(get_the_ID(), 'buy_now', true);
			$featured 		= get_post_meta(get_the_ID(), 'featured', true);
			//$current_bid 		= get_post_meta(get_the_ID(), 'current_bid', true);
			
			$post = get_post(get_the_ID());
			$shop_name = get_userdata($post->post_author);
			$shop_name = $shop_name->user_login;
			
			
			global $current_user;
			get_currentuserinfo();
			$uid = $current_user->ID;
			
			$pid = get_the_ID();
			
?>
				<div class="post_list_view" id="post-ID-<?php the_ID(); ?>">
                
                
                <?php if($featured == "1"): ?>
                <div class="featured-two"></div>
                <?php endif; ?>
                
                
    
                <div class="image_holder_list"><a href="<?php the_permalink(); ?>"><?php echo walleto_get_first_post_image(get_the_ID(),'','','','small-image-post',1); ?></a></div>
                <div class="details_holder_list"><?php 
				 
				$ttl = get_the_title();
				echo '<a href="'.get_permalink(get_the_ID()).'">'.$ttl."</a>";
				echo '<br/>';
				echo '<a href="" class="shop_link">'.$shop_name.'</a>';
				
				 ?></div>
                 
                 <div class="add_to_cart_holder_list"><a class="add_to_cart_link" href="<?php bloginfo('siteurl') ?>/?w_action=add_to_cart&add_to_cart=<?php the_ID(); ?>"><?php _e('Add to Cart','Walleto'); ?></a></div>
                 <div class="price_holder_list"><?php echo walleto_get_show_price(walleto_get_product_price($pid),0); ?></div>
                 
                 
              
                </div>
<?php
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function walleto_get_post_normal_view_function( $arr = '')
{

			if($arr[0] == "winner") $pay_this_me = 1;
			if($arr[0] == "unpaid") $unpaid = 1;
			
			$paid = get_post_meta(get_the_ID(),'paid',true);
			
			$ending 		= get_post_meta(get_the_ID(), 'ending', true);
			$sec 			= $ending - current_time('timestamp',0);
			$location 		= get_post_meta(get_the_ID(), 'Location', true);		
			$closed 		= get_post_meta(get_the_ID(), 'closed', true);
			$post 			= get_post(get_the_ID());
			$only_buy_now 	= get_post_meta(get_the_ID(), 'only_buy_now', true);
			$buy_now 		= get_post_meta(get_the_ID(), 'buy_now', true);
			$featured 		= get_post_meta(get_the_ID(), 'featured', true);
			//$current_bid 		= get_post_meta(get_the_ID(), 'current_bid', true);
			
			$post = get_post(get_the_ID());
			
			global $current_user;
			get_currentuserinfo();
			$uid = $current_user->ID;
			
			$pid = get_the_ID();
			
?>
				<div class="post_normal_view" id="post-ID-<?php the_ID(); ?>">
                
                
                <?php if($featured == "1"): ?>
                <div class="featured-two"></div>
                <?php endif; ?>
                
                
    
                <div class="image_holder_grid"><a href="<?php the_permalink(); ?>"><?php echo walleto_get_first_post_image(get_the_ID(),'','','','small-image-post',1); ?></a></div>
                <div class="details_holder_grid"><?php 
				 
				$ttl = get_the_title();
				$xx = 16;
				
				if(strlen($ttl) > $xx)
				echo substr(0,$xx, $ttl)."..";
				else
				echo $ttl
				
				 ?></div>
              
                </div>
<?php
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_get_post_shop_function()
{
			$post = get_post(get_the_ID());
			
			global $current_user;
			get_currentuserinfo();
			$uid = $current_user->ID;
			
			$pid = get_the_ID();
			
			//global $image_thing_tags;			
			//if(empty($image_thing_tags)) 
			
			$image_thing_tags = 'main-image-post';
			
			
?>
				<div class="post_grid" id="post-ID-<?php the_ID(); ?>">
                
                
                <?php if($featured == "1"): ?>
                <div class="featured-two"></div>
                <?php endif; ?>
                
                
    
                <div class="image_holder_grid"><a title="<?php the_title(); ?>" href="<?php the_permalink(); ?>"><?php echo walleto_get_first_post_image(get_the_ID(),'','','',$image_thing_tags,1); ?></a></div>
                <div class="details_holder_grids">
                <div class="details_holder_grids_ttl"><a title="<?php the_title(); ?>" href="<?php the_permalink() ?>"><?php 
				 
				$ttl = get_the_title();
				$xx = 26;
				
				if(strlen($ttl) > $xx)
				echo substr($ttl, 0,$xx);
				else
				echo $ttl
				
				 ?></a></div>
                 
                  
                 </div>
                
                
                </div>
<?php	
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_get_post_function( $arr = '')
{

			if($arr[0] == "winner") $pay_this_me = 1;
			if($arr[0] == "unpaid") $unpaid = 1;
			
			$paid = get_post_meta(get_the_ID(),'paid',true);
			
			$ending 		= get_post_meta(get_the_ID(), 'ending', true);
			$sec 			= $ending - current_time('timestamp',0);
			$location 		= get_post_meta(get_the_ID(), 'Location', true);		
			$closed 		= get_post_meta(get_the_ID(), 'closed', true);
			$post 			= get_post(get_the_ID());
			$only_buy_now 	= get_post_meta(get_the_ID(), 'only_buy_now', true);
			$buy_now 		= get_post_meta(get_the_ID(), 'buy_now', true);
			$featured 		= get_post_meta(get_the_ID(), 'featured', true);
			//$current_bid 		= get_post_meta(get_the_ID(), 'current_bid', true);
			
			$post = get_post(get_the_ID());
			
			global $current_user;
			get_currentuserinfo();
			$uid = $current_user->ID;
			
			$pid = get_the_ID();
			
			global $image_thing_tags;			
			if(empty($image_thing_tags)) $image_thing_tags = 'main-image-post';
			
?>
				<div class="post_grid" id="post-ID-<?php the_ID(); ?>">
                
                
                <?php if($featured == "1"): ?>
                <div class="featured-two"></div>
                <?php endif; ?>
                
                
    
                <div class="image_holder_grid"><a title="<?php the_title(); ?>" href="<?php the_permalink(); ?>"><?php echo walleto_get_first_post_image(get_the_ID(),'','','',$image_thing_tags,1); ?></a></div>
                <div class="details_holder_grids">
                <div class="details_holder_grids_ttl"><a title="<?php the_title(); ?>" href="<?php the_permalink() ?>"><?php 
				 
				$ttl = get_the_title();
				$xx = 16;
				
				if(strlen($ttl) > $xx)
				echo substr($ttl, 0,$xx)."...";
				else
				echo $ttl
				
				 ?></a> </div>
                 
                 <div class="details_holder_grids_price"><?php echo walleto_get_show_price(walleto_get_product_price($pid),0); ?></div>
                 </div>
                
                
                </div>
<?php
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function walleto_get_first_post_image($pid, $w = 100, $h = 100, $clss = '', $string_image_size = '', $m = 0)
{
	
	//---------------------
	// build the exclude list
	$exclude = array();
	
	$args = array(
	'order'          => 'ASC',
	'post_type'      => 'attachment',
	'post_parent'    => get_the_ID(),
	'meta_key'		 => 'another_reserved1',
	'meta_value'	 => '1',
	'numberposts'    => -1,
	'post_status'    => null,
	);
	$attachments = get_posts($args);
	if ($attachments) {
	    foreach ($attachments as $attachment) {
		$url = $attachment->ID;
		array_push($exclude, $url);
	}
	}
	
	//-----------------

	$args = array(
	'order'          => 'ASC',
	'orderby'        => 'post_date',
	'post_type'      => 'attachment',
	'post_parent'    => $pid,
	'exclude'    		=> $exclude,
	'post_mime_type' => 'image',
	'post_status'    => null,
	'numberposts'    => 1,
	);
	$attachments = get_posts($args);
	if ($attachments) {
	    foreach ($attachments as $attachment) 
	    {
			$default_attr = array(
				'class'	=> "$clss",
			);
			if($m == 1)
			$url = wp_get_attachment_image( $attachment->ID, $string_image_size, false, $default_attr );
			else
			$url = wp_get_attachment_image( $attachment->ID, array($w, $h), false, $default_attr ); 			
			return $url;	  
		}
	}
	else{
			global $_wp_additional_image_sizes;
			if(!is_int($w))
			{
				$an = $_wp_additional_image_sizes[$string_image_size];			
				$w = $an['width'];
				$h = $an['height'];
				//$clss = 'image_class';
			}
			
		 
			
			return '<img src="' . get_bloginfo('template_url') .'/images/nopic.png' . '" alt="no image" width="'.$w.'" height="'.$h.'" class="'.$clss.'" />';
			
	}
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_products_set_metaboxes()
{
		add_meta_box( 'shop_mem', 				'Product Options',						'walleto_product_options_metabox', 	'product', 'side','high' );
		add_meta_box( 'product_variance', 		'Product Variance',						'walleto_product_variance_metabox', 	'product', 'advanced','high' );
		add_meta_box( 'product_images', 		'Product Images / Portfolio',			'walleto_product_images_metabox', 	'product', 'advanced','high' );
		//add_meta_box( 'product_info', 			'Product Information Details',			'walleto_product_info_metabox', 	'product', 'advanced','high' );
		//add_meta_box( 'custom_fields', 			'Product Custom Fields',				'walleto_product_custom_fields_metabox', 	'product', 'advanced','high' );
 
		do_action('walleto_meta_boxes_menu_products');	
		
}

function walleto_product_custom_fields_metabox()
{
	global $post, $wpdb;
	$pid = $post->ID;
	?>
    <table width="100%">
    <input type="hidden" value="1" name="fromadmin" />
	<?php
		$cat 		  	= wp_get_object_terms($pid, 'product_cat');
		$catidarr 		= array();
		
		foreach($cat as $catids)
		{
			$catidarr[] = $catids->term_id;
		}
	
		$arr 	= get_product_category_fields($catidarr, $pid);
		
		for($i=0;$i<count($arr);$i++)
		{
			
			        echo '<tr>';
					echo '<td>'.$arr[$i]['field_name'].$arr[$i]['id'].':</td>';
					echo '<td>'.$arr[$i]['value'];
					do_action('Walleto_step3_after_custom_field_'.$arr[$i]['id'].'_field');
					echo '</td>';
					echo '</tr>';
			
			
		}	
	
	?> 
    
    
    </table>
    <?php	
	
	
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_get_userid_from_username($user)
{			
	$user = get_user_by('login', $user);
	if($user == false) return false;
	
	return $user->ID;
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_username_is_valid($u)
{
	global $wpdb;
	$s = "select ID from ".$wpdb->users." where user_login='$u'";
	$r = $wpdb->get_results($s);
	
	$nr = count($r);
	
	if($nr == 0) return false; 
	return true;
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function Walleto_insert_pages($page_ids, $page_title, $page_tag, $parent_pg = 0 )
{
	
		$opt = get_option($page_ids);			
		if(!Walleto_check_if_page_existed($opt))
		{
			
			$post = array(
			'post_title' 	=> $page_title, 
			'post_content' 	=> $page_tag, 
			'post_status' 	=> 'publish', 
			'post_type' 	=> 'page',
			'post_author' 	=> 1,
			'ping_status' 	=> 'closed', 
			'post_parent' 	=> $parent_pg);
			
			$post_id = wp_insert_post($post);
				
			update_post_meta($post_id, '_wp_page_template', 'walleto-special-page-template.php');
			update_option($page_ids, $post_id);
		
		}
				
	
}


/*************************************************************
*
*	Walleto (c) sitemile.com - function
*
**************************************************************/
function Walleto_check_if_page_existed($pid)
{
	global $wpdb;
	$s = "select * from ".$wpdb->prefix."posts where post_type='page' AND post_status='publish' AND ID='$pid'";
	$r = $wpdb->get_results($s);
	
	if(count($r) > 0) return true;
	return false;	
	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_product_options_metabox()
{
	global $current_user;
	get_currentuserinfo();
	$cid = $current_user->ID;
	
	global $post;
	$pid = $post->ID;
	
	$f = get_post_meta($pid, "featured", true);
	$c = get_post_meta($pid, "status", true);
	$wl_sh = get_post_meta($pid, "wl_free_shipping", true);
	$wl_sp = get_post_meta($pid, "wl_special", true);	
	?>
    
    <input type="hidden" value="1" name="fromadmin" />
    <table width="100%">
    	<tr>
        <td height="30"><?php _e('Price:','Walleto'); ?></td>
        <td><?php echo walleto_get_currency(); ?><input type="text" size="10" name="price" value="<?php echo get_post_meta($pid,'price',true); ?>" /></td>
        </tr>

        <tr>
        <td height="30"><?php _e('Initial Quantity:','Walleto'); ?></td>
        <td><input type="text" size="8" name="ini_quant" value="<?php echo get_post_meta($pid,'ini_quant',true); ?>" /></td>
        </tr>
        
        <tr>
        <td height="30"><?php _e('Quantity:','Walleto'); ?></td>
        <td><input type="text" size="8" name="quant" value="<?php echo get_post_meta($pid,'quant',true); ?>" /></td>
        </tr>
        
        <tr>
        <td height="30"><?php _e('Free Shipping:','Walleto'); ?></td>
        <td><input type="checkbox" name="wl_free_shipping" value="1" <?php if($wl_sh == '1') echo ' checked="checked" '; ?> /></td>
        </tr>
 
        <tr>
        <td height="30"><?php _e('Mark Special:','Walleto'); ?></td>
        <td><input type="checkbox" name="wl_special" value="1" <?php if($wl_sp == '1') echo ' checked="checked" '; ?> /></td>
        </tr>
        
        <tr>
        <td height="30"><?php _e('Featured:','Walleto'); ?></td>
        <td><input type="checkbox" value="1" name="featured" <?php if($f == '1') echo ' checked="checked" '; ?> /></td>
        </tr>
    
    
     <tr>
        <td height="30"><?php _e('Paused/Hidden:','Walleto'); ?></td>
        <td><input type="checkbox" value="paused" name="status" <?php if($c == 'paused') echo ' checked="checked" '; ?> /></td>
        </tr>
        
	<?php do_action('Walleto_details_table_for_product', $pid) ?>
    </table>
    
    
    <?php	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_shop_images_metabox()
{
global $current_user;
	get_currentuserinfo();
	$cid = $current_user->ID;
	
	global $post;
	$pid = $post->ID;


?>
	
    
    <script type="text/javascript" src="<?php echo get_bloginfo('template_url'); ?>/lib/uploadify/jquery.uploadify-3.1.min.js"></script>     
	<link rel="stylesheet" href="<?php echo get_bloginfo('template_url'); ?>/lib/uploadify/uploadify.css" type="text/css" />
	
    <script type="text/javascript">
	
	function delete_this2(id)
	{
		 jQuery.ajax({
						method: 'get',
						url : '<?php echo get_bloginfo('siteurl');?>/index.php/?_ad_delete_pid='+id,
						dataType : 'text',
						success: function (text) {   jQuery('#image_ss'+id).remove();  }
					 });
		  //alert("a");
	
	}

	
	
	jQuery(function() {
		setTimeout(function () {
		jQuery("#fileUpload3").uploadify({
			height        : 30,
			auto:			true,
			swf           : '<?php echo get_bloginfo('template_url'); ?>/lib/uploadify/uploadify.swf',
			uploader      : '<?php echo get_bloginfo('template_url'); ?>/lib/uploadify/uploady.php',
			width         : 120,
			fileTypeExts  : '*.jpg;*.jpeg;*.gif;*.png',
			formData    : {'ID':<?php echo $pid; ?>,'author':<?php echo $cid; ?>},
			onUploadSuccess : function(file, data, response) {
			
			//alert(data);
			var bar = data.split("|");
			
jQuery('#thumbnails').append('<div class="div_div" id="image_ss'+bar[1]+'" ><img width="70" class="image_class" height="70" src="' + bar[0] + '" /><a href="javascript: void(0)" onclick="delete_this2('+ bar[1] +')"><img border="0" src="<?php echo get_bloginfo('template_url'); ?>/images/delete_icon.png" border="0" /></a></div>');
}
	
			
			
    	});
		
		},0);
	});
	
	
	</script>
	
    <style type="text/css">
	.div_div
	{
		margin-left:5px; float:left; 
		width:110px;margin-top:10px;
	}
	
	</style>
    
    <div id="fileUpload3">You have a problem with your javascript</div>
    <div id="thumbnails" style="overflow:hidden;margin-top:20px">
    
    <?php

		$args = array(
		'order'          => 'ASC',
		'orderby'        => 'post_date',
		'post_type'      => 'attachment',
		'post_parent'    => $post->ID,
		'post_mime_type' => 'image',
		'numberposts'    => -1,
		); $i = 0;
		
		$attachments = get_posts($args);



	if ($attachments) {
	    foreach ($attachments as $attachment) {
		$url = wp_get_attachment_url($attachment->ID);
		
			echo '<div class="div_div"  id="image_ss'.$attachment->ID.'"><img width="70" class="image_class" height="70" src="' .
			walleto_generate_thumb($attachment->ID, 70, 70). '" />
			<a href="javascript: void(0)" onclick="delete_this2(\''.$attachment->ID.'\')"><img border="0" src="'.get_bloginfo('template_url').'/images/delete_icon.png" /></a>
			</div>';
	  
	}
	}


	?>
    
    </div>
    
<?php 	
	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_product_info_metabox()
{
	global $current_user;
	get_currentuserinfo();
	$cid = $current_user->ID;
	
	global $post;
	$pid = $post->ID;
	
	?>
    
    <textarea rows="10" cols="80" class="do_input" id="other_details"  name="other_details"><?php echo get_post_meta($pid, 'other_details', true); ?></textarea>
    
    <?php	
	
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_product_variance_metabox()
{
	global $current_user, $wpdb;
	get_currentuserinfo();
	$cid = $current_user->ID;
	
	global $post;
	$pid = $post->ID;
	$cat 		= wp_get_object_terms($pid, 'product_cat');
	
	?>
    
    <ul id="post-new5">
     <?php
			
			global $wpdb;
			$kk = 0;
			
			if($cat[0]->term_id > 0):	
				
				$xx = $cat[0]->term_id;			
				if($xx > 0):	
						
						 
						$s1 = "select * from ".$wpdb->prefix."walleto_variations where category_id='$xx' or category_id='0' order by order_id asc";
						$r1 = $wpdb->get_results($s1);
						
						if(count($r1) > 0):
							
							foreach($r1 as $row1):
								
								$taxonomies = get_terms( $row1->slug, 'hide_empty=0' ); 
								if(count($taxonomies) > 0):
									
									$main_array[] = $taxonomies;
								
								endif;								
							endforeach;
						endif;		
						
						if(is_array($main_array))		
						$result_array = ProjectTheme_array_cartesian_product($main_array);				
						
						if(count($result_array) > 0)
						{
							?>
                            
                            	<li>
                                	<h3 class="variety_name"><?php _e('Product Variance','Walleto'); ?></h3>
                                </li>
                                
                               <li>
                                	<span class="small_fonts"><?php _e('Please fill in at least the quantity field to take into consideration. Leave empty if the product variance is not available. Also if price is left empty the base price will be considered.','Walleto'); ?></span>
                                </li>
                            
                            <?php
							
							foreach($result_array as $combination)
							{
								if(is_array($combination))
								{
									$cnts = count($combination);
									$string_array_name = '';
									$variance_internal_sku = '';
									
									$terms_ids = array();
									$terms_taxes = array();
									
									foreach($combination as $single_variance)
									{
										$ProjectTheme_get_product_variance = ProjectTheme_get_product_variance($single_variance->taxonomy);
										if($ProjectTheme_get_product_variance != false) $ProjectTheme_get_product_variance = $ProjectTheme_get_product_variance->name . ": ";										
										//-----------------
										
										$string_array_name .= $ProjectTheme_get_product_variance.$single_variance->name;
										$cnts--;
										
										if(	$cnts > 0) $string_array_name .= ', ';
										//$variance_internal_sku .= $single_variance->term_id.'_';	
										
										$terms_ids[] = 	$single_variance->term_id;
										$terms_taxes[] = 	$single_variance->taxonomy;							
									}
									
									asort($terms_ids);
									foreach($terms_ids as $tms) {  $variance_internal_sku .= $tms.'_';	 }
										
									$sf = "select * from ".$wpdb->prefix."walleto_variations_content where pid='$pid' and variation_string='$variance_internal_sku'";
									$rf = $wpdb->get_results($sf);
									
									if(count($rf) > 0)
									{
										$price_variance_ 	= $rf[0]->price;	
										$quant_variance_ 	= $rf[0]->quant;
										$weight_variance_ 	= $rf[0]->weight;
									}
									else
									{
										$price_variance_ 	= '';	
										$quant_variance_ 	= '';
										$weight_variance_ 	= '';
									}
									
									?>
										
									 <li><h2 class="prod_variances_h2"><?php echo $string_array_name; ?></h2>
											<p>
												<?php _e('Price:','Walleto'); ?> <input type="text" class="do_input" name="price_variance_<?php echo $variance_internal_sku ?>"  size="10" value="<?php echo $price_variance_ ?>" /> 
												<?php _e('Quantity:','Walleto'); ?> <input type="text" class="do_input" name="quant_variance_<?php echo $variance_internal_sku ?>" size="10" value="<?php echo $quant_variance_ ?>" />
												<?php _e('Weight:','Walleto'); ?> <input type="text" class="do_input" name="weight_variance_<?php echo $variance_internal_sku ?>" size="10" value="<?php echo $weight_variance_ ?>" /> 
											
											</p>
										</li>
										<hr color="#f2f2f2" />
						
									
									<?php
								}
								
							}					
							
						}
										
                   endif; 	
				
				
			endif; ?>
    
    </ul>
    <?php
	
}

function walleto_show_dropdown_variance($pid, $slug)
{
	global $wpdb;
	$s = "select * from ".$wpdb->prefix."walleto_variations_content where variation_slug='$slug' AND pid='$pid'";
	$r = $wpdb->get_results($s);
	
	if(count($r) > 0)
	{
		$content = '<select class="do_input5" name="">';	
		foreach($r as $row)
		{
			if($row->quant > 0)
			{
				$variation = get_term($row->variation_type, $slug);
				$content .= '<option value="'.$row->variation_type.'">'.$variation->name.' ('.$row->quant.')</option>';	
			}
		}
		
		return $content .= '</select>';	
	}
	


}


function walleto_product_images_metabox()
{

	global $current_user;
	get_currentuserinfo();
	$cid = $current_user->ID;
	
	global $post;
	$pid = $post->ID;


?>
	
    
    <script type="text/javascript" src="<?php echo get_bloginfo('template_url'); ?>/lib/uploadify/jquery.uploadify-3.1.js"></script>     
	<link rel="stylesheet" href="<?php echo get_bloginfo('template_url'); ?>/lib/uploadify/uploadify.css" type="text/css" />
	
    <script type="text/javascript">
	
	jQuery(document).ready(function(){
		jQuery(".post-type-product #thumbnails .del_att").click(function(e) {
			e.preventDefault();
			var id = jQuery(this).attr("data-atth");
			var data = {
				'action': 'wl_remove_proimg',
				'ad_delete_pid': id,
			};
			jQuery("#thumbnails").find(".ajax-loader").css("visibility", "visible");
			jQuery.post(ajaxurl, data, function(response) {
				jQuery('#image_ss'+id).remove();
				jQuery("#thumbnails").find(".ajax-loader").css("visibility", "hidden");
			});
		});
	});

	
	
	jQuery(function() {
		
		jQuery("#fileUpload3").uploadify({
			height        : 30,
			auto:			true,
			swf           : '<?php echo get_bloginfo('template_url'); ?>/lib/uploadify/uploadify.swf',
			uploader      : '<?php echo get_bloginfo('template_url'); ?>/lib/uploadify/uploady.php',
			width         : 120,
			fileTypeExts  : '*.jpg;*.jpeg;*.gif;*.png',
			formData    : {'ID':<?php echo $pid; ?>,'author':<?php echo $cid; ?>},
			onUploadSuccess : function(file, data, response) {
			
			//alert(data);
			var bar = data.split("|");
			
jQuery('#thumbnails').append('<div class="div_div" id="image_ss'+bar[1]+'" ><img width="70" class="image_class" height="70" src="' + bar[0] + '" /><a class="del_att" href="javascript: void(0)" data-atth="'+ bar[1] +'"><img border="0" src="<?php echo get_bloginfo('template_url'); ?>/images/delete_icon.png" border="0" /></a></div>');
}
	
			
			
    	});
		
		
	});
	
	
	</script>
	
    <style type="text/css">
	.div_div
	{
		margin-left:5px; float:left; 
		width:110px;margin-top:10px;
	}
	
	</style>
    
    <div id="fileUpload3">You have a problem with your javascript</div>
    <div id="thumbnails" style="overflow:hidden;margin-top:20px">
    
    <?php

		$args = array(
		'order'          => 'ASC',
		'orderby'        => 'post_date',
		'post_type'      => 'attachment',
		'post_parent'    => $post->ID,
		'post_mime_type' => 'image',
		'numberposts'    => -1,
		); $i = 0;
		
		$attachments = get_posts($args);



	if ($attachments) {
	    foreach ($attachments as $attachment) {
		$url = wp_get_attachment_url($attachment->ID);
		
			echo '<div class="div_div"  id="image_ss'.$attachment->ID.'"><img width="70" class="image_class" height="70" src="' .
			walleto_generate_thumb($attachment->ID, 70, 70). '" />
			<a class="del_att" href="javascript: void(0)" data-atth="'.$attachment->ID.'"><img border="0" src="'.get_bloginfo('template_url').'/images/delete_icon.png" /></a>
			</div>';
	  
	}
	echo '<img class="ajax-loader" src="'.get_template_directory_uri().'/images/ajax-loader.gif" alt="Loading..." style="visibility:hidden;" />';
	}


	?>
    
    </div>
    
<?php 

}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_shops_set_metaboxes()
{
	    add_meta_box( 'shop_mem', 			'Featured Shop?',						'walleto_shop_membership_metabox', 	'shop', 'side',		'high' );
		//add_meta_box( 'shop_images', 		'Shop Images / Portfolio',				'walleto_shop_images_metabox', 		'shop', 'advanced',	'high' );
		//add_meta_box( 'shop_info', 			'Shop Information Details',				'walleto_shop_info_metabox', 		'shop', 'advanced',	'high' );
 
		do_action('walleto_meta_boxes_menu_shops');	
	
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_shop_membership_metabox()
{
	global $current_user;
	get_currentuserinfo();
	$uid = $current_user->ID;
	
	global $post;
	$pid = $post->ID;
	
	?>
    <ul id="post-new4"> 
    <input name="fromadmin" type="hidden" value="1" />
    
    
         <?php /*
Commented by Spidanet for disable shop subscription
           <li>
        <h2>          
          
       <?php _e("Shop Membership",'Walleto'); ?>:</h2>
        <p><input type="text" name="membership_available" id="membership_available" value="<?php
		
		$d = get_post_meta($pid,'membership_available',true);
		
		if(!empty($d)) {
		$r = date_i18n('m/d/Y H:i:s', $d);
		echo $r;
		}
		 ?>" class="do_input"  /></p>
        </li> */ ?>
        
 <script>

jQuery(document).ready(function() {
	 jQuery('#membership_available').datetimepicker({
	showSecond: true,
	timeFormat: 'hh:mm:ss'
});});
 
 </script>
        
        <li>
        <h2>Featured:</h2>
        <p> <?php $featured = get_post_meta($pid,'featured',true)  ?>
        <select name="featured_shop">
        <option value="0" <?php echo $featured == "0" ? "selected='selected'" : ''; ?>>No</option>
        <option value="1" <?php echo $featured == "1" ? "selected='selected'" : ''; ?>>Yes</option>
        
        </select>
        </p>
        </li>
	</ul>    
    
    <?php
		
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_get_taxonomy_variance($slug)
{
	
}

function walleto_save_custom_fields($pid)
{
	
	$sbr_post = get_post($pid);
	global $wpdb;
	$term 		= wp_get_object_terms($pid, 'product_cat');
	
	if(isset($_POST['fromadmin']) and $sbr_post->post_type == "product")
	{
		//**********************************************
		
		do_action('Walleto_save_product_save_val_admin',$pid);
		
		$xx = $term[0]->term_id;
		if($xx > 0):	
						
						 
						$s1 = "select * from ".$wpdb->prefix."walleto_variations where category_id='$xx' or category_id='0' order by order_id asc";
						$r1 = $wpdb->get_results($s1);
				 
						
						if(count($r1) > 0):
							
							foreach($r1 as $row1):
								
								$taxonomies = get_terms( $row1->slug, 'hide_empty=0' ); 
								if(count($taxonomies) > 0):
									
									$main_array[] = $taxonomies;
								
								endif;								
							endforeach;
						endif;		
						
						if(is_array($main_array))			
						$result_array = ProjectTheme_array_cartesian_product($main_array);				
						
						if(count($result_array) > 0)
						{
							
							foreach($result_array as $combination)
							{
								if(is_array($combination))
								{
									$cnts = count($combination);
									$string_array_name = '';
									$variance_internal_sku = '';
									
									$terms_ids = array();
									$terms_taxes = array();
									
									foreach($combination as $single_variance)
									{
										$ProjectTheme_get_product_variance = ProjectTheme_get_product_variance($single_variance->taxonomy);
										if($ProjectTheme_get_product_variance != false) $ProjectTheme_get_product_variance = $ProjectTheme_get_product_variance->name . ": ";										
										//-----------------
										
										$string_array_name .= $ProjectTheme_get_product_variance.$single_variance->name;
										$cnts--;
										
										if(	$cnts > 0) $string_array_name .= ', ';
										//$variance_internal_sku .= $single_variance->term_id.'_';	
										
										$terms_ids[] = 	$single_variance->term_id;
										$terms_taxes[] = 	$single_variance->taxonomy;							
									}
									
									asort($terms_ids);
									foreach($terms_ids as $tms) {  $variance_internal_sku .= $tms.'_';	 }
										
									$sf = "select * from ".$wpdb->prefix."walleto_variations_content where pid='$pid' and variation_string='$variance_internal_sku'";
									$rf = $wpdb->get_results($sf);
									
									$price_variance_ 	= $_POST['price_variance_' . $variance_internal_sku];	
									$quant_variance_ 	= $_POST['quant_variance_' . $variance_internal_sku];
									$weight_variance_ 	= $_POST['weight_variance_' . $variance_internal_sku];
									
									//-----------------
									
									if(count($rf) > 0)
									{
										$rkow = $rf[0];
										 
										
										if($quant_variance_ <= 0 or !is_numeric($quant_variance_))
										{
											$price_variance_ 	= '';	
											$quant_variance_ 	= '';
											$weight_variance_ 	= '';
													
										}
										
										$smo = "update ".$wpdb->prefix."walleto_variations_content set price='$price_variance_', quant='$quant_variance_', weight='$weight_variance_' where id='{$rkow->id}'";
										$wpdb->query($smo);
										 
									}
									else
									{
										if($quant_variance_ <= 0 or !is_numeric($quant_variance_))
										{
											$price_variance_ 	= '';	
											$quant_variance_ 	= '';
											$weight_variance_ 	= '';		
										}
										 
										 
										$wpdb->query("insert into ".$wpdb->prefix."walleto_variations_content (variation_string, pid, price, quant, weight) values('$variance_internal_sku','$pid','$price_variance_','$quant_variance_','$weight_variance_')");
									 	
									}
									
									 
								}
								
							}					
							
						}
										
           endif; 
		
		//**********************************************
		
		$price 					= trim($_POST['price']);
		$shipping 				= trim($_POST['shipping']);
		$ini_quant 				= trim($_POST['ini_quant']);
		$quant 					= trim($_POST['quant']);
		
		update_post_meta($pid,'quant', $quant);
		update_post_meta($pid,'ini_quant', $ini_quant);
		update_post_meta($pid,'shipping', $shipping);
		update_post_meta($pid,'price', $price);
		
		update_post_meta($pid,'status', $_POST['status']);
		
		$featured = 0;
		if(isset($_POST['featured'])) $featured = 1;		
		update_post_meta($pid,'featured',  $featured );
		
		$wl_fr_shp = 0;
		if(isset($_POST['wl_free_shipping'])) $wl_fr_shp = 1;
		update_post_meta($pid,'wl_free_shipping',  $wl_fr_shp );
		
		$wl_spl = 0;
		if(isset($_POST['wl_special'])) $wl_spl = 1;
		update_post_meta($pid,'wl_special',  $wl_spl );			
		
		update_post_meta($pid,'other_details',  trim($_POST['other_details']) );
		
		//----------------
		
		$closed = 0;
		if(isset($_POST['closed'])) $closed = 1;		
		update_post_meta($pid,'closed',  $closed );
		
		//------------------
		
		for($i=0;$i<count($_POST['custom_field_id']);$i++)
		{
			$id = $_POST['custom_field_id'][$i];
			$valval = $_POST['custom_field_value_'.$id];		
			
			if(is_array($valval))
					update_post_meta($pid, 'custom_field_ID_'.$id, $valval);
			else
				update_post_meta($pid, 'custom_field_ID_'.$id, strip_tags($valval));
		}
	
		
	}
	
	if(isset($_POST['fromadmin']) and $sbr_post->post_type == "shop")
	{	
		$shop_facebook 			= trim($_POST['shop_facebook']);
		$shop_twitter 			= trim($_POST['shop_facebook']);
		$shop_policies 			= trim($_POST['shop_policies']);
		$contact_information 	= trim($_POST['contact_information']);
		$featured				= $_POST['featured'];
		
		update_post_meta($pid,'featured', $featured);
		update_post_meta($pid,'shop_facebook', $shop_facebook);
		update_post_meta($pid,'shop_twitter', $shop_twitter);
		update_post_meta($pid,'contact_information', nl2br($contact_information));
		update_post_meta($pid,'shop_policies', nl2br($shop_policies));

 		$membership_available = $_POST['membership_available'];
		update_post_meta($pid,'membership_available', strtotime($membership_available));
		update_post_meta($pid,'featured', nl2br($_POST['featured_shop']));
		
	}	  
	
}

function get_product_fields_values($pid)
	{
		$cat = wp_get_object_terms($pid, 'product_cat');
	
		$catid = $cat[0]->term_id ;
	
		global $wpdb;
		$s = "select * from ".$wpdb->prefix."walleto_custom_fields order by ordr asc "; //where cate='all' OR cate like '%|$catid|%' order by ordr asc";	
		$r = $wpdb->get_results($s);
		
	
		
		$arr = array();
		$i = 0;
		
		foreach($r as $row) // = mysql_fetch_object($r))
		{
			
			$pmeta = get_post_meta($pid, "custom_field_ID_".$row->id);
		
			if(!empty($pmeta) && count($pmeta) > 0)
			{
			 	$arr[$i]['field_name']  = $row->name;
		
				if(!empty($pmeta))
				{
					$arr[$i]['field_name']  = $row->name;
					$arr[$i]['field_value'] = $pmeta;
					$i++;
				}
			
			
			}
		}
		
		return $arr;
	}

function walleto_get_payments_link()
{
	return get_permalink(get_option('Walleto_my_account_my_finances_page_id'));	
}

function walleto_isValidEmail($email){
	if(is_email($email))
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_shop_info_metabox()
{
	global $current_user;
	get_currentuserinfo();
	$cid = $current_user->ID;
	
	global $post;
	$pid = $post->ID;
	
	?>
    
    <input type="hidden" value="1" name="fromadmin" />
    <table>
    <tr>
    <td width="130"><?php _e('Shop Facebook:','Walleto'); ?></td>
    <td><input type="text" size="45" value="<?php echo get_post_meta($pid, 'shop_facebook', true); ?>" name="shop_facebook" /></td>
    </tr>
    
    <tr>
    <td><?php _e('Shop Twitter:','Walleto'); ?></td>
    <td><input type="text" size="45" value="<?php echo get_post_meta($pid, 'shop_twitter', true); ?>" name="shop_twitter" /></td>
    </tr>
        
    <!-- <tr>
    <td valign="top"><?php #_e('Shop address:','Walleto'); ?></td>
    <td><textarea name="contact_information" rows="4" cols="70" ><?php #echo str_replace("<br />", " ", get_post_meta($pid, 'contact_information', true)); ?></textarea></td>
    </tr> -->
        
    <tr>
    <td valign="top"><?php _e('Shop Policy:','Walleto'); ?></td>
    <td><textarea name="shop_policy" rows="6" cols="70" ><?php echo str_replace("<br />", " ", get_post_meta($pid, 'shop_policy', true)); ?></textarea></td>
    </tr>    
    </table>       
    <?php	
	
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_framework_init_widgets()
{


	register_sidebar( array(
		'name' => __( 'Single Page Sidebar', 'Walleto' ),
		'id' => 'single-widget-area',
		'description' => __( 'The sidebar area of the single blog post', 'Walleto' ),
		'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );
	
	
	
		
			register_sidebar( array(
		'name' => __( 'Walleto - Stretch Wide MainPage Sidebar', 'Walleto' ),
		'id' => 'main-stretch-area',
		'description' => __( 'This sidebar is site wide stretched in home page, just under the slider/menu.', 'Walleto' ),
		'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );
	
	
	
		register_sidebar( array(
		'name' => __( 'Other Page Sidebar', 'Walleto' ),
		'id' => 'other-page-area',
		'description' => __( 'The sidebar area of any other page than the defined ones', 'Walleto' ),
		'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );
	
	
	
	
	register_sidebar( array(
		'name' => __( 'Home Page Sidebar - Right', 'Walleto' ),
		'id' => 'home-right-widget-area',
		'description' => __( 'The right sidebar area of the homepage', 'Walleto' ),
		'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );
	
	
	
	
	register_sidebar( array(
		'name' => __( 'Home Page Sidebar - Left', 'Walleto' ),
		'id' => 'home-left-widget-area',
		'description' => __( 'The left sidebar area of the homepage', 'Walleto' ),
		'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );
	
	
	
	register_sidebar( array(
		'name' => __( 'First Footer Widget Area', 'Walleto' ),
		'id' => 'first-footer-widget-area',
		'description' => __( 'The first footer widget area', 'Walleto' ),
		'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	// Area 4, located in the footer. Empty by default.
	register_sidebar( array(
		'name' => __( 'Second Footer Widget Area', 'Walleto' ),
		'id' => 'second-footer-widget-area',
		'description' => __( 'The second footer widget area', 'Walleto' ),
		'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	// Area 5, located in the footer. Empty by default.
	register_sidebar( array(
		'name' => __( 'Third Footer Widget Area', 'Walleto' ),
		'id' => 'third-footer-widget-area',
		'description' => __( 'The third footer widget area', 'Walleto' ),
		'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	// Area 6, located in the footer. Empty by default.
	register_sidebar( array(
		'name' => __( 'Fourth Footer Widget Area', 'Walleto' ),
		'id' => 'fourth-footer-widget-area',
		'description' => __( 'The fourth footer widget area', 'Walleto' ),
		'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );
	

		
			register_sidebar( array(
			'name' => __( 'Walleto - Product Single Sidebar', 'Walleto' ),
			'id' => 'product-widget-area',
			'description' => __( 'The sidebar of the single product page', 'Walleto' ),
			'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
			'after_widget' => '</li>',
			'before_title' => '<h3 class="widget-title">',
			'after_title' => '</h3>',
		) );
		
		register_sidebar( array(
			'name' => __( 'Walleto - Shop Single Sidebar', 'Walleto' ),
			'id' => 'shop-widget-area',
			'description' => __( 'The sidebar of the single shop page', 'Walleto' ),
			'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
			'after_widget' => '</li>',
			'before_title' => '<h3 class="widget-title">',
			'after_title' => '</h3>',
		) );
		
		
			register_sidebar( array(
			'name' => __( 'Walleto - HomePage Area','Walleto' ),
			'id' => 'main-page-widget-area',
			'description' => __( 'The sidebar for the main page, just under the slider.', 'Walleto' ),
			'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
			'after_widget' => '</li>',
			'before_title' => '<h3 class="widget-title">',
			'after_title' => '</h3>',
		) );
		

	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_using_permalinks()
{
	global $wp_rewrite;
	if($wp_rewrite->using_permalinks()) return true; 
	else return false; 	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_get_credits($uid)
{
	$c = get_user_meta($uid,'credits',true);
	if(empty($c))
	{
		update_user_meta($uid,'credits',"0");	
		return 0;
	}
	
	return $c;
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_update_credits($uid, $ttl)
{
	update_user_meta($uid,'credits', $ttl);	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function walleto_get_total_for_order($oid)
{
	global $wpdb;
	$g_tot = 0;
	$odr_vat 	= (get_option('Walleto_purchase_vat')) ? get_option('Walleto_purchase_vat') : 15;
	$odr_vat_perc = $odr_vat / 100;	
	$s = "select * from ".$wpdb->prefix."walleto_orders where id='$oid'";
	$r = $wpdb->get_results($s);
	
	// Whether buyer has selected pick up. If so, then include pick up charge in grand total.
	$pkup_charge = 0;
	if(!empty($r[0]->pickup)) {
		$infarr = "";
		$infarr = explode('|', $r[0]->pickup);
		$pkup_charge = $infarr[1];
	}
	$tm = strtotime("05 September 2015", current_time('timestamp', 0));
	if($r[0]->datemade < $tm) {
		$g_tot = $r[0]->totalprice + $r[0]->shipping + ($r[0]->shipping * $odr_vat_perc) + $pkup_charge;
	} else {
		$g_tot = $r[0]->totalprice + $r[0]->shipping + $pkup_charge;	
	}
	$g_tot = Walleto_formats($g_tot, 2);
	$g_tot = str_replace( ',', '', $g_tot );	
	return $g_tot;
		
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/


function walleto_show_cancel_order_link_for_order($oid)
{
	if(Walleto_using_permalinks())
	{
		return get_permalink(get_option('Walleto_my_account_cancel_order_item_page_id')) . "?oid=" . $oid;	
	}
	else
	{
		return get_permalink(get_option('Walleto_my_account_cancel_order_item_page_id')) . "&oid=" . $oid;	
	}
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function walleto_show_payment_link_for_order($oid)
{
	if(Walleto_using_permalinks())
	{
		return get_permalink(get_option('Walleto_my_account_pay_4_item_page_id')) . "?oid=" . $oid;	
	}
	else
	{
		return get_permalink(get_option('Walleto_my_account_pay_4_item_page_id')) . "&oid=" . $oid;	
	}
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_show_payment_link_for_order_virtual_currency($oid, $c = 0)
{
	if(Walleto_using_permalinks())
	{
		return get_permalink(get_option('Walleto_my_account_pay_4_item_virt_page_id')) . "?".($c == 1 ? 'confirm=yes&' : '')."oid=" . $oid;	
	}
	else
	{
		return get_permalink(get_option('Walleto_my_account_pay_4_item_virt_page_id')) . ($c == 1 ? '&confirm=yes' : '')."&oid=" . $oid;	
	}
}

function walleto_show_payment_link_for_order_cod($oid, $c = 0)
{
	if(Walleto_using_permalinks())
	{
		return get_permalink(3851) . "?".($c == 1 ? 'confirm=yes&' : '')."oid=" . $oid;	
	}
	else
	{
		return get_permalink(3851) . ($c == 1 ? '&confirm=yes' : '')."&oid=" . $oid;	
	}
}

function walleto_show_payment_link_for_by_skrill($oid )
{
	return get_bloginfo('siteurl') . "/?pay_order_skrill=1&oid=" . $oid;
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_left_to_pay_for_order($oid, $gtotal = false)
{
	global $wpdb;
	$ordr_obj = walleto_get_order_obj($oid);
	$s = "select * from ".$wpdb->prefix."walleto_order_contents where orderid='$oid' and paid='0'";
	$r = $wpdb->get_results($s);
	$total = 0;
	if(count($r) > 0)
	{
		foreach ($r as $row)
		{
			$total += $row->price * $row->quant;	
			$shp = get_post_meta($row->pid, 'shipping', true)* $row->quant;
			$total += $shp;
		}
	
	}

	/* Spidanet checking if it is coupon enabled order, so update total..*/
	if($total > 0){
		$discountAvl= check_discount($oid);
		if( $discountAvl > 0 ){
			$total -= $discountAvl;
		}
	}
	// If grand total is set to true.
	if($gtotal && $ordr_obj->paid == 0) {
		$odr_vat = (get_option('Walleto_purchase_vat')) ? get_option('Walleto_purchase_vat') : 15;
		$odr_vat_perc = $odr_vat / 100;
		$total += ($ordr_obj->shipping + ($ordr_obj->shipping * $odr_vat_perc));
	}
	
	return $total;
}

function walleto_display_unpaid_order_for_buyer($row)
{
$total_prc = walleto_get_total_for_order($row->id);
?>
    	<div class="my_order">
        	<div class="my_order_id">#<?php echo $row->id ?></div>
            <div class="my_order_datemade"><?php echo date_i18n('d-M-Y H:i:s', $row->datemade) ?></div>
            <div class="my_order_price"><?php echo walleto_get_show_price($total_prc); ?></div>
            <div class="my_order_left_to_pay"><?php echo walleto_get_show_price($total_prc); ?></div>
            <div class="my_order_buttons">            
                <a class="btns_pay" href="<?php echo walleto_get_order_content_link($row->id) ?>"><?php _e('See Items','Walleto'); ?></a> 
                <a class="btns_pay" href="<?php echo walleto_show_payment_link_for_order($row->id) ?>"><?php _e('Pay This','Walleto'); ?></a>
                <a class="btns_pay" href="<?php echo walleto_show_cancel_order_link_for_order($row->id) ?>"><?php _e('Cancel Order','Walleto'); ?></a>                
            </div>        
        </div>    
    <?php	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_display_unshipped_order_for_buyer($row)
{
?>
    	<div class="my_order">
        	<div class="my_order_id"><a href="<?php echo walleto_get_order_content_link($row->id)  ?>">#<?php echo $row->id ?></a></div>
            <div class="my_order_datemade"><?php echo date_i18n('d-M-Y H:i:s', $row->datemade) ?></div>
            <div class="my_order_price"><?php echo walleto_get_show_price(walleto_get_total_for_order($row->id)); ?></div>
            <div class="my_order_price"><?php echo walleto_get_show_price(walleto_left_to_pay_for_order($row->id, true)) ?></div> 
             <div class="my_order_buttons">
            <?php 
               if($row->delivered==1){
               	?>
				<img width="100px" src="<?php echo get_template_directory_uri(); ?>/img/odr_delivered.png" alt="Delivered">
			   <?php } else {
					echo '<form method="post" action="" name="wl_resend_cde">';
					wp_nonce_field( 'wl_resend_vcde' );
					echo '<input type="hidden" name="wl_odr_id" value="'.$row->id.'" />';
					echo '<input type="submit" name="wl_resend_cde_btn" class="btns_pay" value="'.__('Resend PIN','Walleto').'" />';
					echo '</form><br />';
					echo __('Not delivered','Walleto'); 
				} ?>            
            </div>
         </div>
    
    <?php	
	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function walleto_display_awaiting_shipping_for_seller($row)
{
	global $current_user;
	get_currentuserinfo();
	$uid = $current_user->ID;
	
	$buyer = $row->uid;
	
	?>
    	<div class="my_shipp">
        	<div class="my_order_id">#<?php echo $row->id ?></div>
            <div class="my_order_datemade"><?php echo date_i18n('d-M-Y H:i:s', $row->datemade) ?></div>
            <div class="my_order_price"><?php echo walleto_get_show_price($row->totalprice) ?></div>
            <div class="my_order_details">
            
                <?php 
				
					$dt = !empty($row->paid_on) ? date_i18n('d-M-Y H:i:s', $row->paid_on) : "";
					echo empty($dt) ? '&nbsp;' : $dt; ?>
            
            </div>
            
              <div class="my_order_buttons">
              	
                <a class="btns_pay" href="<?php echo walleto_get_order_content_link2($row->id, $uid) ?>"><?php _e('Details','Walleto'); ?></a> 
                <a class="btns_pay" href="<?php bloginfo('siteurl') ?>/?w_action=mark_shipped&oid=<?php echo $row->id ?>"><?php _e('Mark Shipped','Walleto'); ?></a> 
                
              </div>
        
        	<div class="shipping_information"><?php
            
				$dets = get_user_meta($buyer,'shipping_info',true);
				echo '&nbsp; '. sprintf(__('Buyer Shipping Address: %s','Walleto'), $dets);
			
			?>
            
            <?php
			
			$using_perm = Walleto_using_permalinks();
	
			if($using_perm)	$privurl_m = get_permalink(get_option('Walleto_my_account_priv_mess_page_id')). "?";
			else $privurl_m = get_bloginfo('siteurl'). "/?page_id=". get_option('Walleto_my_account_priv_mess_page_id'). "&";	
			
			$prvs = $privurl_m."priv_act=send&";
			$prvs .= 'uid='.$buyer;
			
			$buyer1 = get_userdata($buyer);
			
			?>
            
            
              &nbsp; <a class="btns_pay" href="<?php echo $prvs ?>"><?php echo sprintf(__('Contact Buyer: %s','Walleto'), $buyer1->user_login); ?></a>
            
            </div>
        
        </div>
    
    <?php	
	
}


/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_display_done_payments_for_seller($row)
{
	
	$oid = $row->id; 
	if(empty($oid)) $oid = $row->orderid;
	global $current_user;
	get_currentuserinfo();
	$uid = $current_user->ID;
	
	
		?>
    	<div class="my_order">
        	<div class="my_order_id">#<?php echo $row->id ?></div>
            <div class="my_order_datemade"><?php echo date_i18n('d-M-Y H:i:s', $row->datemade) ?></div>
            <div class="my_order_price"><?php echo walleto_get_show_price($row->totalprice) ?></div>
            <div class="my_order_buttons">
            
                <?php 
				
					$dt = !empty($row->paid_on) ? date_i18n('d-M-Y H:i:s', $row->paid_on) : "";
					echo sprintf(__('Paid on <br/> %s','Walleto'), $dt); ?>
            
            </div>
        	
            <div class="my_order_thing_horiz">
            <?php 
			
			global $wpdb;
			$s = "select cnt.delivered_on from ".$wpdb->prefix."walleto_order_contents cnt, $wpdb->posts posts where 
			 posts.ID=cnt.pid AND posts.post_author='$uid' AND cnt.orderid='$oid' limit 1";
			$r = $wpdb->get_results($s);  
			
			$r = $r[0];
			$shp = date_i18n('d-M-Y H:i:s', $r->delivered_on);
			
			echo sprintf(__('You delivered this order on: %s','Walleto'), $shp); ?> 
            <a class="btns_pay" href="<?php echo walleto_get_order_content_link2($oid, $uid) ?>"><?php _e('Order Details','Walleto'); ?></a>
            
            </div>
            
        </div>
    
    <?php	
	
}



/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

function walleto_display_awaiting_payments_for_seller($row)
{
	?>
    	<div class="my_order">
        	<div class="my_order_id">#<?php echo $row->id ?></div>
            <div class="my_order_datemade"><?php echo date_i18n('d-M-Y H:i:s', $row->datemade) ?></div>
            <div class="my_order_price"><?php echo walleto_get_show_price($row->totalprice) ?></div>
            <div class="my_order_buttons">
            
                <?php 
				
					$dt = !empty($row->datemade) ? date_i18n('d-M-Y H:i:s', $row->datemade) : "";
					echo sprintf(__('Purchased on <br/> %s','Walleto'), $dt); ?>
            
            </div>
        	
            <div class="my_order_thing_horiz">			
			<?php
			
			$using_perm = Walleto_using_permalinks();
	
			if($using_perm)	$privurl_m = get_permalink(get_option('Walleto_my_account_priv_mess_page_id')). "?";
			else $privurl_m = get_bloginfo('siteurl'). "/?page_id=". get_option('Walleto_my_account_priv_mess_page_id'). "&";	
			
			$prvs = $privurl_m."priv_act=send&";
			$prvs .= 'pid='.$post->ID.'&uid='.$row->uid;
			
			$slr = get_userdata($row->uid);
			
			?>
            <a class="btns_pay" href="<?php echo walleto_get_order_content_link2($row->id, $uid) ?>"><?php _e('View Order Details','Walleto'); ?></a>
            <a class="btns_pay" href="<?php echo $prvs ?>"><?php echo sprintf(__('Contact Buyer: %s','Walleto'), $slr->user_login); ?></a>
            
            </div>
            
            
        </div>
    
    <?php	
	
}


/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_display_shipped_order_for_buyer($row)
{
?>
    	<div class="my_order">
        	<div class="my_order_id">#<?php echo $row->id ?></div>
            <div class="my_order_datemade"><?php echo date_i18n('d-M-Y H:i:s', $row->datemade) ?></div>
            <div class="my_order_price"><?php echo walleto_get_show_price(walleto_get_total_for_order($row->id)) ?></div>
            <div class="my_order_buttons">            
            <?php				
			$dt = !empty($row->shipped_on) ? date_i18n('d-M-Y H:i:s', $row->shipped_on) : "";
			echo sprintf(__('Delivered on: %s.','Walleto'), $dt); ?>            
            </div>            
            <div class="my_order_thing_horiz aura_tp">		 
            <a class="btns_pay" href="<?php echo walleto_get_order_content_link($row->id) ?>"><?php _e('View Order Details','Walleto'); ?></a>                       
            </div>        
        </div>    
    <?php	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_get_users_links()
{
	global $post;
	$pid = $post->ID;
	
	global $current_user;
	get_currentuserinfo();
	$uid = $current_user->ID;
	
	$feedback_page 		= get_option('Walleto_my_account_reviews_page_id');
	$messages_page 		= get_option('Walleto_my_account_priv_mess_page_id');
	$parent_acc 		= get_option('Walleto_my_account_page_id');
	$pers_info 			= get_option('Walleto_my_account_pers_info_page_id');
	$shp_pnts_info 		= 1592; // (Page ID)
	$set_dlvry_page 	= 1700; // (Page ID)
	$set_pkup_page 		= 5836; // (Page ID)
	$byr_cmn_bskt_page 	= 21026; // (Page ID)
	$finances 			= get_option('Walleto_my_account_my_finances_page_id');
	
	$all_orders 		= get_option('Walleto_my_account_all_orders_page_id');
	$out_pay 			= get_option('Walleto_my_account_outstanding_pay_page_id');
	$not_shipped 		= get_option('Walleto_my_account_not_shipped_page_id');
	$shipped 			= get_option('Walleto_my_account_shipped_cust_page_id');
	
	$active_items 			= get_option('Walleto_my_account_act_items_page_id');
	$out_of_stock 			= get_option('Walleto_my_account_out_of_stock_page_id');
	$aw_pay 				= get_option('Walleto_my_account_aw_pay_page_id');
	$aw_shp 				= get_option('Walleto_my_account_aw_shp_page_id');
	$shp_orders 			= get_option('Walleto_my_account_shp_ord_page_id');
	$shp_stp_id				= get_option('Walleto_my_account_shop_setup_page_id');
	
	if($pid == $active_items)		$active_active_items = "class='active'";
	elseif($pid == $out_of_stock)	$active_out_of_stock = "class='active'";
	elseif($pid == $aw_pay)			$active_aw_pay = "class='active'";
	elseif($pid == $aw_shp)			$active_aw_shp = "class='active'";
	elseif($pid == $shp_orders)		$active_shp_orders = "class='active'";
	
	elseif($pid == $parent_acc)		$active_home = "class='active'";
	elseif($pid == $messages_page)	$active_messages = "class='active'";
	elseif($pid == $feedback_page)	$active_feedback = "class='active'";
	elseif($pid == $pers_info)		$active_pers_info = "class='active'";
	elseif($pid == $shp_pnts_info)  $active_shp_pnts_info = "class='active'";
	elseif($pid == $byr_cmn_bskt_page)  $active_byr_bskt_info = "class='active'";
	elseif($pid == $finances)		$active_finances = "class='active'";
	
	elseif($pid == $shipped)		$active_shp = "class='active'";
	elseif($pid == $not_shipped)	$active_not_shp = "class='active'";
	elseif($pid == $out_pay)		$active_out_py = "class='active'";
	elseif($pid == $all_orders)		$active_all_orders = "class='active'";
	elseif($pid == $shp_stp_id)		$shop_stp = "class='active'";
	
	$rd = walleto_get_unread_number_messages($current_user->ID);
	if($rd > 0) $ssk = "<span class='nots_nots'>".$rd.'</span>';
	
	?>
    	<?php 
			global $current_user, $wpdb;
			get_currentuserinfo();
			/* $role = $wpdb->prefix . 'capabilities';
			$current_user->role = array_keys($current_user->$role); */
			if(is_array($current_user->roles)) {
				$role = $current_user->roles[0];
			}	
	    	 ?>
        <div id="right-sidebar"> 
			<ul class="xoxo">
            
            	<li class="widget-container widget_text account_widget_thing"><h3 class="widget-title"><?php _e("My Account Menu",'Walleto'); ?></h3>
                
                	<ul id="my-account-admin-menu">
                    <li><a <?php echo $active_home; ?> href="<?php echo walleto_my_account_link(); ?>"><?php _e("My Account Home",'Walleto');?></a></li>
                    
                    <?php /* <li><a <?php echo $shop_stp; ?> href="<?php echo get_permalink($shp_stp_id); ?>"><?php _e("My Shop Setup",'Walleto');?></a></li>  */ ?>
                    
                    <?php
					
					$Walleto_enable_pay_credits = get_option('Walleto_enable_pay_credits');
					if($Walleto_enable_pay_credits != "no"):
					
					?>
                    
                    <li><a <?php echo $active_finances; ?> href="<?php echo get_permalink($finances); ?>"><?php _e("Finances",'Walleto');?></a></li>
                   
                   	<?php endif; ?>
                   <li><a <?php echo $active_pers_info; ?> href="<?php echo get_permalink($pers_info); ?>"><?php _e("Personal Info",'Walleto');?></a></li>
				   <li><a <?php echo $active_shp_pnts_info; ?> href="<?php echo get_permalink($shp_pnts_info); ?>"><?php _e("Earned Loyalty Points",'Walleto');?></a></li>
				   <li><a <?php echo $active_byr_bskt_info; ?> href="<?php echo get_permalink($byr_cmn_bskt_page); ?>"><?php _e("Common Basket",'Walleto');?></a></li>
                    <?php /*<li><a <?php echo $active_messages; ?> href="<?php echo get_permalink($messages_page); ?>"><?php printf(__("Private Messages %s",'Walleto'), $ssk);?></a></li>
                    
                     <li><a <?php echo $active_feedback; ?> href="<?php echo get_permalink($feedback_page); ?>"><?php _e("Reviews/Feedback",'Walleto');?></a></li>  */ ?>
                    
                    
                    </ul>              
                </li>
                <?php if($role=='seller') { ?>
                <li class="widget-container widget_text account_widget_thing"><h3 class="widget-title"><?php _e("My Shop",'Walleto'); ?></h3> 
                <?php
				
				global $wpdb;
				$s = "select distinct cnt.orderid from ".$wpdb->prefix."walleto_order_contents cnt, ".$wpdb->prefix."walleto_orders ord, $wpdb->posts posts where 
				ord.paid='0' and ord.delivered='0' AND ord.id=cnt.orderid AND posts.ID=cnt.pid AND posts.post_author='$uid' order by ord.id desc";
				
				$row = $wpdb->get_results($s);
				$cnt = count($row);
				
				if($cnt > 0) $outs_pmnts2 = ' <span class="nots_nots">'.$cnt.'</span>';
				
				//-------------------------------
				
				global $wpdb;
				$s = "select distinct cnt.orderid from ".$wpdb->prefix."walleto_order_contents cnt, ".$wpdb->prefix."walleto_orders ord, $wpdb->posts posts where 
				ord.paid='1' and ord.delivered='0' AND ord.id=cnt.orderid AND posts.ID=cnt.pid AND cnt.delivered='0' AND posts.post_author='$uid' order by ord.id desc";
				
				$r = $wpdb->get_results($s);						
				if(count($r) > 0) $outs_pmnts2a = ' <span class="nots_nots">'.count($r).'</span>';		
						
				?>
                	<ul id="my-account-admin-menu">
                   <?php /* <li><a href="<?php echo get_permalink(get_option('Walleto_post_new_page_id')); ?>"><?php _e("Sell New Product",'Walleto');?></a></li> 
                    <li><a <?php echo $active_active_items; ?> href="<?php echo get_permalink($active_items); ?>"><?php _e("Active Items",'Walleto');?></a></li>
                    <li><a <?php echo $active_out_of_stock; ?> href="<?php echo get_permalink($out_of_stock); ?>"><?php _e("Out of Stock Items",'Walleto');?></a></li> */?>
                    <li><a <?php echo $active_aw_pay; ?> href="<?php echo get_permalink($aw_pay); ?>"><?php echo sprintf(__("Awaiting Payments %s",'Walleto'), $outs_pmnts2);?></a></li>
                    <li><a <?php echo $active_aw_shp; ?> href="<?php echo get_permalink($aw_shp); ?>"><?php _e("Awaiting Shipping",'Walleto');?><?php echo $outs_pmnts2a; ?></a></li>
                    <li><a <?php echo $active_shp_orders; ?> href="<?php echo get_permalink($shp_orders); ?>"><?php _e("Paid and Shipped",'Walleto');?></a></li>
                  	</ul>  
                                
                </li>
                
                <?php }
				
				global $wpdb;
				$s = "select count(id) as mycnt from ".$wpdb->prefix."walleto_orders where uid='$uid' AND paid='0' AND pymt_type='' AND status!=8 order by id desc";
				$r = $wpdb->get_results($s);
				$row = $r[0];
				
				if($row->mycnt > 0) $outs_pmnts = '<span class="nots_nots">'.$row->mycnt.'</span>';
					
					
				//---------------------
				
				$s = "select distinct orderid from ".$wpdb->prefix."walleto_order_contents where uid='$uid' AND paid='1' and delivered='0' order by id desc";
				$r = $wpdb->get_results($s);	
				
				if(count($r) > 0) $smopp = '<span class="nots_nots">'.count($r).'</span>';	
				  if($role=='subscriber') { ?>
				
                <li class="widget-container widget_text account_widget_thing"><h3 class="widget-title"><?php _e("My Purchases",'Walleto'); ?></h3>
                
                	<ul id="my-account-admin-menu">
                    <li><a <?php echo $active_all_orders; ?> href="<?php echo get_permalink($all_orders); ?>"><?php _e("All Orders",'Walleto');?></a></li>
                    <li><a <?php echo $active_out_py; ?> href="<?php echo get_permalink($out_pay); ?>"><?php echo sprintf(__("Outstanding Payments %s",'Walleto'), $outs_pmnts);?></a></li>
                  <?php /*Spidanet:removes unwanted links starts   <li><a <?php echo $active_not_shp; ?> href="<?php echo get_permalink($not_shipped); ?>"><?php echo sprintf(__("Not Shipped Orders %s",'Walleto'), $smopp);?></a></li>

                    <li><a <?php echo $active_shp; ?> href="<?php echo get_permalink($shipped); ?>"><?php _e("Shipped Orders",'Walleto');?></a></li> Spidanet:removes unwanted links ends */ ?>
                  	</ul>  
                                
                </li>
                <?php } ?>
            

            <?php the_widget( 'adv-search-widget', $instance, $args );   ?>
            </ul>
        </div>
       
    
    
    <?php	
	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_post_new_link()
{
	return get_permalink(get_option('Walleto_post_new_page_id'));		
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_watch_list()
{
	return get_permalink(get_option('Walleto_watch_list_id'));
	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_blog_link()
{
	return get_permalink(get_option('Walleto_blog_home_id'));	
	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_advanced_search_link()
{
	return get_permalink(get_option('Walleto_adv_search_id'));		
	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_get_period_from_code($s)
{
	if($s == "yearly") return __('12 Months','Walleto');
	return __('1 Month','Walleto');	
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_get_period_from_code_numeric($s)
{
	if($s == "yearly") return 12;
	return 1;	
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_how_much_to_get_as_custom_percent($amount)
{
	$Walleto_fee_after_paid = get_option('Walleto_take_percent_fee');
	$deducted = 0;	
								
	if(!empty($Walleto_fee_after_paid)):		
		$deducted = $amount*($Walleto_fee_after_paid * 0.01);
	else: 		
		$deducted = 0;		
	endif;
												
	//------------------------------------
								
	$Walleto_fee_after_paid_flat_fee  = get_option('Walleto_take_flat_fee');
	if(!empty($Walleto_fee_after_paid_flat_fee)):
		if(is_numeric($Walleto_fee_after_paid_flat_fee)):		
			$deducted = $Walleto_fee_after_paid_flat_fee;	
		endif;
	endif;		
	
	return $deducted;
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function walleto_add_history_log($tp, $reason, $amount, $uid, $uid2 = '')
{
	global $wpdb;
	
	$tm = current_time('timestamp',0); global $wpdb;
	$s = "insert into ".$wpdb->prefix."walleto_payment_transactions (tp,reason,amount,uid,datemade,uid2)
	values('$tp','$reason','$amount','$uid','$tm','$uid2')";	
	$wpdb->query($s);
}


/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_is_able_to_post_products()
{
	$opt = get_option('Walleto_only_admins_post_products');
	if($opt == "yes")
	{
		if(current_user_can( 'manage_options' )) return true;
		else return false;
	}
	
	return true;
	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_my_account_link()
{
	return get_permalink(get_option('Walleto_my_account_page_id'));	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_is_home()
{
	global $current_user, $wp_query;
	$a_action 	=  $wp_query->query_vars['w_action'];	
	
	if(!empty($a_action)) return false;
	if(is_home()) return true;
	return false;
	
}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/


	
	add_action('wp_ajax_remove_from_watchlist', 		'Walleto_remove_from_watchlist');
	add_action('wp_ajax_nopriv_remove_from_watchlist', 	'Walleto_remove_from_watchlist');
	
	add_action('wp_ajax_add_to_watchlist', 				'Walleto_add_to_watchlist');
	add_action('wp_ajax_nopriv_add_to_watchlist', 		'Walleto_add_to_watchlist');
	
	function Walleto_remove_from_watchlist()
	{
		$pid = $_POST['pid'];
		
		if(is_user_logged_in()):
		
			global $current_user;
			get_currentuserinfo();
			$uid = $current_user->ID;
			
			Walleto_delete_pid_in_watchlist($pid, $uid);
			
			echo "removed-".$uid."-".$pid."-";
		
		else:
			
			if(!is_user_logged_in())
			{
				$watchlist_thing_id = $_SESSION['watchlist_thing_id'];
				if(empty($watchlist_thing_id))
				{
					$watchlist_thing_id = time().rand(0,9999);	
					$_SESSION['watchlist_thing_id'] = $watchlist_thing_id;
				}
				
				$uid = $watchlist_thing_id;
			}
			
			Walleto_delete_pid_in_watchlist($pid, $uid);
			
			echo "removed-".$uid."-".$pid."-";
			
			//echo "NO_LOGGED";	
		
		endif;	
		
	}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/	
	function Walleto_check_if_pid_is_in_watchlist($pid, $uid)
	{
		global $wpdb;
		$s = "select * from ".$wpdb->prefix."walleto_watchlist where pid='$pid' AND uid='$uid'";	
		$r = $wpdb->get_results($s);
		
		if(count($r) == 0) return false;		
		return true;
	}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
	
 
	 
	function Walleto_add_pid_in_watchlist($pid, $uid)
	{
		global $wpdb;
		$s = "insert into ".$wpdb->prefix."walleto_watchlist (pid,uid) values('$pid','$uid')";	
		$wpdb->query($s);
		
	}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/	
	function Walleto_delete_pid_in_watchlist($pid, $uid)
	{
		global $wpdb;
		$s = "delete from ".$wpdb->prefix."walleto_watchlist where pid='$pid' AND uid='$uid'";	
		$wpdb->query($s);
		
	}
	
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/

	function Walleto_add_to_watchlist()
	{
		$pid = $_POST['pid'];
		
		if(is_user_logged_in()):
		
			global $current_user;
			get_currentuserinfo();
			$uid = $current_user->ID;
			
			if(Walleto_check_if_pid_is_in_watchlist($pid, $uid) == false)
				Walleto_add_pid_in_watchlist($pid, $uid);
			
			echo "added-".$uid."-".$pid."-";
			
		else:
		
			if(!is_user_logged_in())
			{
				$watchlist_thing_id = $_SESSION['watchlist_thing_id'];
				if(empty($watchlist_thing_id))
				{
					$watchlist_thing_id = time().rand(0,9999);	
					$_SESSION['watchlist_thing_id'] = $watchlist_thing_id;
				}
				
				$uid = $watchlist_thing_id;
			}	
			
			if(Walleto_check_if_pid_is_in_watchlist($pid, $uid) == false)
				Walleto_add_pid_in_watchlist($pid, $uid);
			
			echo "added-".$uid."-".$pid."-";
		
		endif;
	}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_get_currency()
{
	$c = trim(get_option('Walleto_currency_symbol'));
	if(empty($c)) return get_option('Walleto_currency');
	return $c;	
	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_currency()
{
	return Walleto_get_currency();	
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_get_show_price($price, $cents = 2)
{	
	$Walleto_currency_position = get_option('Walleto_currency_position');	
	if($Walleto_currency_position == "front") return Walleto_get_currency()."".Walleto_formats($price, $cents);	
	return Walleto_formats($price,$cents)."".Walleto_get_currency();	
		
}
/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_formats($number, $cents = 1) { // cents: 0=never, 1=if needed, 2=always
  
  if($cents == 0) return $number;
  
  $dec_sep = get_option('Walleto_decimal_sum_separator');
  if(empty($dec_sep)) $dec_sep = '.';
  
  $tho_sep = get_option('Walleto_thousands_sum_separator');
  if(empty($tho_sep)) $tho_sep = ',';
  
  //dec,thou
  
  if (is_numeric($number)) { // a number
    if (!$number) { // zero
      $money = ($cents == 2 ? '0'.$dec_sep.'00' : '0'); // output zero
    } else { // value
      if (floor($number) == $number) { // whole number
        $money = number_format($number, ($cents == 2 ? 2 : 0), $dec_sep, $tho_sep ); // format
      } else { // cents
        $money = number_format(round($number, 2), ($cents == 0 ? 0 : 2), $dec_sep, $tho_sep ); // format
      } // integer or decimal
    } // value
    return $money;
  } // numeric
} // formatMoney

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
function Walleto_generate_thumb($img_url, $width, $height, $cut = true)
{

	return walleto_wp_get_attachment_image($img_url, array($width, $height ));
}

function walleto_get_user_profile_link($uid)
{
	return get_bloginfo('siteurl'). '/?w_action=user_profile&post_author='. $uid;	
}

function Walleto_send_email_on_priv_mess_received($sender_uid, $receiver_uid)
{
	$enable 	= get_option('Walleto_priv_mess_received_email_enable');
	$subject 	= get_option('Walleto_priv_mess_received_email_subject');
	$message 	= get_option('Walleto_priv_mess_received_email_message');	
	$admin_email = get_option( 'admin_email' );	
	
	if($enable != "no"):
	
		$user 			= get_userdata($receiver_uid);
		$site_login_url = Walleto_login_url();
		$site_name 		= get_bloginfo('name');
		$account_url 	= get_permalink(get_option('Walleto_my_account_page_id'));
		$sndr			= get_userdata($sender_uid);

		$find 		= array('##sender_username##', '##receiver_username##', '##site_login_url##', '##your_site_name##', '##your_site_url##' , '##my_account_url##');
   		$replace 	= array($sndr->user_login, $user->user_login, $site_login_url, $site_name, get_bloginfo('siteurl'), $account_url);
		
		$tag		= 'Walleto_send_email_on_priv_mess_received';
		$find 		= apply_filters( $tag . '_find', 	$find );
		$replace 	= apply_filters( $tag . '_replace', $replace );
		
		$message 	= Walleto_replace_stuff_for_me($find, $replace, $message);
		$subject 	= Walleto_replace_stuff_for_me($find, $replace, $subject);
		
		//---------------------------------------------
 
		#Walleto_send_email($user->user_email, $subject, $message);
		Walleto_send_email($admin_email, "PRIVATE MESSAGE RECEIVED", $message);
	
	endif;
} 

		if(isset($_GET['confirm_message_deletion']))
		{
			
			$using_perm = Walleto_using_permalinks();
	
			if($using_perm)	$privurl_m = get_permalink(get_option('Walleto_my_account_priv_mess_page_id')). "?";
			else $privurl_m = get_bloginfo('siteurl'). "/?page_id=". get_option('Walleto_my_account_priv_mess_page_id'). "&";	
			
			$return 	= $_GET['return'];
			$messid 	= $_GET['id'];	
			
			global $wpdb, $current_user;
			get_currentuserinfo();
			$uid = $current_user->ID;
			
			$s = "select * from ".$wpdb->prefix."walleto_pm where id='$messid' AND (user='$uid' OR initiator='$uid')";
			$r = $wpdb->get_results($s);	
			
			if(count($r) > 0)
			{
				$row = $r[0];
				
				if($row->initiator == $uid)
				{
					$s = "update ".$wpdb->prefix."walleto_pm set show_to_source='0' where id='$messid'";
					$wpdb->query($s);	
					
				}
				else
				{
					$s = "update ".$wpdb->prefix."walleto_pm set show_to_destination='0' where id='$messid'";
					$wpdb->query($s);						
				}
				
				if($return == "inbox") wp_redirect($privurl_m . "priv_act=inbox");
				else if($return == "outbox") wp_redirect($privurl_m . "priv_act=sent-items");
				else if($return == "home") wp_redirect($privurl_m . "priv_act=home");
				else wp_redirect(Walleto_my_account_link());
				
			}
			else wp_redirect(Walleto_my_account_link());
			
		}

/*****************************************************************************
*
*	Function - Walleto -
*
*****************************************************************************/
/* Custom code starts */


/*Add a new user role*/
function add_user_role() {
       add_role( 'seller', 'Seller', array( 'read' => true, 'level_0' => true ) );
   }
  
   

/*Change post's author*/
function change_pos_auth($post_id){
	$cpt_chk = $_POST['post_type'];
    if ( ! wp_is_post_revision( $post_id ) && ($cpt_chk == "product" || $cpt_chk == "shop") ){

        // unhook this function so it doesn't loop infinitely
        remove_action('save_post','change_pos_auth');
        
        $autohrArr=get_field('seller');

        if ( isset( $autohrArr['ID']) && $autohrArr['ID']!='') {
             $args = array('ID'=>$post_id,'post_author'=> $autohrArr['ID']);
             // update the post, which calls save_post again
             wp_update_post( $args );
        }

       // re-hook this function
       add_action('save_post','change_pos_auth');

    }
}
add_action('save_post', 'change_pos_auth');


/* Enqueue custom js and css */

function hnt_custom_scripts() {
	// Get regions from database
	$rgns = Walleto_get_all_regions();
	$rgns = json_encode($rgns);
	$wl_site_uri = get_bloginfo('url');
	$wl_myaccount_uri = get_permalink(get_option('Walleto_my_account_page_id'));	
	$wl_theme_uri = get_template_directory_uri();
	$wl_ajax_uri = admin_url( 'admin-ajax.php' );
	
	//jQuery UI JS and CSS
	wp_enqueue_style( 'jQuery UI css', 'https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css' );
	wp_enqueue_script('jQuery UI script','https://code.jquery.com/ui/1.11.4/jquery-ui.js',array( 'jquery' ));
	//Custom JS and CSS
	wp_enqueue_style( 'Custom hnt css ', get_template_directory_uri(). '/css/custom_hnt.css?vers='.rand() );
	
	wp_register_script('Custom hnt script', get_template_directory_uri() . '/js/custom_hnt.js', array('jquery'), filemtime( get_stylesheet_directory().'/js/custom_hnt.js' ), false);
	wp_localize_script('Custom hnt script', 'regions_obj', array('encode_obj' => $rgns, 'wl_theme_uri' => $wl_theme_uri, 'wl_ajax_uri' => $wl_ajax_uri, 'wl_site_uri' => $wl_site_uri, 'wl_myaccount_uri' => $wl_myaccount_uri));
	wp_enqueue_script('Custom hnt script');
	
	wp_enqueue_script('lazyload-js', get_template_directory_uri() . '/js/jquery.lazyload.js', array('jquery'));

	//Fancybox JS and CSS
	wp_enqueue_style( 'Fancybox css ', get_template_directory_uri(). '/css/jquery.fancybox-1.3.2.css?vers='.rand() );
	wp_enqueue_script('Fancybox script',get_template_directory_uri() . '/js/jquery.fancybox-1.3.2.js?vers='.rand(),array( 'jquery' ));
	
	wp_enqueue_script('elevateZoom', get_template_directory_uri() . '/js/jquery.elevateZoom-3.0.8.min.js', array('jquery'));
}

add_action( 'wp_enqueue_scripts', 'hnt_custom_scripts' );

function Walleto_admin_favicon() {  	
	$favicon_url = get_stylesheet_directory_uri() . '/favicon.ico';	
	echo '<link rel="shortcut icon" href="' . $favicon_url . '" />';
}

add_action('login_head', 'Walleto_admin_favicon');
add_action('admin_head', 'Walleto_admin_favicon');

function walleto_login_logo() { ?>    
	<style type="text/css">        
	.login h1 a {
		background-image: url(<?php echo get_stylesheet_directory_uri(); ?>/images/online_logo.png);
		background-size: 322px auto;
		width: 322px;
		height: 85px;
	}
	#backtoblog { display: none; }
</style>
<?php }

add_action( 'login_enqueue_scripts', 'walleto_login_logo' );

function custom_role_name() {
    global $wp_roles;

    if ( ! isset( $wp_roles ) )
        $wp_roles = new WP_Roles();
 	// buyer
    $wp_roles->roles['subscriber']['name'] = 'Buyer';
    $wp_roles->role_names['subscriber'] = 'Buyer';
	// Level1 - Handling products, shops and sellers
    $wp_roles->roles['editor']['name'] = 'Level1';	
	$wp_roles->role_names['editor'] = 'Level1';	
	// Level2 - Order Management, Delivery Requests, Loyalty system
    $wp_roles->roles['contributor']['name'] = 'Level2';	
	$wp_roles->role_names['contributor'] = 'Level2';
	// Level3 - E-wallet and payments management
    $wp_roles->roles['author']['name'] = 'Level3';	
	$wp_roles->role_names['author'] = 'Level3';	    
}
add_action('init', 'custom_role_name');

/*Coupon functions starts*/

add_action('wp_ajax_remove_coupon', 'remove_coupon');
	function remove_coupon(){
		$code = $_POST['code'];
		delete_option(SHORTNAME.'_coupon_'.$code);
		echo json_encode(
			array(
				'error' => 0,
				'message' => $_POST['remove_index'],
			)
		);
		die;
	}

	add_action('wp_ajax_edit_coupon', 'edit_coupon');
	function edit_coupon(){
		print_r($_POST);
		die;
	}
/*Coupon functions ends*/

/*Add unique column for product ID starts*/


function walleto_my_product_columns($columns) //this function display the columns headings
{
	$columns["item_seller"] = __("Seller", "Walleto");	
	$columns["itm_avail"] 	= __("Availability","Walleto");
	$item_id_column = array( 		              
		'ID' => __('Unique Item ID', 'Walleto'),                          
	);
	return array_slice( $columns, 0, 1, true ) + $item_id_column + array_slice( $columns, 1, NULL, true );
}

add_filter("manage_edit-product_columns","walleto_my_product_columns");

/*Check if discount coupon is there for order.. starts*/
function check_discount($oId){
	global $wpdb;
	//and `paid`=0
	$s = "select `discount` from ".$wpdb->prefix."walleto_orders where id='$oId' ";
	$r = $wpdb->get_results($s);
	$row = $r[0];
	$aval_discount = $row->discount;
	return $aval_discount;
}

/*Check if discount coupon is there for order.. ends*/


function my_custom_admin_styles() {
   ?>
	<style type="text/css">
		/*Hide post status,visibility and time from admin*/
		.misc-pub-post-status, .misc-pub-visibility, .misc-pub-curtime {
			display: none;
		}	
	 </style>
    <?php
}
add_action('admin_head', 'my_custom_admin_styles');

/*function unregister_taxonomy(){
    register_taxonomy('product_cat', array());
}
add_action('admin_init', 'unregister_taxonomy');*/

function get_shop_by_productid($pId){

$sellerId = get_post_meta($pId,'seller',true);
$logoQuery = new WP_Query(array("author" => $sellerId,"post_type" =>"shop"));

	while ( $logoQuery->have_posts() ) {

		$logoQuery->the_post();
		return get_post(get_the_ID());

		
	}
}


function delete_cart_cookiee() {
	setcookie ("my_cart", "", time() - 3600);
}

add_action('wp_logout', 'delete_cart_cookiee');


/*Spidanet: remove add media button starts*/
function RemoveAddMediaButtons(){
	global $current_screen;
	if( 'shop' == $current_screen->post_type )  {
		remove_action( 'media_buttons', 'media_buttons' );
	}
}
add_action('admin_head', 'RemoveAddMediaButtons');

/*Spidanet: remove add media button ends*/

/*Spidanet : ajax request for order contact*/

	add_action('wp_ajax_order_contact', 		'Walleto_order_contact');
	add_action('wp_ajax_nopriv_order_contact', 	'Walleto_order_contact');

	function Walleto_order_contact()
	{ 
		global $wpdb,$current_user;
		$subject  = 'Order inquiry';
		$dm = current_time('timestamp',0);	
		$curuser = $current_user->ID;
		$reciever = walleto_get_userid_from_username('hntmall');
		

		if(isset($_POST['consubmit']) && $_POST['consubmit']=="Send"){
			extract($_POST);
			$message= mysql_real_escape_string($message);
			$s = "insert into ".$wpdb->prefix."walleto_pm (content,user, subject, initiator,datemade) values('$message','$reciever','$subject', '$curuser', '$dm')";				
			$wpdb->query($s);

			Walleto_send_email_on_priv_mess_received($curuser,$reciever);

			die;
		}

	
	}
register_nav_menus( array(
	'header' => __( 'header Navigation', 'theme' ),
	'footer' => __( 'Footer Navigation', 'theme' )
));

/** function to fetch date picker information
*return a string of the datepicker
*/
function date_picker()
{ 
	$min_date = 1;
	while($min_date <= 31)
	{
		$date[] = $min_date;
		$min_date += 1;
	}
	$min_year = 1900;
	while($min_year <= date('Y' , strtotime("-10 years")))
	{
		$year[] = $min_year;
		$min_year += 1;
	}
	function options($var)
	{
		//print '<option value="">Please Select</option>';
		foreach($var as $col)
		{
			print "<option value='".$col."'>".$col."</option>";
		}
	}
	?>
	<div class="form-group">
		<span class="input-group-addon">
			<select id="year" name="dob[y]"  class='form-control'>
				<?php options($year); ?>
			</select>
		</span>
		<span class="input-group-addon">
			<select id="month" name="dob[m]"  class='form-control'>
				<option value="">Please Select</option>
				<option value='01' >January</option>
				<option value='02' >February</option>
				<option value='03' >March</option>
				<option value='04' >April</option>
				<option value='05' >May</option>
				<option value='06' >June</option>
				<option value='07' >July</option>
				<option value='08' >August</option>
				<option value='09' >September</option>
				<option value='10' >October</option>
				<option value='11' >November</option>
				<option value='12' >December</option>
			</select>
		</span>
		<span class="input-group-addon">
			<select id="day" class='form-control' name="dob[d]">
				<?php options($date); ?>
			</select>
		</span>
	</div><?php
}