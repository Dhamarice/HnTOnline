<?php
require("config.inc.php");



  
$query  = " SELECT VALUE FROM `wp_cimy_uef_data` where USER_ID=:uid and FIELD_ID=4 LIMIT 1";
    //now lets update what :user should be
    $query_params = array(
        ':uid' => $userid
    );
    


    //Now let's make run the query:
    try { 
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
		
		
		 //$response["success"] = 1;
        //$response["message"] = "Phone number fetched" .$result;
        //echo(json_encode($response));
		
    }
    catch (PDOException $ex) {
        
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!";
        echo(json_encode($response));
    }
    
    $row = $stmt->fetch();
    if ($row) {
        
                            $telno = $row['VALUE'];
						


        $response["success"] = 1;
        $response["message"] = "Phone number fetched" .$telno;
        echo(json_encode($response));
	}
 else {
         $telno = "Error";

$response["success"] = 0;
        $response["message"] = "Phone number not fetched:".$row['VALUE'];
		
        echo(json_encode($response));
		
 }






function send_sms($sender,$cell,$message)
{
	//$sender = 'HTAH';
	
    $user = 'calvinm';
    $pass = 'h4mm3r';
	//$message = 'Dear Customer, You have placed an order of $".$_POST["totalprice"].", for invoice  #". $oid ." You will be notified when it is ready for delivery/pick up. Thank you HTSM';
	//$cell = isset($_POST['telno']);
    
    $url = "http://api.infobip.com/api/v3/sendsms/plain?user=".$user."&password=".$pass."&sender=" . $sender . "&SMSText=".urlencode($message)."&GSM=". $cell ."&type=longSMS"; 
    $answer = file_get_contents($url);
    return $answer; 
	 //var_dump(parse_url($url));


    
//$code = $_SESSION['startNum'];

    //$cell = $CellNo;
}

 

send_sms('HTAH', $telno, "Dear Customer, You have placed an order of $".$_POST["totalprice"].", for invoice  #". $orderid ." You will be notified when it is ready for delivery/pick up. Thank you HTSM");

	   
?>