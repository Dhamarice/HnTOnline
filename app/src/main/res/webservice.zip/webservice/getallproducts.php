<?php

/*
Our "config.inc.php" file connects to database every time we include or require
it within a php script.  Since we want this script to add a new user to our db,
we will be talking with our database, and therefore,
let's require the connection to happen:
*/
require("config.inc.php");
 
//initial query
$query = "SELECT p.ID, p.post_title, tt.taxonomy, tt.parent,(SELECT guid FROM wp_posts WHERE id = m.meta_value ) AS `imgurl`, m1.meta_value as 'price', pm1.meta_value as seller
FROM wp_posts p inner join `wp_term_relationships` tr on p.ID=tr.object_id
inner JOIN wp_term_taxonomy tt on tt.term_taxonomy_id = tr.term_taxonomy_id
left outer join wp_postmeta m on p.id = m.post_id AND m.meta_key = '_thumbnail_id' 
left outer join wp_postmeta m1 on p.id = m1.post_id AND m1.meta_key = 'price' 
left outer join wp_postmeta pm1  on p.id = pm1.post_id and pm1.meta_key = 'seller'
left outer join wp_postmeta m2 on p.id=m2.post_id and m2.meta_key='quant'
where p.post_type='product'  and post_status='publish' and m2.meta_value <> '' and m2.meta_value <> '0' and m2.meta_value <> 'null'";


//execute query
try {
    $stmt   = $db->prepare($query);
    $result = $stmt->execute();
}
catch (PDOException $ex) {
    $response["success"] = 0;
    $response["message"] = "Database Error!";
    die(json_encode($response));
}

// Finally, we can retrieve all of the found rows into an array using fetchAll 
$rows = $stmt->fetchAll();


if ($rows) {
    $response["success"] = 1;
    $response["message"] = "Post Available!";
    $response["posts"]   = array();
    
    foreach ($rows as $row) {
        $post             = array();
		$post["post_id"]  = $row["ID"];
        $post["product_name"] = $row["post_title"]; 
        $post["imgurl"] = $row["imgurl"]; 
        $post["price"] = $row["price"]; 
        $post["category_id"] = $row["parent"]; 
         $post["store_id"] = $row["seller"]; 
       $post["product_id"] = $row["ID"]; 
        //update our repsonse JSON data
        array_push($response["posts"], $post);
    }
    
    // echoing JSON response
    echo json_encode($response);
    
    
} else {
    $response["success"] = 0;
    $response["message"] = "No Post Available!";
    die(json_encode($response));
}

?>
