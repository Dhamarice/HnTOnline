<?php
global $wp_query, $wpdb;
if(isset($_POST['endUserId']) && isset($_POST['oid']) && isset($_POST['endUserotp']) && isset($_POST['yes'])) :

	$orderId =   intval(trim($_POST['oid']));
	$action = $_POST['action'];
	$endUserId = intval(trim($_POST['endUserId']));
	$endUserotp = intval(trim($_POST['endUserotp']));
	$orderTotal = $_POST['amt'];

	$total = $_POST['amt'];;
	$sellerArr = array();
	$orderSql = "select * from ".$wpdb->prefix."walleto_order_contents where orderid='$orderId'";
	$orderRs = $wpdb->get_results($orderSql);
	foreach ($orderRs as $orderR) {
		$sid  = $orderR->seller;
		if(!in_array($sid, $sellerArr)) {
			array_push($sellerArr, $sid);
		}	
	}

	$sids=implode(',', $sellerArr);

	//-------------------------------------------------

	$mcht_username = ('230090');
	$mcht_pid = ('OBOPAY');
	$mcht_pass = ('test1234');
	$mcht_enckey = ('test1234');
	
	$reqID =  'hsh'.time().rand(0,9999);

	//$uid = $current_user->ID;
	$amount = $total;
	

	/* Creating Request For TeleCash  */
	$url = "http://testonlinepay.telecel.co.zw/ObopayExternalWS/ObopayExternalWebServiceV1?WSDL";
	//$url = "http://liveonlinepay.telecel.co.zw/ObopayExternalWS/ObopayExternalWebServiceV1?WSDL";
	$client = new SoapClient($url);
	$header_part = '
		<obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="UserName">'.$mcht_username.'</obons:header> 
	  <obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="Password">'.$mcht_pass.'</obons:header> 
	  <obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="PartnerId">'.$mcht_pid.'</obons:header> 
	  <obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="iv">'.$mcht_enckey.'</obons:header>
	';
	$soap_var_header = new SoapVar( $header_part, XSD_ANYXML, null, null, null );
	$soap_header = new SoapHeader( 'http://www.obopay.com/xml/ns/tpu/v1', 'obons', $soap_var_header );
	$client->__setSoapHeaders($soap_header);
	$client->__setLocation('http://liveonlinepay.telecel.co.zw/ObopayExternalWS/ObopayExternalWebServiceV1');

	$result = $client->process(array('request'=>array('encoding'=>'UTF-8',
		'ApiIdType' => 'REQ',
					'Tier3AgentId' => '230090',  
					'CustomerPhoneNumber' => '263'.$endUserId,  
					'TransactionType' => '500',  
					'InstrumentType' => '1', 
					'ProcessorCode' => '0026', 
					'PaymentDetails1' => $endUserotp,
					'TxnAmount' => $amount,  
					'CurrencyType' => 'USD', 
					'FeeAmount' => 20, 
					'TaxAmount' => 10,
					'RequestId' => $reqID,  
					'TerminalID' => '123', 
					'Reference1' => 'ONUS',
					'Reference2' => 'CARDLESS'
		)));	

	if ($result->return->Remark == "Success") {
		
		 $response["success"] = 1;
    $response["message"] = "Zvafayisa!!!!! ";
    echo( json_encode($response));
		
		
		global $wpdb;		
		$hash = $result->return->RequestId;	
		$hsh_ = get_option($hash);
		delete_option($hash);
		$exp = explode('|', $hsh_);	
		$uid = $exp[0];
		$datemade = $exp[1];
		$orderId = $exp[2];
		$sellerIds = $exp[3];
		$ttl_amt = $exp[4];
		
		/*********
		SETTLEMENT OF TRANACTION STARTS
		*********/
	$mcht_username = ('230090');
	$mcht_pid = ('OBOPAY');
	$mcht_pass = ('test1234');
	$mcht_enckey = ('test1234');
		$ops_trnx_id = $result->return->OpsTransactionId;
		$pay_details_1 = date("dmY", $datemade)."MC".$mcht_username."_".rand(1,9999);
		
		//$url = "http://testonlinepay.telecel.co.zw/ObopayExternalWS/ObopayExternalWebServiceV1?WSDL";
		$url = "http://liveonlinepay.telecel.co.zw/ObopayExternalWS/ObopayExternalWebServiceV1?WSDL";
		$client = new SoapClient($url);

		$header_part = '
			<obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="UserName">'.$mcht_username.'</obons:header> 
		  <obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="Password">'.$mcht_pass.'</obons:header> 
		  <obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="PartnerId">'.$mcht_pid.'</obons:header> 
		  <obons:header xmlns:obons="http://www.obopay.com/xml/ns/tpu/v1" name="iv">'.$mcht_enckey.'</obons:header>
		';
		$soap_var_header = new SoapVar( $header_part, XSD_ANYXML, null, null, null );
		$soap_header = new SoapHeader( 'http://www.obopay.com/xml/ns/tpu/v1', 'obons', $soap_var_header );
		$client->__setSoapHeaders($soap_header);
		$client->__setLocation('http://liveonlinepay.telecel.co.zw/ObopayExternalWS/ObopayExternalWebServiceV1');
		$reqID =  'hsh'.time().rand(0,9999);
		$results = $client->process(array('request'=>array('encoding'=>'UTF-8',
			'ApiIdType' => 'REQ',  
						'Tier3AgentId' => $mcht_username, 
						'TransactionType' => '503',  
						'InstrumentType' => '1', 
						'ProcessorCode' => '0029', 
						'PaymentDetails1' => $pay_details_1,
						'PaymentDetails2' => $ops_trnx_id."|".$ttl_amt,
						'RequestId' => $reqID,  
						'TerminalID' => '123', 
						'Reference1' => 'ONUS',
						'Reference2' => 'CARDLESS'
			)));		
			
		/*********
		SETTLEMENT OF TRANACTION ENDS
		*********/		
			
	} else {
		   $response["success"] = 0;
    $response["message"] = "It's owkay rurururu!!!!! ";
    echo( json_encode($response));
		if($result) {
			   $response["success"] = 0;
    $response["message"] = "It's owkay rururu!!!!! ";
    echo( json_encode($response));
		}
   $response["success"] = 0;
    $response["message"] = "It's owkay ruru!!!!! ";
    echo( json_encode($response));
	}	
		
	die();

endif;


//==========================

?>
