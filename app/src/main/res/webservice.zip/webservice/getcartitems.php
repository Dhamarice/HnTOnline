<?php
/*
Our "config.inc.php" file connects to database every time we include or require
it within a php script.  Since we want this script to add a new user to our db,
we will be talking with our database, and therefore,
let's require the connection to happen:
*/
require("config.inc.php");

//initial query
$query = "SELECT Distinct ID, p.post_title, p.post_content, pr_p.meta_value as price, (SELECT guid FROM wp_posts WHERE id = m.meta_value ) AS `imgurl` FROM wp_posts p inner join wp_postmeta pr_p on p.ID=pr_p.post_id inner join `wp_term_relationships` tr on p.ID=tr.object_id left outer join wp_postmeta m on p.id = m.post_id AND m.meta_key = '_thumbnail_id' where p.post_type='product' and pr_p.meta_key='price' and ID IN (".$_POST['productid'].") Order By p.post_modified ";

//execute query
try {
    $stmt   = $db->prepare($query);
    $result = $stmt->execute();
}
catch (PDOException $ex) {
    $response["success"] = 0;
    $response["message"] = "Database Error!";
    die(json_encode($response));
}

// Finally, we can retrieve all of the found rows into an array using fetchAll 
$rows = $stmt->fetchAll();


if ($rows) {
    $response["success"] = 1;
    $response["message"] = "Post Available!";
    $response["posts"]   = array();
    
    foreach ($rows as $row) {
        $post             = array();
		$post["post_id"]  = $row["ID"];
        $post["name"] = $row["post_title"]; 
        $post["imgurl"] = $row["imgurl"]; 
        $post["price"] = $row["price"]; 
		$post["post_id"] = $row["ID"];
        
        //update our repsonse JSON data
        array_push($response["posts"], $post);
    }
    
    // echoing JSON response
    echo json_encode($response);
    
    
} else {
    $response["success"] = 0;
    $response["message"] = "No Post Available!";
    die(json_encode($response));
}
?>
