<?php
try
{
	
require("config.inc.php");
 
 $tm 		= $_SERVER['REQUEST_TIME'] ;
	
    if (!isset($_POST['userid']) || !isset($_POST['totalprice']) || !isset($_POST['discount']) || !isset($_POST['ptype'])   || !isset($_POST['Coupon']) )  {
        

        // Create some data that will be the JSON response 
        $response["success"] = 0;
        $response["message"] = "Please supply UserID,  Total Amount  Discount and Payment Types";
        
        //die will kill the page and not execute any code below, it will also
        //display the parameter... in this case the JSON data our Android
        //app will parse
		print_r($_POST);
        die(json_encode($response));
    }
    
	        $ptype = $_POST['ptype'];
   
    $query = "INSERT INTO `wp_walleto_orders`( `uid`,  datemade, `totalprice`,   `discount` ) VALUES (:uid, :dt, :totalprice, :discount) ";
    
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':uid' => $_POST['userid'],
        ':totalprice' => $_POST['totalprice'],
		':discount' => $_POST['discount'],
		':dt' => $tm
    );
   
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
		$id = $db->lastInsertId();
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!";
        die(json_encode($response));
    }
  
  //$id=16330;  
	if (isset($id))
	{
try
{
		 $cart = json_decode($_POST['cartitems']);
}
catch (exception $ex)
{
	echo die("Error Decoding".$ex);
}
/*
print_r($cart);
die;
*/
if(is_array($cart) and count($cart) > 0)
	{
	/*	 $response["success"] = 0;
        $response["message"] = "Bho Zvokuti Tsano!!!";
		print_r($cart);
        die(json_encode($response));
		
	*/	
		foreach($cart as $item)
		{			
		 $query = "INSERT INTO `wp_walleto_order_contents`( `uid`,  `orderid`, `pid`, `ptitle`, `price`, `discount`, `quant`) VALUES (:uid, :orderid, :pid, :ptitle, :price, :discount, :quant) ";
    
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':uid' => $_POST['userid'],
        ':orderid' => $id,
		':pid' => $item->productid,
		':ptitle' => $item->ptitle,
        ':price' => $item->price,
		':discount' => $item->discount,
		':quant' => $item->qnty,
    );
    
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
		$prdcid = $db->lastInsertId();
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error2. Please Try Again!";
        die(json_encode($response));
    }

		}
			
	}
	
	//SEND EMAIL TO USER
	//Walleto_send_email_when_item_is_paid_buyer($id, $_POST['uid']);
	

$userid = $_POST['userid'];
    //gets user's info based off of a username.
    $query = "SELECT * FROM `wp_cimy_uef_data` where USER_ID=:uid and FIELD_ID=4 LIMIT 1";
    
    $query_params = array(
        ':uid' => $userid
    );
    
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one to product JSON data:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Please Try Again!";
        echo(json_encode($response));
        
    }
    $CellNo="";
    //This will be the variable to determine whether or not the user's information is correct.
    //we initialize it as false.
    $validated_info = false;
    
    //fetching all the rows from the query
 $rows = $stmt->fetchAll();
                           
    if ($rows) {
      foreach ($rows as $row)
                            {
                            $CellNo = $row['VALUE'];
							$CellNo = 	"263" . substr($CellNo, 1);
							}
					
 }
 else {
         $CellNo = "Error";
 }
	//SEND SMS TO USER
	//$usercell = get_user_cellno($_POST['userid']);
	$msg = "Dear Customer, You have made a payment of ".$_POST["totalprice"]." through eWallet for invoice  ". $id ." You will be notified when it is ready for delivery/pick up. Thank you HTSM";
						$url ="http://api.infobip.com/api/v3/sendsms/plain?user=HandT&password=n4Kzkp90&sender=HnTOnline&SMSText=" . urlencode($msg) ."&GSM=" . $CellNo;	
		 
		
//Set stream options
$opts = array(
  'http' => array('ignore_errors' => true)
);

//Create the stream context
$context = stream_context_create($opts);

//Open the file using the defined context
$file = file_get_contents($url, true, $context);	


					
	if ( $_POST['discount'] >0)
	{
		if ($_POST['discount']>= $_POST['totalprice'])
		{
				$query = "Update `wp_walleto_orders` set paid = 1, paid_on = :dt where id = :oid  ";
    
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':oid' => $id, 
		':dt' => $tm,
    );
   
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Failed To Update Order Status To Paid";
        die(json_encode($response));
    }
	
	
	$Change =($_POST['discount'] -$_POST['totalprice']);
	$query = "Update `wp_usermeta` set meta_value = round(meta_value + :amt,2) where user_id = :uid  and meta_key = 'credits' ";
    
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':uid' => $_POST['userid'],
		':amt' => $Change, 

    );
   
    //time to run our query,
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Failed To Update Order Status To Paid". $ex;
        die(json_encode($response));
    }

	
	$query = "Update `wp_walleto_coupons` set cpn_avail = cpn_avail-1 where cpn_code = :uid";
    
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':uid' => $_POST['Coupon'], 

    );
   
    //time to run our query,
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Failed To Update Order Status To Paid". $ex;
        die(json_encode($response));
    }
 	$response["posts"] = "success";	
    $response["success"] = 1;
    $response["message"] = "Order Successfully Added!".$_POST['ptype'];
	$response["id"] = $id;
	$response["celly"] = $CellNo;
    die( json_encode($response));

		}
	}
	
	
	//If Payment is Via Ewallet mark as paid 
if ($_POST['ptype'] =='ewallet')
{
	$query = "Update `wp_walleto_orders` set paid = 1, paid_on = :dt where id = :oid  ";
    
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':oid' => $id, 
		':dt' => $tm,
    );
   
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Failed To Update Order Status To Paid";
        die(json_encode($response));
    }
	
	
	
	$query = "Update `wp_usermeta` set meta_value = round(meta_value - :amt,2) where user_id = :uid  and meta_key = 'credits' ";
    
    //Again, we need to update our tokens with the actual data:
    $query_params = array(
        ':uid' => $_POST['userid'],
		':amt' => $_POST['totalprice'], 

    );
   
    //time to run our query, and create the user
    try {
        $stmt   = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch (PDOException $ex) {
        // For testing, you could use a die and message. 
        //die("Failed to run query: " . $ex->getMessage());
        
        //or just use this use this one:
        $response["success"] = 0;
        $response["message"] = "Database Error1. Failed To Update Order Status To Paid". $ex;
        die(json_encode($response));
    }

	
 	$response["posts"] = "success";	
    $response["success"] = 1;
    $response["message"] = "Order Successfully Added!".$_POST['ptype'];
	$response["id"] = $id;
	$response["celly"] = $CellNo;
    die( json_encode($response));
}

	}
	
						
    $response["posts"] = "success";
	$response["success"] = 1;
    $response["message"] = "Order Successfully Added!";
	$response["id"] = $id;
    die( json_encode($response));
    
    //for a php webservice you could do a simple redirect and die.
    //header("Location: login.php"); 
    //die("Redirecting to login.php");
    
}
catch(Exception $ex)
{
	$response["success"] = 0;
        $response["message"] = $e->getMessage();
        
	  die( 'Caught exception: '.  json_encode($response) );
}
    $response["posts"] = "Failed";	
    $response["success"] = 0;
    $response["message"] = "Failed to Create Order Successfully Added!".$_POST['ptype'];
	$response["id"] = $id;
    die( json_encode($response));

?>
